const express = require('express');
const router = express.Router();
const bannerData=require('../data/banner.json')
// 测试接口
router.get('/test', (req, res) => {
    res.send('测试成功');
})
router.get('/home/banner',(req,res)=>{
    res.send(bannerData)
})
module.exports=router;