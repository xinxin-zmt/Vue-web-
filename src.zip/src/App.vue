<template>
    <!-- 一级路由出口 -->
    <RouterView/>
</template>
<style lang="less">
@import url('./assets/styles/mixins.less');
</style>


