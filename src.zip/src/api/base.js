const base = {
    baseUrl: 'http://you.163.com',
    categoryUrl: '/api/xhr/globalinfo/queryTop.json' ,// 这里要想到跨域配置。
    bannerUrl:'/foo/home/banner',
}
export default base;