<template>
    <div class="banner-nav">
        <div class="nav-container">
            <ul class="nav-list  ">
            <!-- block1 -->
                <li class="nav-item block1 "><span class="nav-item-span">有品推荐</span><span> / </span><span 
                        class="nav-item-span">手机数码</span></li>
                    <!-- tab1 -->
                    <div class="nav-detail d1 ">
                    <div class="sub-cate-area">
                        <div class="cate-name">有品推荐</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="精选分类">精选分类</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=778eb3cf17277f79b8b8e1696db3c609&amp;categoryName=空调&amp;pageFrom=category"
                                        class="category-3-item ">空调</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1d4bbbe272a9a7a8089488873aa6077b&amp;categoryName=平板电视&amp;pageFrom=category"
                                        class="category-3-item ">平板电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=21003a7a17dd3914407cfb4e555d96e1&amp;categoryName=K系列&amp;pageFrom=category"
                                        class="category-3-item ">K系列</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4d3d5b4e50656b6729750909421d649c&amp;categoryName=笔记本&amp;pageFrom=category"
                                        class="category-3-item ">笔记本</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b73e5e40d77afe932dfe54d45bff1f5b&amp;categoryName=Note 系列&amp;pageFrom=category"
                                        class="category-3-item ">Note 系列</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7bb2e71326e98a97a03eadd8e589bccc&amp;categoryName=数字系列&amp;pageFrom=category"
                                        class="category-3-item ">数字系列</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="精选专区">精选专区</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e9ffe172cab816d6e4773394f0f1482c&amp;categoryName=清凉电器&amp;pageFrom=category"
                                        class="category-3-item ">清凉电器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8306f8af578b3a2dab709df798b2647f&amp;categoryName=净化器&amp;pageFrom=category"
                                        class="category-3-item ">净化器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=64b49e2e3c2fbebadd75dcc4a79a9c58&amp;categoryName=加湿器&amp;pageFrom=category"
                                        class="category-3-item ">加湿器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4dab368bc14a4c7ad838cc445fbab2b9&amp;categoryName=耳机&amp;pageFrom=category"
                                        class="category-3-item ">耳机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e9bb31a5bee8ee13c409c66c29ed7943&amp;categoryName=摄像头&amp;pageFrom=category"
                                        class="category-3-item ">摄像头</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a703bca904a90fb6ce0046fed3f9a56f&amp;categoryName=洗衣机&amp;pageFrom=category"
                                        class="category-3-item ">洗衣机</a></span></div>
                        </div>
                    </div>
                    <div class="sub-cate-area">
                        <div class="cate-name">手机数码</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="小米手机">小米手机</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7bb2e71326e98a97a03eadd8e589bccc&amp;categoryName=数字系列&amp;pageFrom=category"
                                        class="category-3-item ">数字系列</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1913ae62fc12e8fd1c3fc5624adbeadc&amp;categoryName=折叠屏&amp;pageFrom=category"
                                        class="category-3-item ">折叠屏</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f47e49ebb7179151f7e148f9a4334e0e&amp;categoryName=CIVI系列&amp;pageFrom=category"
                                        class="category-3-item ">CIVI系列</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="Redmi">Redmi</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=21003a7a17dd3914407cfb4e555d96e1&amp;categoryName=K系列&amp;pageFrom=category"
                                        class="category-3-item ">K系列</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4038ec590a45638a2a1919de93ff29e9&amp;categoryName=Turbo系列&amp;pageFrom=category"
                                        class="category-3-item ">Turbo系列</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b73e5e40d77afe932dfe54d45bff1f5b&amp;categoryName=Note 系列&amp;pageFrom=category"
                                        class="category-3-item ">Note 系列</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8951abd6261260d127ac32b4918beb97&amp;categoryName=Redmi数字&amp;pageFrom=category"
                                        class="category-3-item ">Redmi数字</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="影音周边">影音周边</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=61cb04bbba389f558a42f187d268d9e7&amp;categoryName=投影机&amp;pageFrom=category"
                                        class="category-3-item ">投影机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3396bc3dbeffbe6ed1900b5a7123ec30&amp;categoryName=音响/音箱&amp;pageFrom=category"
                                        class="category-3-item ">音响/音箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a16e3fa147043b593f33812a9599e80e&amp;categoryName=麦克风&amp;pageFrom=category"
                                        class="category-3-item ">麦克风</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c1497378d0a2c066d716164827dcf811&amp;categoryName=家庭影院&amp;pageFrom=category"
                                        class="category-3-item ">家庭影院</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d92db4af061306d31589ffb6898657ed&amp;categoryName=投影配件&amp;pageFrom=category"
                                        class="category-3-item ">投影配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f87ca889e8c41dc66a1f5c0983f081a9&amp;categoryName=特殊商品&amp;pageFrom=category"
                                        class="category-3-item ">特殊商品</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="智能穿戴">智能穿戴</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d97b5df8c6cf3f2ae65f0254e2b849eb&amp;categoryName=小米手环&amp;pageFrom=category"
                                        class="category-3-item ">小米手环</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0c5513f1784f0af220af54cf7fb9e2ec&amp;categoryName=智能手表&amp;pageFrom=category"
                                        class="category-3-item ">智能手表</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ab1041ab8706721891dac6236f1968c9&amp;categoryName=运动手表&amp;pageFrom=category"
                                        class="category-3-item ">运动手表</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=385bbf4d684e441dbfb1c34c644ac993&amp;categoryName=AR/VR&amp;pageFrom=category"
                                        class="category-3-item ">AR/VR</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="手机周边">手机周边</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=713b155c7f4d2645df9a983d733112bd&amp;categoryName=充电器&amp;pageFrom=category"
                                        class="category-3-item ">充电器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=eba07568940eb4209d85db9f3a1aa651&amp;categoryName=移动电源&amp;pageFrom=category"
                                        class="category-3-item ">移动电源</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4eed5cbab9838a91f7e29658fdc8c162&amp;categoryName=三角架/云台&amp;pageFrom=category"
                                        class="category-3-item ">三角架/云台</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=708208c8d086e6d559010052c1d2c979&amp;categoryName=数据线&amp;pageFrom=category"
                                        class="category-3-item ">数据线</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e6300c8b1e5308fc5bb0811014e77aae&amp;categoryName=手机壳/保护套&amp;pageFrom=category"
                                        class="category-3-item ">手机壳/保护套</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=97967749935612ab8f865f42dba2be1c&amp;categoryName=手机贴膜&amp;pageFrom=category"
                                        class="category-3-item ">手机贴膜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a6a051727ef46b34c77e45e978db4893&amp;categoryName=手机支架&amp;pageFrom=category"
                                        class="category-3-item ">手机支架</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=01e2e27439419174b446dc76366e05e1&amp;categoryName=创意配件&amp;pageFrom=category"
                                        class="category-3-item ">创意配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="电竞游戏">电竞游戏</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fd833758d969a668616a2036222ae0ca&amp;categoryName=游戏机&amp;pageFrom=category"
                                        class="category-3-item ">游戏机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=625c6fb3445bbe4e59cd12ebb597a533&amp;categoryName=游戏耳机&amp;pageFrom=category"
                                        class="category-3-item ">游戏耳机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8289727f3c55b9d4ca4aa704eb6fe0f1&amp;categoryName=游戏配件&amp;pageFrom=category"
                                        class="category-3-item ">游戏配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=56f74e335f5b0edc7ea82448c2c44311&amp;categoryName=手柄/方向盘&amp;pageFrom=category"
                                        class="category-3-item ">手柄/方向盘</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2c161954039d2ec022fbade2261b1c63&amp;categoryName=游戏周边&amp;pageFrom=category"
                                        class="category-3-item ">游戏周边</a></span></div>
                        </div>
                    </div>
                    </div>    
            <!-- block2 -->
                <li class="nav-item block2 "><span class="nav-item-span">小米自营</span><span> / </span><span
                        class="nav-item-span">小米电视</span></li>
                    <!-- tab2 -->
                    <div class="nav-detail d2 ">
                    <div class="sub-cate-area">
                        <div class="cate-name">小米自营</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="手机数码">手机数码</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e6b1a2338fc77cc777d4ea85846b2e2a&amp;categoryName=小米手机&amp;pageFrom=category"
                                        class="category-3-item ">小米手机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6dc98d62afa5a343b2e9854f73187c14&amp;categoryName=Redmi手机&amp;pageFrom=category"
                                        class="category-3-item ">Redmi手机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7b014217bd2b1b674b26affc805850b8&amp;categoryName=手表&amp;pageFrom=category"
                                        class="category-3-item ">手表</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=eb64d734a78f4932af8d80aff3c3968d&amp;categoryName=手环&amp;pageFrom=category"
                                        class="category-3-item ">手环</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=dbf0d530afd8751f9fb0f18934ce6ae8&amp;categoryName=耳机&amp;pageFrom=category"
                                        class="category-3-item ">耳机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a2f19fc43e4bf79051920c3505bf6737&amp;categoryName=壳膜配件&amp;pageFrom=category"
                                        class="category-3-item ">壳膜配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6878ca9caa7ec8d26600c6fe1b1d18a4&amp;categoryName=腕带配件&amp;pageFrom=category"
                                        class="category-3-item ">腕带配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3392792e12e45a4ce7d5253e2cf1c231&amp;categoryName=充电器配件&amp;pageFrom=category"
                                        class="category-3-item ">充电器配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="家用大电">家用大电</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=778eb3cf17277f79b8b8e1696db3c609&amp;categoryName=空调&amp;pageFrom=category"
                                        class="category-3-item ">空调</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ea65b26125ebd6e7e230a1cda36f5b67&amp;categoryName=小米电视&amp;pageFrom=category"
                                        class="category-3-item ">小米电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=dcf66435268e838b5fcbb3255e8f9225&amp;categoryName=Redmi电视&amp;pageFrom=category"
                                        class="category-3-item ">Redmi电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7a4c9ff18c2f8f9803eaecb59ac4e579&amp;categoryName=电视盒子&amp;pageFrom=category"
                                        class="category-3-item ">电视盒子</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6afa32aa90dd45766347364e2b3cb7fa&amp;categoryName=投影机&amp;pageFrom=category"
                                        class="category-3-item ">投影机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d1201ae70966f433fee8a6f5a9a1631c&amp;categoryName=米家洗衣机&amp;pageFrom=category"
                                        class="category-3-item ">米家洗衣机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=71aea11f70c3a87e7853187e690f47b2&amp;categoryName=米家冰箱&amp;pageFrom=category"
                                        class="category-3-item ">米家冰箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a76678d62d1b990cb8cfb404bea52e4c&amp;categoryName=安装服务&amp;pageFrom=category"
                                        class="category-3-item ">安装服务</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="新品发布">新品发布</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d68fd34b3c8379c1494955476c216d71&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1feec4c45921e915b13a26512262eb31&amp;categoryName=手机数码&amp;pageFrom=category"
                                        class="category-3-item ">手机数码</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=11e9a2f7f60d78b362e67c74640d7736&amp;categoryName=家装大电&amp;pageFrom=category"
                                        class="category-3-item ">家装大电</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f9a2c236783b271891e70a46529982d0&amp;categoryName=智能生活&amp;pageFrom=category"
                                        class="category-3-item ">智能生活</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="电脑办公">电脑办公</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f6389cd04ca2cdeedf65663acfce400f&amp;categoryName=笔记本&amp;pageFrom=category"
                                        class="category-3-item ">笔记本</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=29c1c7456962c1fccda97d66be4b3793&amp;categoryName=平板&amp;pageFrom=category"
                                        class="category-3-item ">平板</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6203d6416663ff8c9a9612405333a65b&amp;categoryName=显示器&amp;pageFrom=category"
                                        class="category-3-item ">显示器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cd774754a150629164bcc0a6b5a9972d&amp;categoryName=路由&amp;pageFrom=category"
                                        class="category-3-item ">路由</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7ac6ca0476b4f5b99dfcaa3f51fd5a60&amp;categoryName=打印机&amp;pageFrom=category"
                                        class="category-3-item ">打印机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7d6d5b7cc74f592f73d51edabea1d073&amp;categoryName=鼠标及配件&amp;pageFrom=category"
                                        class="category-3-item ">鼠标及配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="厨房小电">厨房小电</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=492730e57dd4e7f2c20a6d7a93872aee&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5bf04bc7e0a0ffd47bdf3f8f8b721df9&amp;categoryName=空气炸锅&amp;pageFrom=category"
                                        class="category-3-item ">空气炸锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2d96a8a5d6929d0776fc928678453d16&amp;categoryName=电饭煲&amp;pageFrom=category"
                                        class="category-3-item ">电饭煲</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f57ffeca342b02be9cd49cfbc4c3fbe0&amp;categoryName=电水壶/热水瓶&amp;pageFrom=category"
                                        class="category-3-item ">电水壶/热水瓶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6d77abdc0c18b36c13074a88a2ce6569&amp;categoryName=电磁炉&amp;pageFrom=category"
                                        class="category-3-item ">电磁炉</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=81de3de40af1ef2cff38d427bd9a2459&amp;categoryName=微波炉&amp;pageFrom=category"
                                        class="category-3-item ">微波炉</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=016c8c7daff869306cab92c228412a18&amp;categoryName=电烤箱&amp;pageFrom=category"
                                        class="category-3-item ">电烤箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f22a1a54380330f1e39b174c869f0582&amp;categoryName=料理机&amp;pageFrom=category"
                                        class="category-3-item ">料理机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=42cec6514f55337061cc615a2167831c&amp;categoryName=电压力锅&amp;pageFrom=category"
                                        class="category-3-item ">电压力锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d7494c368f3444fc8753acf3fc9c5dfc&amp;categoryName=多用途锅&amp;pageFrom=category"
                                        class="category-3-item ">多用途锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=13955ec6b8979355bd5f48f58d17fd0d&amp;categoryName=养生壶/煎药壶&amp;pageFrom=category"
                                        class="category-3-item ">养生壶/煎药壶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3b15163f729c0b4036c73290d79790d5&amp;categoryName=榨汁机/原汁机&amp;pageFrom=category"
                                        class="category-3-item ">榨汁机/原汁机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=af9c52ba0dbdfce154ad5b8ce032e408&amp;categoryName=咖啡机&amp;pageFrom=category"
                                        class="category-3-item ">咖啡机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=16cab7ca92decb159e84f7368948e816&amp;categoryName=破壁机&amp;pageFrom=category"
                                        class="category-3-item ">破壁机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a240163e5d38a60a841cf991f1d397a7&amp;categoryName=厨房电器配件&amp;pageFrom=category"
                                        class="category-3-item ">厨房电器配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="智能生活">智能生活</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7f0823622e92033cbc851700dd0713c7&amp;categoryName=摄像头&amp;pageFrom=category"
                                        class="category-3-item ">摄像头</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=07334ab9aec29e20d69e478e187ad39e&amp;categoryName=灯饰照明&amp;pageFrom=category"
                                        class="category-3-item ">灯饰照明</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b1f94d0e7dca162a45ae1574be2d3441&amp;categoryName=网关/ 传感器&amp;pageFrom=category"
                                        class="category-3-item ">网关/ 传感器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=67df30645563b9cec5a51e71a45a81d0&amp;categoryName=照片打印机&amp;pageFrom=category"
                                        class="category-3-item ">照片打印机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b0342a4b3a0c5c37791344901126abf3&amp;categoryName=儿童手表&amp;pageFrom=category"
                                        class="category-3-item ">儿童手表</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7fca37713abd33c1cb73563dce917e57&amp;categoryName=行车记录仪&amp;pageFrom=category"
                                        class="category-3-item ">行车记录仪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0738c6fb97d498d2aba835e3fff05afa&amp;categoryName=电源充电器&amp;pageFrom=category"
                                        class="category-3-item ">电源充电器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9e2981059d564038dd646130d0273c23&amp;categoryName=装饰材料&amp;pageFrom=category"
                                        class="category-3-item ">装饰材料</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5e475042a5d5f4e91da027d52ae35004&amp;categoryName=门锁&amp;pageFrom=category"
                                        class="category-3-item ">门锁</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=14e6eb10ffdf2445eceb2b51c926ea42&amp;categoryName=路由器&amp;pageFrom=category"
                                        class="category-3-item ">路由器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7933fdd3511a073eb4d2c76c1ab79030&amp;categoryName=音箱&amp;pageFrom=category"
                                        class="category-3-item ">音箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4a4d404c6dbfe9994baff294b96e6a7f&amp;categoryName=开关插座&amp;pageFrom=category"
                                        class="category-3-item ">开关插座</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="个护电器">个护电器</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f75941546768e92d9c67c6eb79e6621d&amp;categoryName=牙刷&amp;pageFrom=category"
                                        class="category-3-item ">牙刷</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=894e2e32bc2a9c551111dd591b6c18c1&amp;categoryName=电吹风&amp;pageFrom=category"
                                        class="category-3-item ">电吹风</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=79bd869583cef60dde520666156bb8a4&amp;categoryName=剃须刀&amp;pageFrom=category"
                                        class="category-3-item ">剃须刀</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fdfa3bbcea520c2ba2a58d68d1a0eb20&amp;categoryName=电子秤&amp;pageFrom=category"
                                        class="category-3-item ">电子秤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6f7f6fa8acaf3ce1a0e0c310007c18aa&amp;categoryName=冲牙器&amp;pageFrom=category"
                                        class="category-3-item ">冲牙器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=51e66fa60e7ef215965d5418c65e0353&amp;categoryName=驱蚊用品&amp;pageFrom=category"
                                        class="category-3-item ">驱蚊用品</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="运动户外">运动户外</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b60588f0a286b90ccef9f2749b8b5632&amp;categoryName=平衡车/滑板车&amp;pageFrom=category"
                                        class="category-3-item ">平衡车/滑板车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=629d35f6c8ae36d8d2260f50d7b91073&amp;categoryName=跑步机&amp;pageFrom=category"
                                        class="category-3-item ">跑步机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4d7e7bf8425a6d9674089583c23ed0e1&amp;categoryName=动感单车&amp;pageFrom=category"
                                        class="category-3-item ">动感单车</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="生活小电">生活小电</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f7b10a0dee27e6389bd2a473aed46fc6&amp;categoryName=空气净化器&amp;pageFrom=category"
                                        class="category-3-item ">空气净化器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5515234e555967b000c5460f7091681e&amp;categoryName=生活电器配件&amp;pageFrom=category"
                                        class="category-3-item ">生活电器配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=10b6d74e1eca135f2dcfed9efc23e26a&amp;categoryName=扫地机器人&amp;pageFrom=category"
                                        class="category-3-item ">扫地机器人</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=360aeb0ab0874bbe3e5fd2039a60a40e&amp;categoryName=电风扇&amp;pageFrom=category"
                                        class="category-3-item ">电风扇</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a2f727e0af4c6c7ba8a0c781eba23662&amp;categoryName=吸尘器&amp;pageFrom=category"
                                        class="category-3-item ">吸尘器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c777fb40114c6251cfe23ac280f43905&amp;categoryName=取暖电器&amp;pageFrom=category"
                                        class="category-3-item ">取暖电器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0191c339f0f6f62d25339aef62b1126b&amp;categoryName=除湿机&amp;pageFrom=category"
                                        class="category-3-item ">除湿机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=71111761dd9b0ba3c15ecc25e7825a9e&amp;categoryName=挂烫机/熨斗&amp;pageFrom=category"
                                        class="category-3-item ">挂烫机/熨斗</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b5084744ab7cd52f280431f71baef144&amp;categoryName=加湿器&amp;pageFrom=category"
                                        class="category-3-item ">加湿器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=633b8e1dc8c3d2f28fffcddc0c2d71c4&amp;categoryName=除螨仪&amp;pageFrom=category"
                                        class="category-3-item ">除螨仪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d9957b07ecf78c144761088ea36eebb4&amp;categoryName=新风系统&amp;pageFrom=category"
                                        class="category-3-item ">新风系统</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f599fcb08ac5fbabc3aabbd2b7879400&amp;categoryName=洗地机&amp;pageFrom=category"
                                        class="category-3-item ">洗地机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=97b59df6d8692ad0a1c8711c95543d35&amp;categoryName=新风配件&amp;pageFrom=category"
                                        class="category-3-item ">新风配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=173b274e1019f987561e78af3ff190b2&amp;categoryName=洗手机&amp;pageFrom=category"
                                        class="category-3-item ">洗手机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7217f024e0881336f6d777c1f66d8e87&amp;categoryName=体温计&amp;pageFrom=category"
                                        class="category-3-item ">体温计</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=98f2aad9f010dbb007f4c63df6a110a0&amp;categoryName=麦克风&amp;pageFrom=category"
                                        class="category-3-item ">麦克风</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=77c1e7ec76d2159496acedf6da1d48b8&amp;categoryName=理发器&amp;pageFrom=category"
                                        class="category-3-item ">理发器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=19d0ee7adf6350cdab216ddce3fb55ab&amp;categoryName=冲牙器&amp;pageFrom=category"
                                        class="category-3-item ">冲牙器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=13479abd6d1b9b6f022345367560692e&amp;categoryName=驱蚊用品&amp;pageFrom=category"
                                        class="category-3-item ">驱蚊用品</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9e5c78e065c949ff5594464d67ac5792&amp;categoryName=挂烫机/熨斗&amp;pageFrom=category"
                                        class="category-3-item ">挂烫机/熨斗</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=790ef38049c7cffcff1d1227c5f7c77e&amp;categoryName=麦克风&amp;pageFrom=category"
                                        class="category-3-item ">麦克风</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4d4062a101d975ddc177cbcd08651438&amp;categoryName=电动牙刷头&amp;pageFrom=category"
                                        class="category-3-item ">电动牙刷头</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=dbb380a7c8377f79b5e54bbb72c124aa&amp;categoryName=毛球修剪器&amp;pageFrom=category"
                                        class="category-3-item ">毛球修剪器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d846245f56c2b3aff7c352ce8674157f&amp;categoryName=电吹风&amp;pageFrom=category"
                                        class="category-3-item ">电吹风</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=55ab6eff6089f707be2ea7d7a7f893ea&amp;categoryName=剃须刀&amp;pageFrom=category"
                                        class="category-3-item ">剃须刀</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=63d231dd105917ee2918cc20dacee97e&amp;categoryName=牙刷&amp;pageFrom=category"
                                        class="category-3-item ">牙刷</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=02185ea26258d6bc2b99e7adfd5b1306&amp;categoryName=洗手液&amp;pageFrom=category"
                                        class="category-3-item ">洗手液</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d54f50d6b5576a341a6f5fd56f1acf21&amp;categoryName=洗车机&amp;pageFrom=category"
                                        class="category-3-item ">洗车机</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="小米配件">小米配件</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0501aeda2b129ba97e57c9e577a6deaf&amp;categoryName=接线板/插排&amp;pageFrom=category"
                                        class="category-3-item ">接线板/插排</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=306b8f43bd3ef37f324bf190173718d8&amp;categoryName=电动工具&amp;pageFrom=category"
                                        class="category-3-item ">电动工具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=630ad162b627df887d24bb32d5ae1347&amp;categoryName=充电器&amp;pageFrom=category"
                                        class="category-3-item ">充电器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=28ea4ca979e8ed201c4656ecd6b6b41d&amp;categoryName=牙刷配件&amp;pageFrom=category"
                                        class="category-3-item ">牙刷配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d002e290e81201be347be38e332c90ac&amp;categoryName=数据线&amp;pageFrom=category"
                                        class="category-3-item ">数据线</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7ce8a79458af30a64aa9da609943984d&amp;categoryName=其他配件&amp;pageFrom=category"
                                        class="category-3-item ">其他配件</a></span></div>
                        </div>
                    </div>
                    <div class="sub-cate-area">
                        <div class="cate-name">小米电视</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="热门推荐">热门推荐</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://m.xiaomiyoupin.com/w/leaderboard?_rt=weex&amp;scmv2_num=1&amp;gid=127288&amp;last_scmv2=3001.21.1:default-3:default-4:default-5:DNN_REALTIME_V18_CTR-6:default-7:default-8:EXP0060.0.0&amp;spmref=YouPin_A.share.share_pop_copy.4.71861628&amp;cid2=617a4315352df300015fe524&amp;cid3=-1&amp;type=6&amp;cid1=617a42a0799ab5000191f061"
                                        class="category-3-item ">电视热销榜</a><a
                                        data-src="https://app.xiaomiyoupin.com/search_category?apppagefrom=category&amp;queryId=45c1abd20bce58291d7fde21ce749742"
                                        class="category-3-item ">32-43吋</a><a
                                        data-src="https://app.xiaomiyoupin.com/search_category?apppagefrom=category&amp;queryId=efb55d7bb9c457b29412a6cc55561f91"
                                        class="category-3-item ">50-55吋</a><a
                                        data-src="https://app.xiaomiyoupin.com/search_category?apppagefrom=category&amp;queryId=a00114604b0ec1a9d7b42d5c2626c420"
                                        class="category-3-item ">60-65吋</a><a
                                        data-src="https://app.xiaomiyoupin.com/search_category?apppagefrom=category&amp;queryId=10b5c594b2efda85d272cfff8d19270d"
                                        class="category-3-item ">70-77吋</a><a
                                        data-src="https://app.xiaomiyoupin.com/search_category?apppagefrom=category&amp;queryId=0b078916968510c76e2641ea6d7b4f6b"
                                        class="category-3-item ">≥80英寸</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="电视类型">电视类型</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1d4bbbe272a9a7a8089488873aa6077b&amp;categoryName=平板电视&amp;pageFrom=category"
                                        class="category-3-item ">平板电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1d1bd5488c89c4e7f17a41f4fd67540a&amp;categoryName=全面屏&amp;pageFrom=category"
                                        class="category-3-item ">全面屏</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=97fad68a4d43735956f2b4b08e257bbc&amp;categoryName=4K超高清&amp;pageFrom=category"
                                        class="category-3-item ">4K超高清</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=dacf55ca8291458533d77abe89265d79&amp;categoryName=OLED电视&amp;pageFrom=category"
                                        class="category-3-item ">OLED电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0c957ba5ea7e5f6800543e80b8e9369a&amp;categoryName=QLED电视&amp;pageFrom=category"
                                        class="category-3-item ">QLED电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ba3fd2f19ab99429f57f537cd39e3a3d&amp;categoryName=8K超高清&amp;pageFrom=category"
                                        class="category-3-item ">8K超高清</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4451d672fbd2e4f189ff298ec26967d7&amp;categoryName=小米电视&amp;pageFrom=category"
                                        class="category-3-item ">小米电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d0f749216fed3e067eaac9a94450e198&amp;categoryName=Redmi电视&amp;pageFrom=category"
                                        class="category-3-item ">Redmi电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=408fe47eea78e4f6c3d4c37c7884ccaf&amp;categoryName=安装服务&amp;pageFrom=category"
                                        class="category-3-item ">安装服务</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="视听场景">视听场景</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e00cc29deea23f1b3119aec01be3ed9c&amp;categoryName=客厅电视&amp;pageFrom=category"
                                        class="category-3-item ">客厅电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d7bc5e220cf9c538c9ea04a6f2de4231&amp;categoryName=卧室电视&amp;pageFrom=category"
                                        class="category-3-item ">卧室电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=25393ea235df532d8bea8d8f12be4db6&amp;categoryName=游戏电视&amp;pageFrom=category"
                                        class="category-3-item ">游戏电视</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fb31111607f4945fec8b6de9e6973d79&amp;categoryName=剧幕大屏&amp;pageFrom=category"
                                        class="category-3-item ">剧幕大屏</a></span></div>
                        </div>
                    </div>
                    </div>
                <!-- block3 -->
                <li class="nav-item block3 "><span class="nav-item-span">电脑办公</span><span> / </span><span
                        class="nav-item-span">大家电</span></li>
                    <!-- tab3 -->
                    <div class="nav-detail d3 ">
                    <div class="sub-cate-area">
                        <div class="cate-name">电脑办公</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="办公设备">办公设备</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=47948f827493600b0460b77df7de50ce&amp;categoryName=外设产品&amp;pageFrom=category"
                                        class="category-3-item ">外设产品</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=056e2969319eecc37dd28c2ce0541bff&amp;categoryName=配件/耗材&amp;pageFrom=category"
                                        class="category-3-item ">配件/耗材</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=42c4d4d79c788a0a60e7885f89cba5ff&amp;categoryName=打印机&amp;pageFrom=category"
                                        class="category-3-item ">打印机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=703bfcaa39dc0e8f0008044b98991d6b&amp;categoryName=扫描仪&amp;pageFrom=category"
                                        class="category-3-item ">扫描仪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ddd81c2f858dbcaa8b7c553b22d10a8d&amp;categoryName=升降桌&amp;pageFrom=category"
                                        class="category-3-item ">升降桌</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d53eaef3c218e01919ef1d6fc1cade6c&amp;categoryName=路由器&amp;pageFrom=category"
                                        class="category-3-item ">路由器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=838b402368c7613e285c3d021c514d83&amp;categoryName=插线板&amp;pageFrom=category"
                                        class="category-3-item ">插线板</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="电脑">电脑</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5465576e71b35b68da0e54eba47bded1&amp;categoryName=台式机&amp;pageFrom=category"
                                        class="category-3-item ">台式机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4d3d5b4e50656b6729750909421d649c&amp;categoryName=笔记本&amp;pageFrom=category"
                                        class="category-3-item ">笔记本</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=db43a9289396142fe8736658c4680f14&amp;categoryName=平板电脑&amp;pageFrom=category"
                                        class="category-3-item ">平板电脑</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=836afb0cfe91193545fe7ecf3d6ab741&amp;categoryName=游戏本&amp;pageFrom=category"
                                        class="category-3-item ">游戏本</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=854541814fa5d6a34d93736adf936166&amp;categoryName=显示器&amp;pageFrom=category"
                                        class="category-3-item ">显示器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6b55a5f5c394824bc321808c0e4036ab&amp;categoryName=一体机&amp;pageFrom=category"
                                        class="category-3-item ">一体机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cb50e4863883b5b161a7768fb02c2e91&amp;categoryName=DIY存储配件&amp;pageFrom=category"
                                        class="category-3-item ">DIY存储配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a66d389ba9f8844ad528e96bc688a900&amp;categoryName=DIY电脑配件&amp;pageFrom=category"
                                        class="category-3-item ">DIY电脑配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=61729658f25631332e6e9b31e5f04f4d&amp;categoryName=笔记本配件&amp;pageFrom=category"
                                        class="category-3-item ">笔记本配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c3d0c2fe5fa23701a13c58f69fdb7c89&amp;categoryName=平板电脑配件&amp;pageFrom=category"
                                        class="category-3-item ">平板电脑配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="存储周边">存储周边</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=63d4bd79be2707822b105f87d324efc7&amp;categoryName=移动硬盘&amp;pageFrom=category"
                                        class="category-3-item ">移动硬盘</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7c9f846be2a6b4ddce2141021a7b4183&amp;categoryName=网络存储&amp;pageFrom=category"
                                        class="category-3-item ">网络存储</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=21a0666b94d44d168a56cf53291d2991&amp;categoryName=存储卡&amp;pageFrom=category"
                                        class="category-3-item ">存储卡</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1663a8a99137480b53f5ea439439885d&amp;categoryName=U盘&amp;pageFrom=category"
                                        class="category-3-item ">U盘</a></span></div>
                        </div>
                    </div>
                    <div class="sub-cate-area">
                        <div class="cate-name">大家电</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="冰箱">冰箱</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=320d32cc900b118cf49efb6c9f85a1df&amp;categoryName=对开门冰箱&amp;pageFrom=category"
                                        class="category-3-item ">对开门冰箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=052e0b164733ec3ec29add8e362d2df1&amp;categoryName=十字对开门&amp;pageFrom=category"
                                        class="category-3-item ">十字对开门</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5b30f5a465c5acb95fc527a9bfe32de0&amp;categoryName=多门冰箱&amp;pageFrom=category"
                                        class="category-3-item ">多门冰箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=95c6992834bb6015d5070fdbfd365a9b&amp;categoryName=三门冰箱&amp;pageFrom=category"
                                        class="category-3-item ">三门冰箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=098a76bd2c178518c2c4171c7c559993&amp;categoryName=双门冰箱&amp;pageFrom=category"
                                        class="category-3-item ">双门冰箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ee9c6171c4e2e9c10a1b4918dd2802e5&amp;categoryName=mini冰箱&amp;pageFrom=category"
                                        class="category-3-item ">mini冰箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d3f64d301de160c2f699aeb5c43a2792&amp;categoryName=冷柜/酒柜&amp;pageFrom=category"
                                        class="category-3-item ">冷柜/酒柜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2ba3d9c6cf3527c8ffe1d85e35c87060&amp;categoryName=大屏冰箱&amp;pageFrom=category"
                                        class="category-3-item ">大屏冰箱</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="洗衣机">洗衣机</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4e23857de9a48747a5ac4e15dceea590&amp;categoryName=洗烘一体机&amp;pageFrom=category"
                                        class="category-3-item ">洗烘一体机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e348bdc629bc1d073053fc9ce553878f&amp;categoryName=滚筒洗衣机&amp;pageFrom=category"
                                        class="category-3-item ">滚筒洗衣机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f4040b0d439b2fa75afae062efbbb71d&amp;categoryName=波轮洗衣机&amp;pageFrom=category"
                                        class="category-3-item ">波轮洗衣机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3e93b3c906b9e483950839e0f967e4c4&amp;categoryName=迷你洗衣机&amp;pageFrom=category"
                                        class="category-3-item ">迷你洗衣机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=87a705bfac211dd0128fe051cacd632e&amp;categoryName=烘干机&amp;pageFrom=category"
                                        class="category-3-item ">烘干机</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="空调">空调</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=18a68a324d15199e5f6d1cb4ebe209b2&amp;categoryName=新一级能效&amp;pageFrom=category"
                                        class="category-3-item ">新一级能效</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0a3f53c2f5a8649eeb493a8eea95012e&amp;categoryName=柜式空调&amp;pageFrom=category"
                                        class="category-3-item ">柜式空调</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1d3d8d3a8fca8b851a708d9f3b47a061&amp;categoryName=壁挂空调&amp;pageFrom=category"
                                        class="category-3-item ">壁挂空调</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="净水热水">净水热水</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ae548d94fcf41acfea3e451ddcd6a19b&amp;categoryName=净水器&amp;pageFrom=category"
                                        class="category-3-item ">净水器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8247b31c74c92db20104b05ebbd6ec55&amp;categoryName=电热水器&amp;pageFrom=category"
                                        class="category-3-item ">电热水器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6e660cb1d023854b92f95dab089f5e2c&amp;categoryName=净水耗材&amp;pageFrom=category"
                                        class="category-3-item ">净水耗材</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="大厨电">大厨电</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c5285f2f390fb234646e0681996526dd&amp;categoryName=烟灶套装&amp;pageFrom=category"
                                        class="category-3-item ">烟灶套装</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b1c799f9431db8987430d8c2cffe6e78&amp;categoryName=集成灶&amp;pageFrom=category"
                                        class="category-3-item ">集成灶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8be98ee98e3890567c42a97c7733ab9a&amp;categoryName=洗碗机&amp;pageFrom=category"
                                        class="category-3-item ">洗碗机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=afd48ba081f8197fec711beb493c9a89&amp;categoryName=燃气热水器&amp;pageFrom=category"
                                        class="category-3-item ">燃气热水器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8c4810884d2a73cfec6710cd5586c8de&amp;categoryName=嵌入式蒸烤箱&amp;pageFrom=category"
                                        class="category-3-item ">嵌入式蒸烤箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7e876fae5d31450d99e11c5887e069b8&amp;categoryName=消毒柜&amp;pageFrom=category"
                                        class="category-3-item ">消毒柜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5510626e547b50fb98295e202efba888&amp;categoryName=集成水槽&amp;pageFrom=category"
                                        class="category-3-item ">集成水槽</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=784bb0c4a3c6ec919deda0fac1a5bc12&amp;categoryName=垃圾处理器&amp;pageFrom=category"
                                        class="category-3-item ">垃圾处理器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ddc8a2cbfde9d4071fd0bd8f15fd8d51&amp;categoryName=厨电套装&amp;pageFrom=category"
                                        class="category-3-item ">厨电套装</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0c379a67c50760cdabc69c89906ed807&amp;categoryName=油烟机&amp;pageFrom=category"
                                        class="category-3-item ">油烟机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=20e7fc05bed1adf526a53089b3e1a71f&amp;categoryName=燃气灶&amp;pageFrom=category"
                                        class="category-3-item ">燃气灶</a></span></div>
                        </div>
                    </div>
                    </div> 
                <!-- block4 -->
                <li class="nav-item block4 "><span class="nav-item-span">小家电</span><span> / </span><span
                        class="nav-item-span">美食酒饮</span></li>
                    <!-- tab4 -->
                    <div class="nav-detail d4 ">
                    <div class="sub-cate-area">
                        <div class="cate-name">小家电</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="厨房小电">厨房小电</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a749caccfbbbaad74afdc2c9aae4d0c0&amp;categoryName=热卖新品&amp;pageFrom=category"
                                        class="category-3-item ">热卖新品</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6e24125cbb57f25b4911dba0af90807d&amp;categoryName=饮水机/咖啡机&amp;pageFrom=category"
                                        class="category-3-item ">饮水机/咖啡机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3ce6e59d4ef8276b0f9c94cf5dbe6512&amp;categoryName=蒸箱/烤箱&amp;pageFrom=category"
                                        class="category-3-item ">蒸箱/烤箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0c38f7b38f0d53e44c997a28d090b150&amp;categoryName=创意厨电&amp;pageFrom=category"
                                        class="category-3-item ">创意厨电</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=824c5f93c6abd7606b18e856de7c1315&amp;categoryName=电饭煲/电火锅&amp;pageFrom=category"
                                        class="category-3-item ">电饭煲/电火锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=05642c34fa76cab1c3c77259168d665d&amp;categoryName=破壁机/榨汁机&amp;pageFrom=category"
                                        class="category-3-item ">破壁机/榨汁机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ff17afe35de5bfb1d4ab2b1f4a3b7668&amp;categoryName=多用途锅&amp;pageFrom=category"
                                        class="category-3-item ">多用途锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=76355b30b4dafffea055ccbc32affe7d&amp;categoryName=微波炉/料理机&amp;pageFrom=category"
                                        class="category-3-item ">微波炉/料理机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a6a2d89e14efe338f4d90f13e6ecf6a0&amp;categoryName=养生壶/煎药壶&amp;pageFrom=category"
                                        class="category-3-item ">养生壶/煎药壶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2202a8f6d2e519866beac1308b3181fa&amp;categoryName=厨电小配件&amp;pageFrom=category"
                                        class="category-3-item ">厨电小配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="清洁电器">清洁电器</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d30ffe03589758032d5016b8a1b5e377&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=561a0962644bf47257e0a6465cc3d1be&amp;categoryName=扫地机器人&amp;pageFrom=category"
                                        class="category-3-item ">扫地机器人</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=deed22cd113270157158cb8bb8bf684b&amp;categoryName=洗地机&amp;pageFrom=category"
                                        class="category-3-item ">洗地机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f9fa666bfeebb0578afb80c3c6f2aa16&amp;categoryName=吸尘器&amp;pageFrom=category"
                                        class="category-3-item ">吸尘器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ba42b1594ab30914a9c76012ffd736e0&amp;categoryName=擦窗机器人&amp;pageFrom=category"
                                        class="category-3-item ">擦窗机器人</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5aea6f0c603c9901b34671736139d2dd&amp;categoryName=蒸汽/电动拖把&amp;pageFrom=category"
                                        class="category-3-item ">蒸汽/电动拖把</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7bb5261d3b930cf337974b22a33c93f2&amp;categoryName=除螨仪&amp;pageFrom=category"
                                        class="category-3-item ">除螨仪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=67f2f10a4813273b25181cd40725ace2&amp;categoryName=清洁机&amp;pageFrom=category"
                                        class="category-3-item ">清洁机</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="环境电器">环境电器</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fa76b54bbb1aaab7854c2547c0979000&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=71e7a735b982245d83220aef1328ba3d&amp;categoryName=空气净化器&amp;pageFrom=category"
                                        class="category-3-item ">空气净化器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c1df81cf4832b40686159192da3b87ea&amp;categoryName=加湿器&amp;pageFrom=category"
                                        class="category-3-item ">加湿器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=35f16afc4101a7b6ee05ae0f61868252&amp;categoryName=品牌风扇&amp;pageFrom=category"
                                        class="category-3-item ">品牌风扇</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=835c16738deb2d6aa2e5026837d19a71&amp;categoryName=香薰机&amp;pageFrom=category"
                                        class="category-3-item ">香薰机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ff6dd183d588a826a08711100989eafb&amp;categoryName=除湿机&amp;pageFrom=category"
                                        class="category-3-item ">除湿机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f66e92bea26513f7f010f4aa28ab3fbc&amp;categoryName=电暖器&amp;pageFrom=category"
                                        class="category-3-item ">电暖器</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="洗护工具">洗护工具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=44e98931b39dcc62297b287dbd253b27&amp;categoryName=剃须刀&amp;pageFrom=category"
                                        class="category-3-item ">剃须刀</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=90e106c1f7c47c6baaebe0b751df4585&amp;categoryName=可视采耳棒&amp;pageFrom=category"
                                        class="category-3-item ">可视采耳棒</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=92886e0819c9effa30978613cf2d3447&amp;categoryName=电吹风&amp;pageFrom=category"
                                        class="category-3-item ">电吹风</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5ba245daa5ca0ace662f1d29f97b4efe&amp;categoryName=超声波清洗机&amp;pageFrom=category"
                                        class="category-3-item ">超声波清洗机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3d45f36f53d23318757ef4b32a21d56d&amp;categoryName=鼻毛修剪器&amp;pageFrom=category"
                                        class="category-3-item ">鼻毛修剪器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4741b638cc10b3bfeb68ada79200d56c&amp;categoryName=洗手机&amp;pageFrom=category"
                                        class="category-3-item ">洗手机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e12dc22fdb014493369db7246605d8a1&amp;categoryName=理发器&amp;pageFrom=category"
                                        class="category-3-item ">理发器</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="口腔清洁">口腔清洁</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2d1f1470553a64d7a59e6492515df0a4&amp;categoryName=牙刷&amp;pageFrom=category"
                                        class="category-3-item ">牙刷</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6ba6b72c02b1e47b42148d7228f3e351&amp;categoryName=洁牙仪&amp;pageFrom=category"
                                        class="category-3-item ">洁牙仪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c8f779f5fb1bc84221495cee938c479e&amp;categoryName=冲牙器&amp;pageFrom=category"
                                        class="category-3-item ">冲牙器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3018bf75d3cd585bdbe3b8d7ae009e7c&amp;categoryName=电动牙刷头&amp;pageFrom=category"
                                        class="category-3-item ">电动牙刷头</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c3175d2faa02bd95ae94a7b5ecfbcb07&amp;categoryName=其它口腔护理产品&amp;pageFrom=category"
                                        class="category-3-item ">其它口腔护理产品</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="生活电器配件">生活电器配件</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d75de4149b5a775b2820b722ab23c462&amp;categoryName=生活电器配件&amp;pageFrom=category"
                                        class="category-3-item ">生活电器配件</a></span></div>
                        </div>
                    </div>
                    <div class="sub-cate-area">
                        <div class="cate-name">美食酒饮</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="热门精选">热门精选</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://m.youpin.mi.com/w/mifans?_rt=weex&amp;pageid=2415"
                                        class="category-3-item ">新品榜</a><a
                                        data-src="https://m.xiaomiyoupin.com/w/mifans?_rt=weex&amp;pageid=588"
                                        class="category-3-item ">热销榜</a><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal?_rt=weex&amp;pageid=6282&amp;sign=cdf9688e3b854938480e0a15d5eaf155&amp;pdl=jianyu"
                                        class="category-3-item ">酒坊</a><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal?_rt=weex&amp;pageid=11554&amp;pdl=youpin&amp;sign=f4b33b518e5c417498fcca6d0a5814e1"
                                        class="category-3-item ">茶馆</a><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal_1?_rt=weex&amp;pageid=11838&amp;pdl=youpin&amp;sign=acf8c638fb7032bfa6cb8987ca8ae75f"
                                        class="category-3-item ">原产地计划</a><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal?_rt=weex&amp;pageid=10517&amp;pdl=youpin&amp;sign=f53137e91ad28ffe665411dc2f174a19"
                                        class="category-3-item ">每日滋补</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="方便食品">方便食品</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0a9235ac661d039d9d985cc7397d5a53&amp;categoryName=方便速食&amp;pageFrom=category"
                                        class="category-3-item ">方便速食</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e11f5cb07e77f338344650ef41cb073b&amp;categoryName=方便菜&amp;pageFrom=category"
                                        class="category-3-item ">方便菜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f5a3e0c452e2db35950f78830bbabb52&amp;categoryName=轻食运动&amp;pageFrom=category"
                                        class="category-3-item ">轻食运动</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="酒水">酒水</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8ec82b4be9fb77947dbed6194748c020&amp;categoryName=白酒&amp;pageFrom=category"
                                        class="category-3-item ">白酒</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a6f8a0991370f31dca7cc4da1a253670&amp;categoryName=葡萄酒&amp;pageFrom=category"
                                        class="category-3-item ">葡萄酒</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=892601297cefd8619fc5cde981c6a782&amp;categoryName=洋酒&amp;pageFrom=category"
                                        class="category-3-item ">洋酒</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6a9739ce410a3622f049e6eac324c5e8&amp;categoryName=啤酒&amp;pageFrom=category"
                                        class="category-3-item ">啤酒</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=afa41aa6866b19d7df27e4db80d95313&amp;categoryName=黄酒/养身酒&amp;pageFrom=category"
                                        class="category-3-item ">黄酒/养身酒</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="生鲜干货">生鲜干货</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f4d71d6b859539175acac1a9b2bdc5e2&amp;categoryName=牛羊肉类&amp;pageFrom=category"
                                        class="category-3-item ">牛羊肉类</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5f89ccc43eafcb676670a823a655e500&amp;categoryName=禽肉蛋品&amp;pageFrom=category"
                                        class="category-3-item ">禽肉蛋品</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5946b3933b51ed80e123b8d96bd77521&amp;categoryName=海鲜水产&amp;pageFrom=category"
                                        class="category-3-item ">海鲜水产</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=caf3cea48ef9a21ea7c5555fd11f9572&amp;categoryName=冷冻食品&amp;pageFrom=category"
                                        class="category-3-item ">冷冻食品</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=75d183860c0db529e7decab5c00b7c5c&amp;categoryName=时令果蔬&amp;pageFrom=category"
                                        class="category-3-item ">时令果蔬</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=bbd6ce42d4df006b2ceb189f167d8cef&amp;categoryName=南北干货&amp;pageFrom=category"
                                        class="category-3-item ">南北干货</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="零食特产">零食特产</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d651ec0e5ec41136a14584dbd271d63e&amp;categoryName=休闲零食&amp;pageFrom=category"
                                        class="category-3-item ">休闲零食</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7b538293afce117fbe85cd743c6ad114&amp;categoryName=坚果炒货&amp;pageFrom=category"
                                        class="category-3-item ">坚果炒货</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=830b10e7d7832ea4bd9e1c1f0ec17ebd&amp;categoryName=饼干蛋糕&amp;pageFrom=category"
                                        class="category-3-item ">饼干蛋糕</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f0d76a4e336441dee919bafa8fd73193&amp;categoryName=熟食腊味&amp;pageFrom=category"
                                        class="category-3-item ">熟食腊味</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b0c8825102ea1d769937ff4f07787283&amp;categoryName=地方特产&amp;pageFrom=category"
                                        class="category-3-item ">地方特产</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="滋补保健">滋补保健</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e1b41da9650d3563915ceec7a02e3851&amp;categoryName=传统滋补&amp;pageFrom=category"
                                        class="category-3-item ">传统滋补</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=dcf56597099546f4be74ef0620e4f7cd&amp;categoryName=营养成分&amp;pageFrom=category"
                                        class="category-3-item ">营养成分</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="茗茶">茗茶</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=06fb19cdae50e120157b4d9f3ba19253&amp;categoryName=普洱茶&amp;pageFrom=category"
                                        class="category-3-item ">普洱茶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0b0a0a457fbfff6b15866c2f59c5260&amp;categoryName=绿茶&amp;pageFrom=category"
                                        class="category-3-item ">绿茶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d147b6da45ece41a282c15801e0e65c7&amp;categoryName=红茶&amp;pageFrom=category"
                                        class="category-3-item ">红茶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7cd43dc7b368fcec5042eeb780241ecc&amp;categoryName=黑茶/白茶&amp;pageFrom=category"
                                        class="category-3-item ">黑茶/白茶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=91424fa0522ec704eba4e66631b3f4d6&amp;categoryName=花茶/养生茶&amp;pageFrom=category"
                                        class="category-3-item ">花茶/养生茶</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="冲饮乳品">冲饮乳品</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=27017f0eec64b627fb93ddb095b3eb89&amp;categoryName=乳品冷饮&amp;pageFrom=category"
                                        class="category-3-item ">乳品冷饮</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b38eaf1e1e46b0d45df5ac0e69176b9b&amp;categoryName=冲调饮品&amp;pageFrom=category"
                                        class="category-3-item ">冲调饮品</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=67d9b681db2fa3cc502dc79ab3299bfb&amp;categoryName=饮料&amp;pageFrom=category"
                                        class="category-3-item ">饮料</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=58b05ce4b0eb7d4c6f1dac93ee2dd043&amp;categoryName=饮用水&amp;pageFrom=category"
                                        class="category-3-item ">饮用水</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="粮油调味">粮油调味</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e351f4f44f93b360cd6429e5ac0bf9d4&amp;categoryName=米面杂粮&amp;pageFrom=category"
                                        class="category-3-item ">米面杂粮</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b40a3054c2a8998b8b3d29d40f588827&amp;categoryName=调味品&amp;pageFrom=category"
                                        class="category-3-item ">调味品</a></span></div>
                        </div>
                    </div>
                    </div>    
                <!-- block5 -->
                <li class="nav-item block5 "><span class="nav-item-span">家具家装</span><span> / </span><span
                        class="nav-item-span">服装配饰</span></li>
                        <!-- tab5 -->
                        <div class="nav-detail d5 ">
                    <div class="sub-cate-area">
                        <div class="cate-name">家具家装</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="智能安防">智能安防</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=25cc804f81dd4450a5c5aa949974d3f3&amp;categoryName=摄像头&amp;pageFrom=category"
                                        class="category-3-item ">摄像头</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6a3315915d5c9693dca86beaaa51657c&amp;categoryName=智能门锁&amp;pageFrom=category"
                                        class="category-3-item ">智能门锁</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5dd0fe5b282bd8850387076650d813f4&amp;categoryName=智能门&amp;pageFrom=category"
                                        class="category-3-item ">智能门</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5eb17798e9795027b0c8ad5e1fb78dbb&amp;categoryName=猫眼&amp;pageFrom=category"
                                        class="category-3-item ">猫眼</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6861a42fd258d3a37f89a901cafc24f7&amp;categoryName=门铃&amp;pageFrom=category"
                                        class="category-3-item ">门铃</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0ba1366172d7c99ca9db10a041db18a4&amp;categoryName=保险箱/柜&amp;pageFrom=category"
                                        class="category-3-item ">保险箱/柜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c6c63c6a09d3276f3bb6f915b13dfb0d&amp;categoryName=防丢设备&amp;pageFrom=category"
                                        class="category-3-item ">防丢设备</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="卧室家具">卧室家具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8eed610d2c3b3a75625f06fe703e8fb5&amp;categoryName=床&amp;pageFrom=category"
                                        class="category-3-item ">床</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e1a0921a0940f21fd68019102132cd39&amp;categoryName=床垫&amp;pageFrom=category"
                                        class="category-3-item ">床垫</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7e363723017a7201d146d8d86149ac09&amp;categoryName=衣柜&amp;pageFrom=category"
                                        class="category-3-item ">衣柜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=484c5bc51760760fd431a73a9bc4b912&amp;categoryName=梳妆台/凳&amp;pageFrom=category"
                                        class="category-3-item ">梳妆台/凳</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="阳台家具">阳台家具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cbdb1575a460e3ad1b411ecfaa1deebe&amp;categoryName=智能晾衣架&amp;pageFrom=category"
                                        class="category-3-item ">智能晾衣架</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3e79c2d8836bcc889b63d2ab0b98a4ac&amp;categoryName=晾衣架&amp;pageFrom=category"
                                        class="category-3-item ">晾衣架</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="客厅家具">客厅家具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a116c95cd97f76de68995e47cd9f71fd&amp;categoryName=沙发&amp;pageFrom=category"
                                        class="category-3-item ">沙发</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=aef1bf0c0453c85fb7a223ba9a82b36a&amp;categoryName=边桌/茶几&amp;pageFrom=category"
                                        class="category-3-item ">边桌/茶几</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ed714b6cf099815a6be6ce1fcbe72d0d&amp;categoryName=电视柜&amp;pageFrom=category"
                                        class="category-3-item ">电视柜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=83a353d4d6b8e00759184750ddcd63b5&amp;categoryName=衣帽架&amp;pageFrom=category"
                                        class="category-3-item ">衣帽架</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5e6a25e33e95c02cf7dba8c0b5b8ef28&amp;categoryName=鞋柜&amp;pageFrom=category"
                                        class="category-3-item ">鞋柜</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="书房家具">书房家具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c1dc1ce2620eca2576962ee4a90509df&amp;categoryName=电脑椅&amp;pageFrom=category"
                                        class="category-3-item ">电脑椅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=80204319d3b97ac7223332182686da61&amp;categoryName=电脑桌&amp;pageFrom=category"
                                        class="category-3-item ">电脑桌</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e7dc587c2f7c7a1ad9fc94cf266cf7a0&amp;categoryName=书桌/书柜&amp;pageFrom=category"
                                        class="category-3-item ">书桌/书柜</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="餐厨家具">餐厨家具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8a764e31d314d8a5a234f264aa94944c&amp;categoryName=餐桌&amp;pageFrom=category"
                                        class="category-3-item ">餐桌</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="网关传感器">网关传感器</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=65903a1640de33cb904f4594c66bdc62&amp;categoryName=窗帘电机&amp;pageFrom=category"
                                        class="category-3-item ">窗帘电机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=df393e78d743a6f5c25ad84ea0262da1&amp;categoryName=网关&amp;pageFrom=category"
                                        class="category-3-item ">网关</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b4e7cc5d8104e2b0b4837e47ec11d6b1&amp;categoryName=传感器&amp;pageFrom=category"
                                        class="category-3-item ">传感器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7a30a86e688da6e2e5a027c8860b1848&amp;categoryName=智能插排&amp;pageFrom=category"
                                        class="category-3-item ">智能插排</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="儿童家具">儿童家具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d06268238a8e5d8c1aeec577e5884ba8&amp;categoryName=儿童桌椅&amp;pageFrom=category"
                                        class="category-3-item ">儿童桌椅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ba80277d08f794543afd8569129225c0&amp;categoryName=儿童床&amp;pageFrom=category"
                                        class="category-3-item ">儿童床</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3278855b172f6ff7ea58e67dfe77f557&amp;categoryName=儿童家具配件&amp;pageFrom=category"
                                        class="category-3-item ">儿童家具配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="厨房卫浴">厨房卫浴</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fe368664e875fe9d4f1b60ab08606a9d&amp;categoryName=智能马桶&amp;pageFrom=category"
                                        class="category-3-item ">智能马桶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9f9c30e9fe44e1f295232338b531a73c&amp;categoryName=浴霸&amp;pageFrom=category"
                                        class="category-3-item ">浴霸</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1c6418c1628efbcade0e519613e30015&amp;categoryName=智能马桶盖&amp;pageFrom=category"
                                        class="category-3-item ">智能马桶盖</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0686906d5d847da0734b521ad117d572&amp;categoryName=浴室镜/柜&amp;pageFrom=category"
                                        class="category-3-item ">浴室镜/柜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=eb65446df447df0225728e2157dac87d&amp;categoryName=凉霸/换气扇&amp;pageFrom=category"
                                        class="category-3-item ">凉霸/换气扇</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=54c9e94598926c10bed2474cccfee3ee&amp;categoryName=电热毛巾架&amp;pageFrom=category"
                                        class="category-3-item ">电热毛巾架</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b87acb71fd7caea4d8eddfece853b3dd&amp;categoryName=卫浴套装&amp;pageFrom=category"
                                        class="category-3-item ">卫浴套装</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f68c4fa1f9f98e76f1af2d8a1b46eccc&amp;categoryName=淋浴花洒&amp;pageFrom=category"
                                        class="category-3-item ">淋浴花洒</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5118a7faa03cc5ea052eaddb033cedfe&amp;categoryName=厨卫配件&amp;pageFrom=category"
                                        class="category-3-item ">厨卫配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=15ef62b677792492085c47c84236b949&amp;categoryName=马桶&amp;pageFrom=category"
                                        class="category-3-item ">马桶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=be89d175e555d5e2f19f32bdb68792cc&amp;categoryName=龙头&amp;pageFrom=category"
                                        class="category-3-item ">龙头</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=94d2e09848ec9c6edd73602b01609bf3&amp;categoryName=水槽&amp;pageFrom=category"
                                        class="category-3-item ">水槽</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e078f77fa1ea62a5d4adc30d21dfa990&amp;categoryName=置物挂件&amp;pageFrom=category"
                                        class="category-3-item ">置物挂件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0d36fc28d091a50eac49e5609a583959&amp;categoryName=淋浴房&amp;pageFrom=category"
                                        class="category-3-item ">淋浴房</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e7bfd6ef943eb3aeed2c83039380a7de&amp;categoryName=地漏&amp;pageFrom=category"
                                        class="category-3-item ">地漏</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d8a61675886e422148a9f395f37bf01e&amp;categoryName=浴缸&amp;pageFrom=category"
                                        class="category-3-item ">浴缸</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="装修材料">装修材料</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8e18ea9baf7481ab2ee1092b30889529&amp;categoryName=地板/地砖&amp;pageFrom=category"
                                        class="category-3-item ">地板/地砖</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=47584a07aee2e79823c21957c6a6e4ab&amp;categoryName=吊顶&amp;pageFrom=category"
                                        class="category-3-item ">吊顶</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="顶吊灯">顶吊灯</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=18a4a711b777b7fb2fbd69a79e00f327&amp;categoryName=客卧吸顶灯&amp;pageFrom=category"
                                        class="category-3-item ">客卧吸顶灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c3b218084972a0e53e64bbee31ca66dd&amp;categoryName=风扇灯&amp;pageFrom=category"
                                        class="category-3-item ">风扇灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=bfcb66cf5ea1ae0b0673462c7ff0cd9f&amp;categoryName=吊灯&amp;pageFrom=category"
                                        class="category-3-item ">吊灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0dc966cb0e3570757d080cdcf3130485&amp;categoryName=厨卫/阳台/玄关/过道灯&amp;pageFrom=category"
                                        class="category-3-item ">厨卫/阳台/玄关/过道灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4399cb1e09081a42a4ca7b2caf9843b0&amp;categoryName=面板灯&amp;pageFrom=category"
                                        class="category-3-item ">面板灯</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="家居类灯饰">家居类灯饰</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=817887b5dbaa7b725b4b622ddc427945&amp;categoryName=台灯&amp;pageFrom=category"
                                        class="category-3-item ">台灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e9f16344f4b45491f1c7e0ceb2118164&amp;categoryName=壁灯&amp;pageFrom=category"
                                        class="category-3-item ">壁灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=924135bac19779dd6ab2b3357f029f7c&amp;categoryName=橱柜灯&amp;pageFrom=category"
                                        class="category-3-item ">橱柜灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a863875b87391c56c9e1139e0e5e66b6&amp;categoryName=落地灯&amp;pageFrom=category"
                                        class="category-3-item ">落地灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d7679cc7048e7f0793a69b697ebfed84&amp;categoryName=氛围照明&amp;pageFrom=category"
                                        class="category-3-item ">氛围照明</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f6033254ae33a63ece96cb97388218ce&amp;categoryName=室外/庭院灯&amp;pageFrom=category"
                                        class="category-3-item ">室外/庭院灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d3b8be9aeec619dbd67ba6eec1a09f0c&amp;categoryName=镜前灯&amp;pageFrom=category"
                                        class="category-3-item ">镜前灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=eb5f7afd28fbd4fb0b329e566f58bf86&amp;categoryName=LED灯源&amp;pageFrom=category"
                                        class="category-3-item ">LED灯源</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="功能性照明">功能性照明</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a2232c9a89a4fe1f3bd3294689143c06&amp;categoryName=杀菌/消毒灯&amp;pageFrom=category"
                                        class="category-3-item ">杀菌/消毒灯</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="无主灯照明">无主灯照明</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9b71532d43330940464bdfeb9ef9409a&amp;categoryName=筒灯/射灯&amp;pageFrom=category"
                                        class="category-3-item ">筒灯/射灯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e2dc330fff49b07a9eaeafaa70112fe8&amp;categoryName=灯带&amp;pageFrom=category"
                                        class="category-3-item ">灯带</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=024bbd6828dfb413a464db8ad9d123fa&amp;categoryName=轨道灯&amp;pageFrom=category"
                                        class="category-3-item ">轨道灯</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="电工电料">电工电料</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4ffbf5803361fe9b1254d7c56641d766&amp;categoryName=开关插座&amp;pageFrom=category"
                                        class="category-3-item ">开关插座</a></span></div>
                        </div>
                    </div>
                    <div class="sub-cate-area">
                        <div class="cate-name">服装配饰</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="应季热销">应季热销</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=166441"
                                        class="category-3-item ">超轻防晒衣</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=166827"
                                        class="category-3-item ">凉感速干裤</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=164670"
                                        class="category-3-item ">拾柒棉T恤</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="男士上衣">男士上衣</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c01fe1566ce95029363b9870b4a8f0be&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e85041e6c3a5985c0f96daedd6993791&amp;categoryName=T恤/POLO&amp;pageFrom=category"
                                        class="category-3-item ">T恤/POLO</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0ed4bdfb0f98e86865ba34b5c1395016&amp;categoryName=夹克/风衣&amp;pageFrom=category"
                                        class="category-3-item ">夹克/风衣</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b0fc83b1d4ffe5893e9e64603078b65a&amp;categoryName=卫衣&amp;pageFrom=category"
                                        class="category-3-item ">卫衣</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5b26d1d128805359c05101fd5d013757&amp;categoryName=衬衫&amp;pageFrom=category"
                                        class="category-3-item ">衬衫</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6c32582921f201f905970d7969275e28&amp;categoryName=羽绒服/棉服&amp;pageFrom=category"
                                        class="category-3-item ">羽绒服/棉服</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="男士裤装">男士裤装</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d7c86bab17fbee26b4790aaa329cf0d9&amp;categoryName=休闲裤&amp;pageFrom=category"
                                        class="category-3-item ">休闲裤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=900bd0acb2c3b1f7175f93341aa133e3&amp;categoryName=牛仔裤&amp;pageFrom=category"
                                        class="category-3-item ">牛仔裤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fd67d7cadc00164300465da320ed8f99&amp;categoryName=短裤&amp;pageFrom=category"
                                        class="category-3-item ">短裤</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="男士内衣">男士内衣</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b618616efb7d32c2222df2c80e59a544&amp;categoryName=男士内裤&amp;pageFrom=category"
                                        class="category-3-item ">男士内裤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c565585090a02012a13216d895c751f9&amp;categoryName=男士袜子&amp;pageFrom=category"
                                        class="category-3-item ">男士袜子</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=508ed58b1b3724ea46ae079b2ec146ab&amp;categoryName=保暖内衣&amp;pageFrom=category"
                                        class="category-3-item ">保暖内衣</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="运动服饰">运动服饰</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1cf970f643eb7e9f47478ff9d51b51c8&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ffbe2ee89857a4290f3df2bd723751ed&amp;categoryName=运动裤&amp;pageFrom=category"
                                        class="category-3-item ">运动裤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b814cf15186f3aee7788db331670fa50&amp;categoryName=运动T恤&amp;pageFrom=category"
                                        class="category-3-item ">运动T恤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c7cbbf569b5ac9d052856dbedf364210&amp;categoryName=软壳衣裤&amp;pageFrom=category"
                                        class="category-3-item ">软壳衣裤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cd0f9038a204d8bb3316a9416a5fa64c&amp;categoryName=卫衣/外套&amp;pageFrom=category"
                                        class="category-3-item ">卫衣/外套</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e6b971d0beb8aef7a1518db30195055b&amp;categoryName=户外服饰&amp;pageFrom=category"
                                        class="category-3-item ">户外服饰</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="眼镜">眼镜</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9ca45b20b193b8068524151093af9a30&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=91717f498ed6b8fd57b77b07e4ab0696&amp;categoryName=近视镜&amp;pageFrom=category"
                                        class="category-3-item ">近视镜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6fa24c7d45097af0958336b4a1268bc6&amp;categoryName=太阳镜&amp;pageFrom=category"
                                        class="category-3-item ">太阳镜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=02ed268afb25d70cada3bac48cb4941d&amp;categoryName=防蓝光&amp;pageFrom=category"
                                        class="category-3-item ">防蓝光</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="配饰">配饰</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a659d82f44636abe061173d74f1790e2&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=71fe508dc75076847de34ff6ff463605&amp;categoryName=皮带&amp;pageFrom=category"
                                        class="category-3-item ">皮带</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=afd797946b4cd68041f61db75a6f1d18&amp;categoryName=帽子&amp;pageFrom=category"
                                        class="category-3-item ">帽子</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="儿童服饰">儿童服饰</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list "><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=10ba45fa4aa8acfb32f11b3af2c9879a&amp;categoryName=童装&amp;pageFrom=category"
                                        class="category-3-item ">童装</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=47dc1987dc3c138e6570275389c0328f&amp;categoryName=童鞋&amp;pageFrom=category"
                                        class="category-3-item ">童鞋</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b37d3adba31e35e77657746e7be70fd9&amp;categoryName=童包&amp;pageFrom=category"
                                        class="category-3-item ">童包</a></span></div>
                        </div>
                    </div>
                        </div>  
                <!-- block6 -->
                <li class="nav-item block6 "><span class="nav-item-span">日常元素</span><span> / </span><span
                        class="nav-item-span">有品海购</span></li>
                        <!-- tab6 -->
                        <div class="nav-detail d6 ">
                    <div class="sub-cate-area">
                        <div class="cate-name">日常元素</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="人气上新">人气上新</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=163417"
                                        class="category-3-item ">气垫梳</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=159810"
                                        class="category-3-item ">车载香氛</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=162935"
                                        class="category-3-item ">湿厕纸</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=158814"
                                        class="category-3-item ">纸面巾</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=157759"
                                        class="category-3-item ">白板笔</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=152797"
                                        class="category-3-item ">男士内裤</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="热销榜单">热销榜单</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=160915"
                                        class="category-3-item ">超柔鼻用纸</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=144567"
                                        class="category-3-item ">清洁湿巾</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=156012"
                                        class="category-3-item ">拖鞋</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="精选好物">精选好物</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=160360"
                                        class="category-3-item ">防蛀牙膏</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=160212"
                                        class="category-3-item ">精油棒</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=154959"
                                        class="category-3-item ">蒸汽眼罩</a></span></div>
                        </div>
                    </div>
                    <div class="sub-cate-area">
                        <div class="cate-name">有品海购</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="热门精选">热门精选</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://app.xiaomiyoupin.com/search_category?apppagefrom=category&amp;queryId=9011e6bb26bc118f23e48d6c70a63bd4"
                                        class="category-3-item ">游戏数码</a><a
                                        data-src="https://app.xiaomiyoupin.com/search_category?apppagefrom=category&amp;queryId=c1673459c055f1069c5352efba57ddee"
                                        class="category-3-item ">大牌美妆</a><a
                                        data-src="https://app.xiaomiyoupin.com/search_category?apppagefrom=category&amp;queryId=1da8fa31e48b893c91d40be1b14e9668"
                                        class="category-3-item ">补肾固元</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="美妆个护">美妆个护</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1badcc90b07012427cf0fe265279ebf5&amp;categoryName=爽肤水&amp;pageFrom=category"
                                        class="category-3-item ">爽肤水</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c1673459c055f1069c5352efba57ddee&amp;categoryName=套装/礼盒&amp;pageFrom=category"
                                        class="category-3-item ">套装/礼盒</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=685ef1e2f1a3efc12862b6197e0cf653&amp;categoryName=卸妆洁面&amp;pageFrom=category"
                                        class="category-3-item ">卸妆洁面</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e3c6ea5a199b456e7de062516775ddb8&amp;categoryName=乳液面霜&amp;pageFrom=category"
                                        class="category-3-item ">乳液面霜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1d7c48b96bb034d44217ba84dd0fbf97&amp;categoryName=面部精华&amp;pageFrom=category"
                                        class="category-3-item ">面部精华</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=822a8a1e05a2b33023ca56b2cfa4bdd6&amp;categoryName=眼霜/眼膜&amp;pageFrom=category"
                                        class="category-3-item ">眼霜/眼膜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4a8de8f5efac3b04fe4e2e7d280b1db5&amp;categoryName=香水&amp;pageFrom=category"
                                        class="category-3-item ">香水</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6493cfd060e7b86df5770084c73344bf&amp;categoryName=口红/唇膏/唇釉&amp;pageFrom=category"
                                        class="category-3-item ">口红/唇膏/唇釉</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=48f85feaf5cda4eed6540bd3ac352f8d&amp;categoryName=洗发护发&amp;pageFrom=category"
                                        class="category-3-item ">洗发护发</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="健康饮食">健康饮食</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=077c109a511d2485fba5dd7ca19f5127&amp;categoryName=保肝利胆&amp;pageFrom=category"
                                        class="category-3-item ">保肝利胆</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0ca4f1995080d3c9e4fdc0c2cda3e170&amp;categoryName=增强免疫&amp;pageFrom=category"
                                        class="category-3-item ">增强免疫</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=aa41207fa579a8a988d0ec2e1a3839c6&amp;categoryName=调节三高&amp;pageFrom=category"
                                        class="category-3-item ">调节三高</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5ceec8cedc53aca6db4886b5e19d2936&amp;categoryName=骨骼健康&amp;pageFrom=category"
                                        class="category-3-item ">骨骼健康</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=548222f0b6649ac3f2dde62c944ab467&amp;categoryName=减肥瘦身&amp;pageFrom=category"
                                        class="category-3-item ">减肥瘦身</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c8e5ed7f9974814ef71bce64a14566d4&amp;categoryName=明目益智&amp;pageFrom=category"
                                        class="category-3-item ">明目益智</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="母婴亲子">母婴亲子</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c770f7bb768bc0780d2d6401c696589a&amp;categoryName=成人奶粉&amp;pageFrom=category"
                                        class="category-3-item ">成人奶粉</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d1a7b192a58970cdec98c218444d4883&amp;categoryName=营养辅食&amp;pageFrom=category"
                                        class="category-3-item ">营养辅食</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=87f54bd73c3c30ff0cada27fe4008128&amp;categoryName=爱他美&amp;pageFrom=category"
                                        class="category-3-item ">爱他美</a></span></div>
                        </div>
                    </div>
                        </div>   
                <!-- block7 -->
                <li class="nav-item block7 "><span class="nav-item-span">手表首饰</span><span> / </span><span
                        class="nav-item-span">出行车品</span></li>
                        <!-- tab7 -->
                        <div class="nav-detail d7 ">
                    <div class="sub-cate-area">
                        <div class="cate-name">手表首饰</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="配饰上新">配饰上新</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2cf460ea0aeb414befb352885a55e4b0&amp;categoryName=新品珠宝&amp;pageFrom=category"
                                        class="category-3-item ">新品珠宝</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cbbec3f2c76d790b662b9f0fa4295056&amp;categoryName=手表上新&amp;pageFrom=category"
                                        class="category-3-item ">手表上新</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9aa111100c49ce1ffceb408009e53656&amp;categoryName=首饰上新&amp;pageFrom=category"
                                        class="category-3-item ">首饰上新</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="金银投资">金银投资</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e7354dbcc16bf942e0d41c7b5aba2dd2&amp;categoryName=投资金&amp;pageFrom=category"
                                        class="category-3-item ">投资金</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=defcd074accf391492ca6feac5feee70&amp;categoryName=投资藏品&amp;pageFrom=category"
                                        class="category-3-item ">投资藏品</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="黄金">黄金</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=acae341d93e4c403ac6771498df59f8d&amp;categoryName=黄金吊坠&amp;pageFrom=category"
                                        class="category-3-item ">黄金吊坠</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=05be89a5886d5732e0f3be197d2e7e44&amp;categoryName=黄金转运珠&amp;pageFrom=category"
                                        class="category-3-item ">黄金转运珠</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9a2a3fe21ccf4a6f5f3ad3b39d580747&amp;categoryName=黄金项链&amp;pageFrom=category"
                                        class="category-3-item ">黄金项链</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b9eea207734b3f98ce39e0e13165d24a&amp;categoryName=黄金手镯/手链/脚链&amp;pageFrom=category"
                                        class="category-3-item ">黄金手镯/手链/脚链</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=df87fc89be0ae8a5ed0b591426cfc709&amp;categoryName=黄金戒指&amp;pageFrom=category"
                                        class="category-3-item ">黄金戒指</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b2464cb4b744c405e3bc9e003fc64cd3&amp;categoryName=黄金耳饰&amp;pageFrom=category"
                                        class="category-3-item ">黄金耳饰</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="K金铂金">K金铂金</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3a833ba612894dee0b82d2cc4ad5f6ee&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=65748c5236d86d84d07792dd5c772e45&amp;categoryName=K金吊坠&amp;pageFrom=category"
                                        class="category-3-item ">K金吊坠</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="钻石">钻石</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6d412c05d19d6f5fa64e6b691148bd88&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b23f5ab03f62f9eda491b8ef7163060c&amp;categoryName=钻石项链/吊坠&amp;pageFrom=category"
                                        class="category-3-item ">钻石项链/吊坠</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fd6fe1926530cc26880276674b5f3e7e&amp;categoryName= 钻戒&amp;pageFrom=category"
                                        class="category-3-item "> 钻戒</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="翡翠玉石">翡翠玉石</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9f3507de40530810c98d5f6ddab0ad5d&amp;categoryName=翡翠吊坠&amp;pageFrom=category"
                                        class="category-3-item ">翡翠吊坠</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1be8702e8ada414a4b5bf1f0d22a1bad&amp;categoryName=和田玉吊坠&amp;pageFrom=category"
                                        class="category-3-item ">和田玉吊坠</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8814c33c942b6281a572d3a8faf12e87&amp;categoryName=和田玉手镯&amp;pageFrom=category"
                                        class="category-3-item ">和田玉手镯</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="木手串/把件">木手串/把件</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=396eb1258d1c44dadfc567db23d8d6b3&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0106426981bb0882c2bf6120a2aaddb9&amp;categoryName=小叶紫檀&amp;pageFrom=category"
                                        class="category-3-item ">小叶紫檀</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=77b6169d201bb80bc32d3edde2a487f2&amp;categoryName=菩提&amp;pageFrom=category"
                                        class="category-3-item ">菩提</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="银饰">银饰</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5634e1764a2d5622e05e1d2504755108&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=bf306dea068d5f46c901c8cea82a426d&amp;categoryName=银吊坠/项链&amp;pageFrom=category"
                                        class="category-3-item ">银吊坠/项链</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b466113198c9b2e2e9b8019ab0cbf311&amp;categoryName= 银耳饰&amp;pageFrom=category"
                                        class="category-3-item "> 银耳饰</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="水晶玛瑙">水晶玛瑙</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e18aa590ad5a6658bdc5347ecae9618e&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=efbd21398ff5863128b987803f449a6e&amp;categoryName=黑曜石&amp;pageFrom=category"
                                        class="category-3-item ">黑曜石</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c1ad9d8407690c24e7cec40824b89170&amp;categoryName=水晶&amp;pageFrom=category"
                                        class="category-3-item ">水晶</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="机械表">机械表</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3027ba7b3bccc390297b64474cb2cbbf&amp;categoryName=陀飞轮&amp;pageFrom=category"
                                        class="category-3-item ">陀飞轮</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cdcc79b9362169573500ef74fb6938a0&amp;categoryName=镂空&amp;pageFrom=category"
                                        class="category-3-item ">镂空</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fde832fada4e401c107da2caa8267873&amp;categoryName=商务&amp;pageFrom=category"
                                        class="category-3-item ">商务</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7d91fa544d9610519b51bc79c47a295f&amp;categoryName=夜光&amp;pageFrom=category"
                                        class="category-3-item ">夜光</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e78739b8adc095d43aa8c3a61a99896a&amp;categoryName=防水&amp;pageFrom=category"
                                        class="category-3-item ">防水</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=33fcf66590013ba1fb211d9587485fcd&amp;categoryName=IP联名&amp;pageFrom=category"
                                        class="category-3-item ">IP联名</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=200d105d7f4d71502876885171aff9e0&amp;categoryName=礼盒&amp;pageFrom=category"
                                        class="category-3-item ">礼盒</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=238c8deafd8cd122e81e5abf9c938027&amp;categoryName=休闲&amp;pageFrom=category"
                                        class="category-3-item ">休闲</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="石英表">石英表</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=10d14d17fbe879a81d7bf7e6e5f7c7e4&amp;categoryName=简约&amp;pageFrom=category"
                                        class="category-3-item ">简约</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=319c877d74528d7e420985dfc45013d1&amp;categoryName=时尚休闲&amp;pageFrom=category"
                                        class="category-3-item ">时尚休闲</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=affbf266cf0909de85177e15b91b77b1&amp;categoryName=商务&amp;pageFrom=category"
                                        class="category-3-item ">商务</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e00f51f76f4f213a759d5ca8966c546a&amp;categoryName=礼盒&amp;pageFrom=category"
                                        class="category-3-item ">礼盒</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="手表大牌">手表大牌</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2a7b3df7e0cd5cd8b7c64d7cb4e8d351&amp;categoryName=国货经典&amp;pageFrom=category"
                                        class="category-3-item ">国货经典</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=28878f4032f52c8c7c89cf83ec79f651&amp;categoryName=欧美时尚&amp;pageFrom=category"
                                        class="category-3-item ">欧美时尚</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a7a4fba01cdc82377c9a485d587ee5dc&amp;categoryName=日韩潮流&amp;pageFrom=category"
                                        class="category-3-item ">日韩潮流</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="品牌推荐">品牌推荐</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f15f97430fe8f0ea711bcf993eb8c834&amp;categoryName=周大福&amp;pageFrom=category"
                                        class="category-3-item ">周大福</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f47a3da7d22754fe09b5f520e23e740f&amp;categoryName=周大生&amp;pageFrom=category"
                                        class="category-3-item ">周大生</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=81962b16f0a8ba56dae444719ffa3d2e&amp;categoryName=佐卡伊&amp;pageFrom=category"
                                        class="category-3-item ">佐卡伊</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=eea7564e252d956dc1ee3e985cc7e39c&amp;categoryName=海盗船&amp;pageFrom=category"
                                        class="category-3-item ">海盗船</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4e77eccc7d86615e6dafb3aaabc216f7&amp;categoryName=玺佳&amp;pageFrom=category"
                                        class="category-3-item ">玺佳</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fe1129be1152505c4a5d4473ccb1ca34&amp;categoryName=西铁城&amp;pageFrom=category"
                                        class="category-3-item ">西铁城</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=408ec2497a3b95c2021ccd282872ada8&amp;categoryName=JEEP &amp;pageFrom=category"
                                        class="category-3-item ">JEEP </a></span></div>
                        </div>
                    </div>
                    <div class="sub-cate-area">
                        <div class="cate-name">出行车品</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="热门精选">热门精选</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal?_rt=weex&amp;pageid=12672&amp;pdl=youpin&amp;sign=a3581a6c1fe0bf8a89bf79f4b4704ab5"
                                        class="category-3-item ">骑行配件</a><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal_1?_rt=weex&amp;pageid=9274&amp;sign=00a66911727f8b3ab81a9e520d582152&amp;pdl=jianyu"
                                        class="category-3-item ">踏青春游</a><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal?_rt=weex&amp;pageid=13265&amp;pdl=youpin&amp;sign=0edb0b2bad5bbd3f3f3bc86de98b44ed"
                                        class="category-3-item ">汽车用品</a><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal?_rt=weex&amp;pageid=7154&amp;sign=d18cbce594341f36b8f8590c708d2d63&amp;pdl=jianyu"
                                        class="category-3-item ">日常出行</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="骑行">骑行</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2621788b8a7e2adcafb20c8a914873fd&amp;categoryName=折叠电动车&amp;pageFrom=category"
                                        class="category-3-item ">折叠电动车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d0bb7bd6635f23288dd2fc39269579a6&amp;categoryName=公路自行车&amp;pageFrom=category"
                                        class="category-3-item ">公路自行车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ad3023b141d53f54ba4cdd920db5c328&amp;categoryName=电动自行车&amp;pageFrom=category"
                                        class="category-3-item ">电动自行车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=72d84ecaa045e18430e1ddd852f5892f&amp;categoryName=童车&amp;pageFrom=category"
                                        class="category-3-item ">童车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=243ca4f87be9e27af726684c596ba124&amp;categoryName=平衡车&amp;pageFrom=category"
                                        class="category-3-item ">平衡车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3a5720b698012156cb4148f7f223973b&amp;categoryName=山地自行车&amp;pageFrom=category"
                                        class="category-3-item ">山地自行车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0fac44dba71a207547dc1703f20417f1&amp;categoryName=滑板车&amp;pageFrom=category"
                                        class="category-3-item ">滑板车</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="车载电器">车载电器</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3e5c666b80784a38b8a273d54bd5eca4&amp;categoryName=行车记录仪&amp;pageFrom=category"
                                        class="category-3-item ">行车记录仪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5ac68f9d0501ec754f6579e3040f4f74&amp;categoryName=车载净化器&amp;pageFrom=category"
                                        class="category-3-item ">车载净化器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cf5ff63d65bbe52cc7e05ac03073c259&amp;categoryName=车充&amp;pageFrom=category"
                                        class="category-3-item ">车充</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8a8e6b79582e322343ad207f168e475c&amp;categoryName=HUD&amp;pageFrom=category"
                                        class="category-3-item ">HUD</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c76a489d34e68806598f99b28aa1b3c7&amp;categoryName=车载冰箱&amp;pageFrom=category"
                                        class="category-3-item ">车载冰箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cf78cf1315a137b99e65597aac19ba70&amp;categoryName=电子后视镜&amp;pageFrom=category"
                                        class="category-3-item ">电子后视镜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=edb90cac6495e03039b0e8cadca1d718&amp;categoryName=电动汽车配件&amp;pageFrom=category"
                                        class="category-3-item ">电动汽车配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=bfaea3f792844241fa6b3896f9a303b6&amp;categoryName=车载生活电器&amp;pageFrom=category"
                                        class="category-3-item ">车载生活电器</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="保养清洁">保养清洁</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=aa7c854b7dba18f38fc86865279ab97c&amp;categoryName=清洗机&amp;pageFrom=category"
                                        class="category-3-item ">清洗机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=81037942be04101afcc20cb4883ccf88&amp;categoryName=洗车水枪&amp;pageFrom=category"
                                        class="category-3-item ">洗车水枪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e991a4b4acfac08d0a35a90386302635&amp;categoryName=燃油添加剂&amp;pageFrom=category"
                                        class="category-3-item ">燃油添加剂</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7644b3dc4715b3ad2a4a1d58d809e9c0&amp;categoryName=洗车配件&amp;pageFrom=category"
                                        class="category-3-item ">洗车配件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d2248db39a2e0870c58f316580859903&amp;categoryName=洗车液/清洁剂&amp;pageFrom=category"
                                        class="category-3-item ">洗车液/清洁剂</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=861f9f068b4c3d7c64861a47d327fe18&amp;categoryName=玻璃水&amp;pageFrom=category"
                                        class="category-3-item ">玻璃水</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c524da4f2733f40ee1bd67a2a1785fde&amp;categoryName=防雨剂/驱水剂&amp;pageFrom=category"
                                        class="category-3-item ">防雨剂/驱水剂</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d62bd722a933322e48d82eb6aca4699a&amp;categoryName=镀晶镀膜&amp;pageFrom=category"
                                        class="category-3-item ">镀晶镀膜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=493073ed9c8c17b35e2dddaea30ca376&amp;categoryName=车蜡&amp;pageFrom=category"
                                        class="category-3-item ">车蜡</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9b1223bc688af75ef5d1a9470423a90a&amp;categoryName=车内/空调除菌剂&amp;pageFrom=category"
                                        class="category-3-item ">车内/空调除菌剂</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="汽车装饰">汽车装饰</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=19044f2303536455209f5e694c6a2914&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=961d0961357872523b54472fc9ec1187&amp;categoryName=手机支架&amp;pageFrom=category"
                                        class="category-3-item ">手机支架</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=adbc45291e9af185f0f71bab7fa1eafe&amp;categoryName=汽车脚垫&amp;pageFrom=category"
                                        class="category-3-item ">汽车脚垫</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4f7e32ee29bb3a46017bc930dc987c7f&amp;categoryName=颈枕腰靠&amp;pageFrom=category"
                                        class="category-3-item ">颈枕腰靠</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ffc7d82f79c9f8c9c16303ba7a79fc7c&amp;categoryName=汽车坐垫&amp;pageFrom=category"
                                        class="category-3-item ">汽车坐垫</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8f613f62518ee5675c06c000fefab2ed&amp;categoryName=车载香薰&amp;pageFrom=category"
                                        class="category-3-item ">车载香薰</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2b2b8daac4913ef48cf035b97006030a&amp;categoryName=方向盘套&amp;pageFrom=category"
                                        class="category-3-item ">方向盘套</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2ee40d6e0b97bba9da2cdb45782e7379&amp;categoryName=后备箱垫&amp;pageFrom=category"
                                        class="category-3-item ">后备箱垫</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=dc690c7f9580e3a99cf1ebad4161b003&amp;categoryName=停车牌&amp;pageFrom=category"
                                        class="category-3-item ">停车牌</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f11602ba5c29950aeb7c1895a54f6d40&amp;categoryName=车内用品&amp;pageFrom=category"
                                        class="category-3-item ">车内用品</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="安全自驾">安全自驾</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=969b7c651f22b2bd8eacee8cbf1047f2&amp;categoryName=充气泵&amp;pageFrom=category"
                                        class="category-3-item ">充气泵</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e0faa23d2a039930d5264f831de9d719&amp;categoryName=应急启动电源&amp;pageFrom=category"
                                        class="category-3-item ">应急启动电源</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=039f7779bb7223a349a2ea88c385b97a&amp;categoryName=安全座椅&amp;pageFrom=category"
                                        class="category-3-item ">安全座椅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e5a2a60e3b2f0118940a3c60dd2219d5&amp;categoryName=胎压监测&amp;pageFrom=category"
                                        class="category-3-item ">胎压监测</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0c9ea2038e9309f3f75b99253dbf5165&amp;categoryName=安全锤&amp;pageFrom=category"
                                        class="category-3-item ">安全锤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4f282d051a855549793f6ecc00b1b29f&amp;categoryName=自驾野营&amp;pageFrom=category"
                                        class="category-3-item ">自驾野营</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="骑行配件">骑行配件</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7fe051b19598775bff7e3fd32a9cb262&amp;categoryName=头盔/护具&amp;pageFrom=category"
                                        class="category-3-item ">头盔/护具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1b4d5b6c12b5bfe3d76afa91de512e77&amp;categoryName=车锁&amp;pageFrom=category"
                                        class="category-3-item ">车锁</a></span></div>
                        </div>
                    </div>
                        </div>  
                <!-- block8 -->
                <li class="nav-item block8 "><span class="nav-item-span">家纺厨具</span><span> / </span><span
                        class="nav-item-span">美妆个护</span></li>
                        <!-- tab8 -->
                        <div class="nav-detail d8 ">
                    <div class="sub-cate-area">
                        <div class="cate-name">家纺厨具</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="热门精选">热门精选</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=166407"
                                        class="category-3-item ">硅胶凉席夏被</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=165928"
                                        class="category-3-item ">透气乳胶枕</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=166250"
                                        class="category-3-item ">简约抗菌件套</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=159819"
                                        class="category-3-item ">无涂层炒锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=159286"
                                        class="category-3-item ">纯钛保温杯</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=161862&amp;"
                                        class="category-3-item ">煮茶提梁壶</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="水杯">水杯</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7c75e4f691bebdd5d1b80294a0165d23&amp;categoryName=保温杯&amp;pageFrom=category"
                                        class="category-3-item ">保温杯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9ff449a96177e9583bea7f330aabc7a2&amp;categoryName=保温壶&amp;pageFrom=category"
                                        class="category-3-item ">保温壶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1084b103359885d5e4244fa9d7b518b2&amp;categoryName=泡茶杯&amp;pageFrom=category"
                                        class="category-3-item ">泡茶杯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=756c6353e76daf84a04768589553b80c&amp;categoryName=运动杯&amp;pageFrom=category"
                                        class="category-3-item ">运动杯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=22ce1c0c559d213ecb30d12937b9b5eb&amp;categoryName=马克杯&amp;pageFrom=category"
                                        class="category-3-item ">马克杯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c8ec483b01f3cc732ebff7e7edd0580e&amp;categoryName=杯具套装&amp;pageFrom=category"
                                        class="category-3-item ">杯具套装</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="锅">锅</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c88254ad6dee31128ea9f6c864f98288&amp;categoryName=炒锅&amp;pageFrom=category"
                                        class="category-3-item ">炒锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8d975fef17aed547dde7cbef733b2114&amp;categoryName=汤锅&amp;pageFrom=category"
                                        class="category-3-item ">汤锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3d36733e7c399df36db2bf41d08e387f&amp;categoryName=煎锅&amp;pageFrom=category"
                                        class="category-3-item ">煎锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6db14952e38c10e652acc260763f17c0&amp;categoryName=蒸锅&amp;pageFrom=category"
                                        class="category-3-item ">蒸锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6b60c13dece05f6d347d29a0be4305d3&amp;categoryName=砂锅&amp;pageFrom=category"
                                        class="category-3-item ">砂锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a7430d2eb22fff7ebbbb9461096e40b9&amp;categoryName=平底锅&amp;pageFrom=category"
                                        class="category-3-item ">平底锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=bee0e2b270a6aaac6ad6cd3c97c59899&amp;categoryName=高压锅&amp;pageFrom=category"
                                        class="category-3-item ">高压锅</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4720a80bd876ec47ebb0673a8fc6438a&amp;categoryName=锅具套装&amp;pageFrom=category"
                                        class="category-3-item ">锅具套装</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="枕头">枕头</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=94084fa6543c24c71c606db4e8f70084&amp;categoryName=智能枕&amp;pageFrom=category"
                                        class="category-3-item ">智能枕</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f821a88c6d81f6e239df0ce8873e6713&amp;categoryName=乳胶枕&amp;pageFrom=category"
                                        class="category-3-item ">乳胶枕</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=43efbb5fd82f58c3fbf01b079302ce9e&amp;categoryName=纤维枕&amp;pageFrom=category"
                                        class="category-3-item ">纤维枕</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=18251266144898082be81e0ddce03cff&amp;categoryName=记忆枕&amp;pageFrom=category"
                                        class="category-3-item ">记忆枕</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=266954689678d59df2091cf2a6d594ae&amp;categoryName=羽绒枕&amp;pageFrom=category"
                                        class="category-3-item ">羽绒枕</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d14c6a39ef5c75d672b06281c33a4bfd&amp;categoryName=可水洗枕&amp;pageFrom=category"
                                        class="category-3-item ">可水洗枕</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=80c624e9eb602971e97fad677ffe9324&amp;categoryName=新材质枕&amp;pageFrom=category"
                                        class="category-3-item ">新材质枕</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c1a466ba4fd086a904cffeb528117f45&amp;categoryName=U形枕&amp;pageFrom=category"
                                        class="category-3-item ">U形枕</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="被子">被子</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c390910e1a7e0e647bfe82af2deed4ac&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=12e47fa5d0f2e3ce85b115bac9971827&amp;categoryName=纤维被&amp;pageFrom=category"
                                        class="category-3-item ">纤维被</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=86ce9fbdbc09d977320d4d423c908007&amp;categoryName=蚕丝被&amp;pageFrom=category"
                                        class="category-3-item ">蚕丝被</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=626fb13bed85d47a2f6b375c5d25a4a7&amp;categoryName=羽绒被&amp;pageFrom=category"
                                        class="category-3-item ">羽绒被</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=20e1b3196e44e8826b4035ac6074e07b&amp;categoryName=棉花被&amp;pageFrom=category"
                                        class="category-3-item ">棉花被</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="家纺">家纺</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ebaaba96a7d03af624f6a055747a9192&amp;categoryName=床品件套&amp;pageFrom=category"
                                        class="category-3-item ">床品件套</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=645c5affa5664e2aa028977db951627f&amp;categoryName=毛巾浴巾&amp;pageFrom=category"
                                        class="category-3-item ">毛巾浴巾</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e15433571b534fad09a5b67097f25708&amp;categoryName=地毯&amp;pageFrom=category"
                                        class="category-3-item ">地毯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8dd4901ea661655c955b71bd699ece65&amp;categoryName=地垫&amp;pageFrom=category"
                                        class="category-3-item ">地垫</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=137c77bda761fbef95bbc41be2785358&amp;categoryName=抱枕靠垫&amp;pageFrom=category"
                                        class="category-3-item ">抱枕靠垫</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=bb554a3b64cf0fd87a24338eb9e50002&amp;categoryName=窗帘&amp;pageFrom=category"
                                        class="category-3-item ">窗帘</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=10cb8657881e175962ff1002e35a5efa&amp;categoryName=床单床笠&amp;pageFrom=category"
                                        class="category-3-item ">床单床笠</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2d423ec7c76c80e92b42350009ab5344&amp;categoryName=坐垫&amp;pageFrom=category"
                                        class="category-3-item ">坐垫</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="家饰">家饰</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=49df1e04ab89703cb636763f95f9b0da&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0bfd6cd39ed243b167c9eb5ffa077c4a&amp;categoryName=摆件&amp;pageFrom=category"
                                        class="category-3-item ">摆件</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8b54e0ef8f5452e756b41690ab3c516b&amp;categoryName=装饰画&amp;pageFrom=category"
                                        class="category-3-item ">装饰画</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1bbeee1f9ca6a66908a710720c0e7c67&amp;categoryName=鲜花绿植&amp;pageFrom=category"
                                        class="category-3-item ">鲜花绿植</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a8747d0e8843debbe2760ee7cf9bdda5&amp;categoryName=永生花&amp;pageFrom=category"
                                        class="category-3-item ">永生花</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=29e639b088ac6d9fca2a29972023ad6a&amp;categoryName=香薰蜡烛&amp;pageFrom=category"
                                        class="category-3-item ">香薰蜡烛</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="刀剪砧板">刀剪砧板</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2ab26735349d336fb85b00b52b025166&amp;categoryName=刀具套装&amp;pageFrom=category"
                                        class="category-3-item ">刀具套装</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=901df4fe8e528505dc960f82c55066e3&amp;categoryName=砧板&amp;pageFrom=category"
                                        class="category-3-item ">砧板</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="厨房配件">厨房配件</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c3ea422d40731c8f5e30dc94d5e836db&amp;categoryName=保鲜收纳&amp;pageFrom=category"
                                        class="category-3-item ">保鲜收纳</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=551411fb9c07bc01a6558f7de786cae1&amp;categoryName=厨房置物架&amp;pageFrom=category"
                                        class="category-3-item ">厨房置物架</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5f84970702ef88c6e82cb08d95d3a374&amp;categoryName=功能餐具&amp;pageFrom=category"
                                        class="category-3-item ">功能餐具</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="餐具">餐具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=24407e0eabbc9e8910b8db3dc2161dc7&amp;categoryName=碗&amp;pageFrom=category"
                                        class="category-3-item ">碗</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=39531340bf19f15d40844bf3c0384aca&amp;categoryName=筷子&amp;pageFrom=category"
                                        class="category-3-item ">筷子</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1fd02f34cc3d03bf3f4dbe267316be17&amp;categoryName=餐盘套装&amp;pageFrom=category"
                                        class="category-3-item ">餐盘套装</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="茶咖酒具">茶咖酒具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7cce0accc82eacf6b2f170e1e3511444&amp;categoryName=茶具套装&amp;pageFrom=category"
                                        class="category-3-item ">茶具套装</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=803a2dc6b0dec45237a2ba9fd554192c&amp;categoryName=酒杯&amp;pageFrom=category"
                                        class="category-3-item ">酒杯</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=edcdbbdf05f06d60c9a0eabe1dca728b&amp;categoryName=酒具套装&amp;pageFrom=category"
                                        class="category-3-item ">酒具套装</a></span></div>
                        </div>
                    </div>
                    <div class="sub-cate-area">
                        <div class="cate-name">美妆个护</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="热门精选">热门精选</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=159801"
                                        class="category-3-item ">高速吹风机</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=162947"
                                        class="category-3-item ">优选新品</a><a
                                        data-src="https://m.xiaomiyoupin.com/search_category?apppagefrom=category&amp;queryId=6ff1d5bec8baba2202a3522d028b6e6c"
                                        class="category-3-item ">洗发护发</a><a
                                        data-src="https://m.xiaomiyoupin.com/search_category?apppagefrom=category&amp;queryId=78877dbbed68afafc00e8eb533d69cd3"
                                        class="category-3-item ">牙刷/冲牙器</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=157039"
                                        class="category-3-item ">爆款尖货</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="面部护肤">面部护肤</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c66ca881d806fd6b9f591eec5329579c&amp;categoryName=面膜&amp;pageFrom=category"
                                        class="category-3-item ">面膜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=842bd3e8807022bd560d8a794a92d51e&amp;categoryName=洁面/卸妆&amp;pageFrom=category"
                                        class="category-3-item ">洁面/卸妆</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=327caaafc2f3943da4b2dbe19b947294&amp;categoryName=爽肤水&amp;pageFrom=category"
                                        class="category-3-item ">爽肤水</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2cda693d7868b177bcefd19da52c77b8&amp;categoryName=精华&amp;pageFrom=category"
                                        class="category-3-item ">精华</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d0ad53a077a0b8ccbf4550ef2bc095dc&amp;categoryName=乳液面霜&amp;pageFrom=category"
                                        class="category-3-item ">乳液面霜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6ec4b960c51723c8802170394eab9e5d&amp;categoryName=套装礼盒&amp;pageFrom=category"
                                        class="category-3-item ">套装礼盒</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="身体护理">身体护理</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6ff1d5bec8baba2202a3522d028b6e6c&amp;categoryName=洗发护发&amp;pageFrom=category"
                                        class="category-3-item ">洗发护发</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9020a0ccc35d5f4d8ab5f8b452e5d96f&amp;categoryName=防脱系列&amp;pageFrom=category"
                                        class="category-3-item ">防脱系列</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=15aae5b6ec79fa27b7a39126279c8d5e&amp;categoryName=沐浴露&amp;pageFrom=category"
                                        class="category-3-item ">沐浴露</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d698e5aaed319aded8df906a67f96d91&amp;categoryName=养生护理&amp;pageFrom=category"
                                        class="category-3-item ">养生护理</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e4f9344fe2c98d726424ef4ebba67c5a&amp;categoryName=身体乳&amp;pageFrom=category"
                                        class="category-3-item ">身体乳</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=89db7fd1e64d4da4d17d84f83e184e2b&amp;categoryName=洗手护手&amp;pageFrom=category"
                                        class="category-3-item ">洗手护手</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="彩妆香氛">彩妆香氛</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0261729d41f4d160b7c3b1ec3f8b7a75&amp;categoryName=香水&amp;pageFrom=category"
                                        class="category-3-item ">香水</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1e321d89faf3ae0491eb058df09a99fb&amp;categoryName=口红&amp;pageFrom=category"
                                        class="category-3-item ">口红</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3114465f2428a29d5849451c998f8c63&amp;categoryName=彩妆&amp;pageFrom=category"
                                        class="category-3-item ">彩妆</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b55d16b0351e8ec31b71f67555c69b5e&amp;categoryName=粉底&amp;pageFrom=category"
                                        class="category-3-item ">粉底</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="口腔清洁">口腔清洁</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=78877dbbed68afafc00e8eb533d69cd3&amp;categoryName=牙刷&amp;pageFrom=category"
                                        class="category-3-item ">牙刷</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5cc272ae8550ddf51afed43d974dc66b&amp;categoryName=电动牙刷&amp;pageFrom=category"
                                        class="category-3-item ">电动牙刷</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=358b9237a35dd2346a9c97ebbcd6ccab&amp;categoryName=冲牙器&amp;pageFrom=category"
                                        class="category-3-item ">冲牙器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=65bc876d912f7218b9382ad0cdd0d4f1&amp;categoryName=牙膏&amp;pageFrom=category"
                                        class="category-3-item ">牙膏</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ad605d7ce303fb912e2fabd55f8ce633&amp;categoryName=漱口水&amp;pageFrom=category"
                                        class="category-3-item ">漱口水</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9f5685b92944bf23a6e9ea461fd62982&amp;categoryName=牙线&amp;pageFrom=category"
                                        class="category-3-item ">牙线</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3c4328712d84125bac5515037a342158&amp;categoryName=刷头配件&amp;pageFrom=category"
                                        class="category-3-item ">刷头配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="美妆工具">美妆工具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c1c581b7a1b9d7d65aed728e911dc1b4&amp;categoryName=护理仪器&amp;pageFrom=category"
                                        class="category-3-item ">护理仪器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0972d6369fdcd270611d17c9f4f03a6f&amp;categoryName=剃须刀&amp;pageFrom=category"
                                        class="category-3-item ">剃须刀</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=932ea52ae660f56623276598b39fe4ee&amp;categoryName=梳子&amp;pageFrom=category"
                                        class="category-3-item ">梳子</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6c275422efe2b86e00ce953600fd0bde&amp;categoryName=化妆镜&amp;pageFrom=category"
                                        class="category-3-item ">化妆镜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7e119695f207e4c07ae63d8c7022e02b&amp;categoryName=吹风机&amp;pageFrom=category"
                                        class="category-3-item ">吹风机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=792d9628c899d9813998c595d179ce96&amp;categoryName=卷发棒&amp;pageFrom=category"
                                        class="category-3-item ">卷发棒</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fdfd7dd0486836b79cef926911564416&amp;categoryName=洗澡刷&amp;pageFrom=category"
                                        class="category-3-item ">洗澡刷</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=20391d54df1f3dcffd131054adc7b31a&amp;categoryName=足部护理&amp;pageFrom=category"
                                        class="category-3-item ">足部护理</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b1d0f04bbf9ed1c29d605c2d63c116c9&amp;categoryName=指甲剪&amp;pageFrom=category"
                                        class="category-3-item ">指甲剪</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="进口大牌">进口大牌</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f8fea703e205af073d8823899ccb6da6&amp;categoryName=礼盒套装&amp;pageFrom=category"
                                        class="category-3-item ">礼盒套装</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=addbfcb83dc5fe2589d0a7c8b2c134c1&amp;categoryName=资生堂&amp;pageFrom=category"
                                        class="category-3-item ">资生堂</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=64321e13e89b1414d6ef114a94183276&amp;categoryName=Dior&amp;pageFrom=category"
                                        class="category-3-item ">Dior</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=aef9799759e15ea83370d9da7506001f&amp;categoryName=LA MER&amp;pageFrom=category"
                                        class="category-3-item ">LA MER</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5efc17a5c24bc02398ab22c945542ab3&amp;categoryName=SK-II&amp;pageFrom=category"
                                        class="category-3-item ">SK-II</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3da0c11d71aa20f82b49e8adfbccda27&amp;categoryName=雅诗兰黛&amp;pageFrom=category"
                                        class="category-3-item ">雅诗兰黛</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=963ddff517472b1e70d2dc05ecc6e368&amp;categoryName=兰蔻&amp;pageFrom=category"
                                        class="category-3-item ">兰蔻</a></span></div>
                        </div>
                    </div>
                        </div>
                <!-- block9 -->
                <li class="nav-item block9 "><span class="nav-item-span">鞋靴箱包</span><span> / </span><span
                        class="nav-item-span">医疗健康</span></li>
                        <!-- tab9 -->
                        <div class="nav-detail d9 ">
                    <div class="sub-cate-area">
                        <div class="cate-name">鞋靴箱包</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="热门精选">热门精选</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=163815"
                                        class="category-3-item ">袜套健步鞋</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=164589"
                                        class="category-3-item ">轻户外鞋</a><a
                                        data-src="https://www.xiaomiyoupin.com/detail?gid=164201"
                                        class="category-3-item ">通勤背包</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="运动户外鞋">运动户外鞋</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=28ea83caa81712aa5a76a0a774d19c1b&amp;categoryName=跑步鞋&amp;pageFrom=category"
                                        class="category-3-item ">跑步鞋</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b2b2dc100b81de9cc9be00cc6e4dc5d2&amp;categoryName=休闲鞋&amp;pageFrom=category"
                                        class="category-3-item ">休闲鞋</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=67d379396708dc4ab13083d1a7fc349d&amp;categoryName=运动凉鞋/拖鞋&amp;pageFrom=category"
                                        class="category-3-item ">运动凉鞋/拖鞋</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=aeffeda91b9c590fe10177ce097c6d1b&amp;categoryName=登山/徒步鞋&amp;pageFrom=category"
                                        class="category-3-item ">登山/徒步鞋</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="男鞋">男鞋</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=87324cdb740b05096a4f4fe5632ca51f&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b5ef687a9722589f3a4709665ff2a8c3&amp;categoryName=正装鞋&amp;pageFrom=category"
                                        class="category-3-item ">正装鞋</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9bfc0260e6a374fc6be6c85bc12d1630&amp;categoryName=商务休闲&amp;pageFrom=category"
                                        class="category-3-item ">商务休闲</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e512d8c16c67ac35a400a1f060222a1e&amp;categoryName=男靴&amp;pageFrom=category"
                                        class="category-3-item ">男靴</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e968123e643b73f12159f1210c5cb772&amp;categoryName=休闲鞋&amp;pageFrom=category"
                                        class="category-3-item ">休闲鞋</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=550d37a94dea8861dc70e54ad0875307&amp;categoryName=凉鞋/拖鞋&amp;pageFrom=category"
                                        class="category-3-item ">凉鞋/拖鞋</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=50955cab716c15f8b369bcac21a04600&amp;categoryName=鞋配件&amp;pageFrom=category"
                                        class="category-3-item ">鞋配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="旅行箱">旅行箱</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6ef92ab7fc33978069ba654c4d9d6deb&amp;categoryName=新品箱包&amp;pageFrom=category"
                                        class="category-3-item ">新品箱包</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e23de09e5cd58e4abb1df6dc8ce5de4c&amp;categoryName=拉杆箱&amp;pageFrom=category"
                                        class="category-3-item ">拉杆箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c4465a688495f766628e5e5b5ee3df6c&amp;categoryName=金属箱&amp;pageFrom=category"
                                        class="category-3-item ">金属箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e12137f5464ff58aeb0b479220bca315&amp;categoryName=小米旅行箱&amp;pageFrom=category"
                                        class="category-3-item ">小米旅行箱</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="男包">男包</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=878eab99ae21800faee2a605f867c0ab&amp;categoryName=双肩包&amp;pageFrom=category"
                                        class="category-3-item ">双肩包</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fbcf9529d710f2329fe008586220d1db&amp;categoryName=单肩/斜挎包&amp;pageFrom=category"
                                        class="category-3-item ">单肩/斜挎包</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=51f4475fa1c5e2a644bc665b76e1e9f4&amp;categoryName=胸包腰包&amp;pageFrom=category"
                                        class="category-3-item ">胸包腰包</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=dcdbb1561588bf8764a999ec31a7ab9e&amp;categoryName=电脑包/公文包&amp;pageFrom=category"
                                        class="category-3-item ">电脑包/公文包</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b5d653d661d34f25251366f17b4eb266&amp;categoryName=小米背包&amp;pageFrom=category"
                                        class="category-3-item ">小米背包</a></span></div>
                        </div>
                    </div>
                    <div class="sub-cate-area">
                        <div class="cate-name">医疗健康</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="热门精选">热门精选</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal?_rt=weex&amp;pageid=10681&amp;pdl=youpin&amp;sign=8bb5f04d80f735d6c24e22963452be7a"
                                        class="category-3-item ">健康科普</a><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal?_rt=weex&amp;pageid=12145&amp;pdl=youpin&amp;sign=47d3abc218de9f2fb30f70264034473f"
                                        class="category-3-item ">健康防疫</a><a
                                        data-src="https://m.xiaomiyoupin.com/w/universal?_rt=weex&amp;pageid=13028&amp;pdl=youpin&amp;sign=a690b363928d06807e50acf3d492a011"
                                        class="category-3-item ">愈养愉康</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="按摩椅">按摩椅</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0fa76c14d6f42fdeae1d6924e19f66bf&amp;categoryName=按摩椅&amp;pageFrom=category"
                                        class="category-3-item ">按摩椅</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="按摩器械">按摩器械</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=acbd9be94cb6d76138a4dd3e98aed7d4&amp;categoryName=肩颈按摩&amp;pageFrom=category"
                                        class="category-3-item ">肩颈按摩</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8f77f3db5843dc6c023bcb174bc5b200&amp;categoryName=筋膜枪&amp;pageFrom=category"
                                        class="category-3-item ">筋膜枪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2e7178684a48a1afd860897c73618324&amp;categoryName=按摩器&amp;pageFrom=category"
                                        class="category-3-item ">按摩器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8fc421864a2b700ea7edacbeb312adcc&amp;categoryName=眼部按摩仪&amp;pageFrom=category"
                                        class="category-3-item ">眼部按摩仪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=92c5af629464bfd7c4758fd176894294&amp;categoryName=电子秤&amp;pageFrom=category"
                                        class="category-3-item ">电子秤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=441a4c1dd115caa764442a9c3914b074&amp;categoryName=足疗机&amp;pageFrom=category"
                                        class="category-3-item ">足疗机</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="养生器械">养生器械</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=675c71669bb7162de376b15ad201b3ae&amp;categoryName=足浴盆&amp;pageFrom=category"
                                        class="category-3-item ">足浴盆</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e3f0bd893510957c57baf722aa436c7f&amp;categoryName=养生理疗&amp;pageFrom=category"
                                        class="category-3-item ">养生理疗</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=142e1360aea57c7723d7e2a7a927fb9f&amp;categoryName=中医保健&amp;pageFrom=category"
                                        class="category-3-item ">中医保健</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="家用医疗">家用医疗</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=41f8b23b7a45265ee4fd6f93d2a92601&amp;categoryName=理疗仪&amp;pageFrom=category"
                                        class="category-3-item ">理疗仪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=be2d06100b7569afbedee2a2e66cec71&amp;categoryName=助听器&amp;pageFrom=category"
                                        class="category-3-item ">助听器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3b9552d199abed46eb3a344f581fdd0b&amp;categoryName=血压计&amp;pageFrom=category"
                                        class="category-3-item ">血压计</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1c0a318840bde2dee6b049e63429197e&amp;categoryName=体温计&amp;pageFrom=category"
                                        class="category-3-item ">体温计</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5d911c9073e7f26acbf2aafd2bc6b6ee&amp;categoryName=血糖仪&amp;pageFrom=category"
                                        class="category-3-item ">血糖仪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=151561c87c44e830d691740ec6190833&amp;categoryName=智能健康&amp;pageFrom=category"
                                        class="category-3-item ">智能健康</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a77310478051212b2ecd2f8cecf22be6&amp;categoryName=制氧机&amp;pageFrom=category"
                                        class="category-3-item ">制氧机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=dbec6a346648a05a9565d25d44580c73&amp;categoryName=心电/血氧仪&amp;pageFrom=category"
                                        class="category-3-item ">心电/血氧仪</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=da3bc098b5de136eb3f578d0b4a631c1&amp;categoryName=雾化器&amp;pageFrom=category"
                                        class="category-3-item ">雾化器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=99123c0a4e540d0cabf4bfd37aef2071&amp;categoryName=呼吸机&amp;pageFrom=category"
                                        class="category-3-item ">呼吸机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8bd6e8f31e43301a10ad78e15632b730&amp;categoryName=轮椅-拐杖&amp;pageFrom=category"
                                        class="category-3-item ">轮椅-拐杖</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="护理护具">护理护具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=92290d728144b9166de9f35d6d636122&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4f6ecfaffb7dbefad280f23ca5801c45&amp;categoryName=口罩&amp;pageFrom=category"
                                        class="category-3-item ">口罩</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=952dce95e8f8fedf08e5e0a792ccd13e&amp;categoryName=眼部保健&amp;pageFrom=category"
                                        class="category-3-item ">眼部保健</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9755a31cfaac40d96c5e5264a36ab9f6&amp;categoryName=塑形矫姿&amp;pageFrom=category"
                                        class="category-3-item ">塑形矫姿</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c89e34d14359482f877f045a903c2906&amp;categoryName=健康电器&amp;pageFrom=category"
                                        class="category-3-item ">健康电器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0ded2d24eb2e7be3d41ac920733fa686&amp;categoryName=消毒消杀&amp;pageFrom=category"
                                        class="category-3-item ">消毒消杀</a></span></div>
                        </div>
                    </div>
                        </div>  
                <!-- block10 -->
                <li class="nav-item block10 "><span class="nav-item-span">日用百货</span><span> / </span><span
                        class="nav-item-span">母婴亲子</span></li>
                        <!-- tab10 -->
                        <div class="nav-detail d10 ">
                    <div class="sub-cate-area">
                        <div class="cate-name">日用百货</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="酷玩">酷玩</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=428515b25bdafe632f004bd2f8b2dd49&amp;categoryName=创意工具&amp;pageFrom=category"
                                        class="category-3-item ">创意工具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b1197b326c6dd2c38947ad182522a398&amp;categoryName=无人机&amp;pageFrom=category"
                                        class="category-3-item ">无人机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=987bb48eec8cc39ab5789383e428b492&amp;categoryName=智能乐器&amp;pageFrom=category"
                                        class="category-3-item ">智能乐器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c448ba9d42ac9b5c5c18c05291669cad&amp;categoryName=照片打印机&amp;pageFrom=category"
                                        class="category-3-item ">照片打印机</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="工具">工具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2a6bb4e01108f34bf8cb149c8fd8adbf&amp;categoryName=工具箱&amp;pageFrom=category"
                                        class="category-3-item ">工具箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=72dc2d48e75c9fe65480da593c3e9034&amp;categoryName=电动工具&amp;pageFrom=category"
                                        class="category-3-item ">电动工具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=be9a957b5e581b17f827be3a8242437b&amp;categoryName=手动工具&amp;pageFrom=category"
                                        class="category-3-item ">手动工具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e2cd51bcd77daa40e4e539fd287c5c06&amp;categoryName=测量工具&amp;pageFrom=category"
                                        class="category-3-item ">测量工具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=45d9488a9813dad848d30ea14adfb37f&amp;categoryName=安防工具&amp;pageFrom=category"
                                        class="category-3-item ">安防工具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=031d670ecd4aa79dec158a4b912bd88f&amp;categoryName=DIY工具&amp;pageFrom=category"
                                        class="category-3-item ">DIY工具</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="纸品湿巾">纸品湿巾</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fb530c4b0e3eed7b2da075faf0443124&amp;categoryName=湿巾&amp;pageFrom=category"
                                        class="category-3-item ">湿巾</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f0db767be5f6ba277168ef0a76b51c17&amp;categoryName=纸品&amp;pageFrom=category"
                                        class="category-3-item ">纸品</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="清洁用具">清洁用具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=bbdba89b00f812bb0ec92811671c5a97&amp;categoryName=清洁刷&amp;pageFrom=category"
                                        class="category-3-item ">清洁刷</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=79e9fe24614b9207fa75db831741b8ae&amp;categoryName=脸盆水桶&amp;pageFrom=category"
                                        class="category-3-item ">脸盆水桶</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e977fd985fd614254e88bb263b43b36c&amp;categoryName=其他清洁&amp;pageFrom=category"
                                        class="category-3-item ">其他清洁</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=61dedb11412dc01c5cfc6d109cf40714&amp;categoryName=拖把/扫把&amp;pageFrom=category"
                                        class="category-3-item ">拖把/扫把</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fdb7e268faaa3758eb8e3dc5b983edb3&amp;categoryName=垃圾桶/垃圾袋&amp;pageFrom=category"
                                        class="category-3-item ">垃圾桶/垃圾袋</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c3937051f5da69ce3e5903a66edddbf8&amp;categoryName=一次性清洁用品&amp;pageFrom=category"
                                        class="category-3-item ">一次性清洁用品</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="日用杂货">日用杂货</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=850b7eefa92a2786f4b0a78256ed4474&amp;categoryName=保暖防护&amp;pageFrom=category"
                                        class="category-3-item ">保暖防护</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0d5161afb3f4bccf981fd7d51aa83696&amp;categoryName=驱蚊驱虫&amp;pageFrom=category"
                                        class="category-3-item ">驱蚊驱虫</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f6f44cdd8f3e1bdc652795375d506e20&amp;categoryName=卫浴用品&amp;pageFrom=category"
                                        class="category-3-item ">卫浴用品</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=7fe74b203b2c32eee428c997c54cf44a&amp;categoryName=晾晒&amp;pageFrom=category"
                                        class="category-3-item ">晾晒</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6012056b1adff963c4a2d7bbfa99287c&amp;categoryName=雨伞/雨披&amp;pageFrom=category"
                                        class="category-3-item ">雨伞/雨披</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=976ef749f7ffdf834851c138d0df3692&amp;categoryName=其他&amp;pageFrom=category"
                                        class="category-3-item ">其他</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="日化洗涤">日化洗涤</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=926a5c15e6fdcb1d0b58137430b43a19&amp;categoryName=衣物护理&amp;pageFrom=category"
                                        class="category-3-item ">衣物护理</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d0c8a4e3169ada266acafd7cd807452c&amp;categoryName=家庭清洁&amp;pageFrom=category"
                                        class="category-3-item ">家庭清洁</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="收纳用品">收纳用品</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3892166f2dbc051937d06d832bbc1c7d&amp;categoryName=收纳袋/包&amp;pageFrom=category"
                                        class="category-3-item ">收纳袋/包</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f22c22042cac77deb943087a183aadf9&amp;categoryName=收纳盒/箱&amp;pageFrom=category"
                                        class="category-3-item ">收纳盒/箱</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8a8b7c9958699786d86865f97fa6437e&amp;categoryName=收纳柜&amp;pageFrom=category"
                                        class="category-3-item ">收纳柜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9eb895419141326314886de8cc7a69f3&amp;categoryName=收纳架/篮&amp;pageFrom=category"
                                        class="category-3-item ">收纳架/篮</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="文具">文具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b4782fd62be61c9292d97e784e1e6c39&amp;categoryName=笔类&amp;pageFrom=category"
                                        class="category-3-item ">笔类</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e6fcd26b2c46b7b5ca6be22aa9055a9d&amp;categoryName=其他文具&amp;pageFrom=category"
                                        class="category-3-item ">其他文具</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="文创礼品">文创礼品</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ef5f64c9612b00db3d491deb9bf46a8f&amp;categoryName=礼品文具&amp;pageFrom=category"
                                        class="category-3-item ">礼品文具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4add7d1a12d7dfb4208f6177ef28a513&amp;categoryName=其他文创礼品&amp;pageFrom=category"
                                        class="category-3-item ">其他文创礼品</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="图书音像">图书音像</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=42dc5ddbae5a0ab59b880205b1c1cf55&amp;categoryName=图书&amp;pageFrom=category"
                                        class="category-3-item ">图书</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="智能教育">智能教育</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d4689128daf1943e3ef15e2cee01eb92&amp;categoryName=电纸书&amp;pageFrom=category"
                                        class="category-3-item ">电纸书</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6fb6a7023a11378015910efa3fc800ab&amp;categoryName=手写板/笔&amp;pageFrom=category"
                                        class="category-3-item ">手写板/笔</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d91eb66f85ed21dfcfa9b93185640e68&amp;categoryName=电子词典&amp;pageFrom=category"
                                        class="category-3-item ">电子词典</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=563b8b172aeeb18d73e6665db178d202&amp;categoryName=点读机/笔&amp;pageFrom=category"
                                        class="category-3-item ">点读机/笔</a></span></div>
                        </div>
                        </div>
                    <div class="sub-cate-area">
                        <div class="cate-name">母婴亲子</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="新奇玩具">新奇玩具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8f7615b620374183fe2c42fcc48fe7ee&amp;categoryName=新品推荐&amp;pageFrom=category"
                                        class="category-3-item ">新品推荐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=13f2e05ebd19b38e8d8ca840cf0d5cf7&amp;categoryName=积木/模型&amp;pageFrom=category"
                                        class="category-3-item ">积木/模型</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=06729dff6a2f43fa963cbeaabd9233d4&amp;categoryName=遥控电动&amp;pageFrom=category"
                                        class="category-3-item ">遥控电动</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4c440ecfe9b74b9a209fb6a6c4a4c9ef&amp;categoryName=绘画DIY&amp;pageFrom=category"
                                        class="category-3-item ">绘画DIY</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b4b93ef5e66bf0ed15e85496be3522d3&amp;categoryName=益智玩具&amp;pageFrom=category"
                                        class="category-3-item ">益智玩具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ae18abf5cd6e2ba12c9e5b8c6db2289b&amp;categoryName=娃娃玩具&amp;pageFrom=category"
                                        class="category-3-item ">娃娃玩具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=795780f60e761006f69d04f514761e4e&amp;categoryName=科学实验&amp;pageFrom=category"
                                        class="category-3-item ">科学实验</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="奶粉尿裤">奶粉尿裤</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=9ce96ac166503a5165f52f02771a9d65&amp;categoryName=婴幼奶粉&amp;pageFrom=category"
                                        class="category-3-item ">婴幼奶粉</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=241753dc20d7c79bebe28ce477591f93&amp;categoryName=尿裤&amp;pageFrom=category"
                                        class="category-3-item ">尿裤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e54c943f65c6195099eb356461455367&amp;categoryName=湿巾/纸巾&amp;pageFrom=category"
                                        class="category-3-item ">湿巾/纸巾</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="出行好物">出行好物</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=addada9a08be2e1b779bb3d448b98da6&amp;categoryName=滑步车&amp;pageFrom=category"
                                        class="category-3-item ">滑步车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=989144a6172be2fa530654dafd9058d4&amp;categoryName=轮滑/滑板车&amp;pageFrom=category"
                                        class="category-3-item ">轮滑/滑板车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1f3993824098390ffbd5a636a4a54d71&amp;categoryName=婴儿推车&amp;pageFrom=category"
                                        class="category-3-item ">婴儿推车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b62e2847827542e425ab746132aa59cf&amp;categoryName=三轮车/扭扭车&amp;pageFrom=category"
                                        class="category-3-item ">三轮车/扭扭车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f13597f3cc402edf40e2e1ad59c329a2&amp;categoryName=自行车&amp;pageFrom=category"
                                        class="category-3-item ">自行车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5d52f12a2b1413622ec23554bc959b35&amp;categoryName=安全座椅&amp;pageFrom=category"
                                        class="category-3-item ">安全座椅</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="洗护喂养">洗护喂养</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5f6cb73828cd53cb93543f37f8881ef0&amp;categoryName=日常护理&amp;pageFrom=category"
                                        class="category-3-item ">日常护理</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=768de95bfb1e8807bc56d644deb1fb5f&amp;categoryName=婴儿口腔清洁&amp;pageFrom=category"
                                        class="category-3-item ">婴儿口腔清洁</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=18c72dd66795cd5a9da00fd5c8bb0fcf&amp;categoryName=理发器&amp;pageFrom=category"
                                        class="category-3-item ">理发器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=fefeb957a3660eb5da807cf9dc422de0&amp;categoryName=喂养电器&amp;pageFrom=category"
                                        class="category-3-item ">喂养电器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=899bc54c3be1230462d85cd12ff0a8b8&amp;categoryName=水壶/水杯&amp;pageFrom=category"
                                        class="category-3-item ">水壶/水杯</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="家教辅导">家教辅导</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cab1234840e75efca660d257cb1364bc&amp;categoryName=儿童手表&amp;pageFrom=category"
                                        class="category-3-item ">儿童手表</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=6ecb271486f0ca9f831a1b229024ba16&amp;categoryName=学生平板&amp;pageFrom=category"
                                        class="category-3-item ">学生平板</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=32a5056dbcae56ac1674bc9ceec9df4b&amp;categoryName=打印机&amp;pageFrom=category"
                                        class="category-3-item ">打印机</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="服饰鞋包">服饰鞋包</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=86db0baf6a811767b091493c789b1f70&amp;categoryName=冬装&amp;pageFrom=category"
                                        class="category-3-item ">冬装</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=dccdcef8123fcc66e85f88f0ca034c99&amp;categoryName=运动鞋&amp;pageFrom=category"
                                        class="category-3-item ">运动鞋</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=579dbe52f35edd34817b372ed848e644&amp;categoryName=童包&amp;pageFrom=category"
                                        class="category-3-item ">童包</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=acde3b49ace8841c3c5b2813ebf0f464&amp;categoryName=内衣裤/袜子&amp;pageFrom=category"
                                        class="category-3-item ">内衣裤/袜子</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="儿童图书">儿童图书</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=33b1c0d2edbe78fee69dab2460dd0df9&amp;categoryName=6岁+&amp;pageFrom=category"
                                        class="category-3-item ">6岁+</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="儿童寝居">儿童寝居</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d8e7e5686e6ecb0ff51ec31f1a0741da&amp;categoryName=婴童床品&amp;pageFrom=category"
                                        class="category-3-item ">婴童床品</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3909b6ead028d248a788489a939b8978&amp;categoryName=儿童家具&amp;pageFrom=category"
                                        class="category-3-item ">儿童家具</a></span></div>
                        </div>
                        </div>
                        </div>
                <!-- block11 -->
                <li class="nav-item block11 "><span class="nav-item-span">运动户外</span><span> / </span><span
                        class="nav-item-span">宠物生活</span></li>
                        <!-- tab11 -->
                        <div class="nav-detail d11 ">
                <div class="sub-cate-area">
                        <div class="cate-name">运动户外</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="有氧燃脂">有氧燃脂</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=746e42bcb86d5f6ff14360bb3814e606&amp;categoryName=跑步机&amp;pageFrom=category"
                                        class="category-3-item ">跑步机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b0ee1d249f519ea06e88981d27bba5a7&amp;categoryName=动感单车&amp;pageFrom=category"
                                        class="category-3-item ">动感单车</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=8add12b142e98a13adf24ae5910ddf09&amp;categoryName=划船机&amp;pageFrom=category"
                                        class="category-3-item ">划船机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=242b19dae42fe25cb41de8c46df345c0&amp;categoryName=椭圆机&amp;pageFrom=category"
                                        class="category-3-item ">椭圆机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=200bc8efa6dda0468abd5bc5621b4d0d&amp;categoryName=跳绳&amp;pageFrom=category"
                                        class="category-3-item ">跳绳</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1f86c868f07bcd955746f30761ad494e&amp;categoryName=蹦床&amp;pageFrom=category"
                                        class="category-3-item ">蹦床</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="健身小器械">健身小器械</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c8c404aa22c0b1218ce768a69159b1fd&amp;categoryName=力量训练&amp;pageFrom=category"
                                        class="category-3-item ">力量训练</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=3cb50b9ea02a6531508b9c5d91f3935d&amp;categoryName=美体塑形&amp;pageFrom=category"
                                        class="category-3-item ">美体塑形</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="户外装备">户外装备</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5899722e0947152ad34a48c7b5726ab3&amp;categoryName=户外照明&amp;pageFrom=category"
                                        class="category-3-item ">户外照明</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=29f3df16b2ba95a846227ad514a739d7&amp;categoryName=望远镜&amp;pageFrom=category"
                                        class="category-3-item ">望远镜</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ceef630a3560ee0b888bb466f853ea34&amp;categoryName=户外工具&amp;pageFrom=category"
                                        class="category-3-item ">户外工具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=0ffa71a2f973db5c7674228dd7376b07&amp;categoryName=对讲机&amp;pageFrom=category"
                                        class="category-3-item ">对讲机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f9cc0e5ef9500184c6576445bb88d582&amp;categoryName=打火机&amp;pageFrom=category"
                                        class="category-3-item ">打火机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=15840896c8ae37c1db48487ff289d1c0&amp;categoryName=户外电源&amp;pageFrom=category"
                                        class="category-3-item ">户外电源</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=377c1586e491f3a7c115de3a5363c73a&amp;categoryName=帐篷/垫子&amp;pageFrom=category"
                                        class="category-3-item ">帐篷/垫子</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2868df8f12ac58fe8f08910226ea4889&amp;categoryName=露营家具&amp;pageFrom=category"
                                        class="category-3-item ">露营家具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b62fc4c16bf017f449b0d5a581e14b3d&amp;categoryName=睡袋/吊床&amp;pageFrom=category"
                                        class="category-3-item ">睡袋/吊床</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=a100a6b3ea17e488c006f9b799c1fc91&amp;categoryName=军迷用品&amp;pageFrom=category"
                                        class="category-3-item ">军迷用品</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=b76439c07a56a615e5a64243e8f6e2ab&amp;categoryName=户外娱乐&amp;pageFrom=category"
                                        class="category-3-item ">户外娱乐</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=94f8e52613fa698f084f248b5a5453de&amp;categoryName=野餐/烧烤&amp;pageFrom=category"
                                        class="category-3-item ">野餐/烧烤</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=2ba3d20d62039b177a87047c73d89530&amp;categoryName=垂钓用品&amp;pageFrom=category"
                                        class="category-3-item ">垂钓用品</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="体育用品">体育用品</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f06fe7fe4e103ac98cd311f0adbd963c&amp;categoryName=球类运动&amp;pageFrom=category"
                                        class="category-3-item ">球类运动</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=bf7118c65dcf62ddc9e3ba960d36c4cf&amp;categoryName=轮滑滑板&amp;pageFrom=category"
                                        class="category-3-item ">轮滑滑板</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cef46f795dab1e0c41d4d263b99de337&amp;categoryName=护具配件&amp;pageFrom=category"
                                        class="category-3-item ">护具配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="棋牌麻将">棋牌麻将</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=e5f620861134bc633e1425a6aa3f8a04&amp;categoryName=麻将机&amp;pageFrom=category"
                                        class="category-3-item ">麻将机</a></span></div>
                        </div>
                    </div> 
                <div class="sub-cate-area">
                        <div class="cate-name">宠物生活</div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="宠物智能">宠物智能</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=1604ceaef57ae108d40a0cd9064afefe&amp;categoryName=宠物饮水机&amp;pageFrom=category"
                                        class="category-3-item ">宠物饮水机</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c731e7ec0e4c602e1f39910c96860113&amp;categoryName=智能喂食器&amp;pageFrom=category"
                                        class="category-3-item ">智能喂食器</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=72bd62160a64fc40f1c307d730c4fa9c&amp;categoryName=智能除臭&amp;pageFrom=category"
                                        class="category-3-item ">智能除臭</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ff9a7ff7e6d8d109e43221121ce06880&amp;categoryName=智能猫砂盆&amp;pageFrom=category"
                                        class="category-3-item ">智能猫砂盆</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f7d8274de609f632e08510cd6bd3670b&amp;categoryName=宠物小家电&amp;pageFrom=category"
                                        class="category-3-item ">宠物小家电</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="水族用品">水族用品</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=afaffcb2c30cdf0e232034e11a214a15&amp;categoryName=鱼缸&amp;pageFrom=category"
                                        class="category-3-item ">鱼缸</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=c89711669d8e235e5ee57d35dae8cafe&amp;categoryName=水族配件&amp;pageFrom=category"
                                        class="category-3-item ">水族配件</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="宠物主粮">宠物主粮</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=ff4a8583eafb9b786e3da929191d47e9&amp;categoryName=猫粮&amp;pageFrom=category"
                                        class="category-3-item ">猫粮</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=39a2621c84da2eaca6bc52320596d87f&amp;categoryName=狗粮&amp;pageFrom=category"
                                        class="category-3-item ">狗粮</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=cb1ce24535ab946210cb8720b93c62d0&amp;categoryName=湿粮/罐头&amp;pageFrom=category"
                                        class="category-3-item ">湿粮/罐头</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="日常用品">日常用品</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=be3988e6ca356a900fa172f53069bc6a&amp;categoryName=猫砂&amp;pageFrom=category"
                                        class="category-3-item ">猫砂</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4695a9ec0eab1c383b336e2701b4c98e&amp;categoryName=美容工具&amp;pageFrom=category"
                                        class="category-3-item ">美容工具</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="零食罐头">零食罐头</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=190afc544ccdbb20b4675246227d799f&amp;categoryName=猫咪零食&amp;pageFrom=category"
                                        class="category-3-item ">猫咪零食</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=5300a557e3d270d217b52e957724e6cf&amp;categoryName=狗狗零食&amp;pageFrom=category"
                                        class="category-3-item ">狗狗零食</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="宠物保健">宠物保健</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list li-bottom"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=973b0f25afdf7d9dbc6547dd4e4c706e&amp;categoryName=营养补充&amp;pageFrom=category"
                                        class="category-3-item ">营养补充</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=d6ac4a882ad40edaddff938a3546bf73&amp;categoryName=宠物驱虫&amp;pageFrom=category"
                                        class="category-3-item ">宠物驱虫</a></span></div>
                        </div>
                        <div class="sub-nav-row">
                            <div class="sub-nav-item-row"><span class="category-2-item"><span class="name"
                                        title="宠物玩具">宠物玩具</span><img
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAMCAYAAABBV8wuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVCQkYwOUNEQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVCQkYwOUREQUFDMTFFOTg4MjdGMkE2NzI5QzVEMDMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUJCRjA5QURBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUJCRjA5QkRBQUMxMUU5ODgyN0YyQTY3MjlDNUQwMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Po++138AAACLSURBVHjaYjQ2Nl7CwMBQAcRPGJAAExBPBuI1QCyKLnESiNuAeAMQc8EkWKD0JiDmB+JlQBwGxL+YkHQvBuITQDwPiBmRJUCgA4hfgoxGlwCBfyC7WdAEQc6WBOJYZIloILYC4hAg/g+T8APiLCB2BbkI5lxzIK4BYm8g/obswWwgDgLi18iWAQQYAI8wFjnp4CZ5AAAAAElFTkSuQmCC"
                                        class="icon"></span><span class="category-3-list"><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=4ae91948de2ec0c1bebbd58320f4ea54&amp;categoryName=猫咪玩具&amp;pageFrom=category"
                                        class="category-3-item ">猫咪玩具</a><a
                                        data-src="https://www.xiaomiyoupin.com/search?queryId=f5aa59c2f5ed4e53758133512b9b37a7&amp;categoryName=狗狗玩具&amp;pageFrom=category"
                                        class="category-3-item ">狗狗玩具</a></span></div>
                        </div>
                    </div>              
                        </div>
            </ul>                                                   
            <HomeBanner />
        </div>
    </div>
</template>
<script>
import HomeBanner from '@/views/Home/HomeBanner.vue';
export default {
    components: {
        HomeBanner
    }
}
</script>
<style>
.banner-nav{
    width: 100%;
    background-color: #FFFFFF;
    height: 358px;
}
.nav-container{
    width: 1080px;
    height: 358px;
    margin: 0 auto;
    background-color: rgb(252, 240, 217);
}
.nav-list {
    float: left;
    width: 221px;
    height: 358px; 
    overflow-wrap: hidden;
    background-color:#836435;
    padding: 10px 0;
}
.nav-list a:hover{
    color: #cf9c4e;
}
.nav-item{
    width: 191px;
    height: 34px;
    padding-left: 30px;
    color: #fff;
    line-height: 35px;
}
.nav-item:hover{
    background-color: #6e552f;
}
.nav-list:hover{
    height: 400px;
}
.nav-item {
    position: relative;
}
.nav-detail{
    position: absolute;
    top: 140px;
    width: 857px;
    min-height:316px;
    display: none;
    height: auto;
    background-color: #fff;
    padding-top: 20px;
    padding-bottom:20px;
    border: 1px solid #eee;
    transition: opacity 2s ease;
    z-index: 1000;
}
.d1,.d2,.d3,.d4,.d6,.d9,.d11{
    left:940px;
}
.d5,.d7,.d8,.d10{
    left: 940px;
}
.block1:hover + .d1{
    display: block;
}
.block2:hover + .d2{
    display: block;
}
.block3:hover + .d3{
    display: block;
}
.block4:hover + .d4{
    display: block;
}
.block5:hover + .d5{
    display: block;
}
.block6:hover + .d6{
    display: block;
}
.block7:hover + .d7{
    display: block;
}
.block8:hover + .d8{
    display: block;
}
.block9:hover + .d9{
    display: block;
}
.block10:hover + .d10{
    display: block;
}
.block11:hover + .d11{
    display: block;
}
.nav-container .nav-detail .sub-cate-area .sub-nav-row .sub-nav-item-row .category-2-item {
    display: inline-flex;
    align-items: center;
    padding-left: 33px;
    padding-right: 34px;
    width: 72px;
}
.nav-container .nav-detail .sub-cate-area .sub-nav-row .sub-nav-item-row .category-2-item .name {
    color: #333;
    font-weight: 700;
    width: 56px;
    white-space: nowrap;
    overflow-x: hidden;
    overflow-y: hidden;
    text-overflow: ellipsis;
    text-align: justify;
    text-align-last: justify;
}
.cate-name{
    font-size: 18px;
    font-weight: 700;
    color: #805e3f;
    padding-left: 33px;
    margin-bottom: 11px;
}
.nav-container .nav-detail .sub-cate-area .sub-nav-row .sub-nav-item-row {
    display: flex;
}
.nav-container .nav-detail .sub-cate-area .sub-nav-row .sub-nav-item-row .category-2-item .name {
    color: #333;
    font-weight: 700;
    width: 56px;
    white-space: nowrap;
    overflow-x: hidden;
    overflow-y: hidden;
    text-overflow: ellipsis;
    text-align: justify;
    text-align-last: justify;
}
.nav-container .nav-detail .sub-cate-area .sub-nav-row .sub-nav-item-row .category-2-item .icon {
    margin-left: 5px;
    width: 6px;
    height: 12px;
}
.icon {
    width: 20px;
    height: 20px;
    margin-right: 2px;
}
img {
    vertical-align: middle;
    border: none;
}
.nav-container .nav-detail .sub-cate-area .sub-nav-row:not(:last-child) .category-3-list {
    border-bottom: 1px dashed #e6e6e6;
}
.nav-container .nav-detail .sub-cate-area .sub-nav-row .sub-nav-item-row .category-3-list {
    padding-top: 15px;
    padding-bottom: 15px;
    display: flex;
    flex-wrap: wrap;
    width: 673px;
}
.nav-container .nav-detail .sub-cate-area .sub-nav-row .sub-nav-item-row .category-3-list .category-3-item {
    margin-right: 15px;
    white-space: nowrap;
    color: #666;
}
a, button {
    outline: none;
}
a {
    text-decoration: none;
}
.nav-container .nav-detail .sub-cate-area .sub-nav-row:last-child {
    margin-bottom: 35px;
}

.sub-nav-row span{
    float: left;
    width: 54px;
    padding-left: 33px;
    color: #333;
    font-weight: 700;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
}
.m-banner .swipe-item {
    font-weight: 700;
    color: #14ade5;
    font-size: 20px;
}
.swiper-slide {
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    width: 100%;
    height: 100%;
    position: relative;
}
.m-tag-a {
    cursor: pointer;
}
a, button {
    outline: none;
}
a {
    text-decoration: none;
}
.m-banner .swipe-item img {
    height: 358px;
}
img {
    vertical-align: middle;
    border: none;
}

.sub-nav-row img{
    float: left;
    color: rgb(138, 138, 138);
    line-height: 50px;
}
.category-3-list{
    float: left;
    width: 673px;
    margin-left: 33px;
}
.category-3-list a{
    color: rgb(138, 138, 138);
    margin: auto 5px;
}
.category-3-list .li-bottom{
    border-bottom: 1px dashed rgb(197, 194, 194);
}

@keyframes lunbo{
    0%{
        background-image: url("https://res.youpin.mi-img.com/youpinoper/ac7e7de0_a28b_4fad_9749_e20cf74157d8.png");
    }
    16.6%{
        background-image: url("https://res.youpin.mi-img.com/youpinoper/887ecd4c_4d83_44f8_8cf1_56c5a707e8d2.jpeg");
    }
    33.3%{
        background-image: url("https://res.youpin.mi-img.com/youpinoper/13e7f1a2_079c_440e_8376_9008534d9f86.jpeg");
    }
    50%{
        background-image: url("https://res.youpin.mi-img.com/youpinoper/c7bf4f51_7c37_446e_b69e_7c33d9ce1798.jpeg");
    }
    66.6%{
        background-image: url("https://res.youpin.mi-img.com/youpinoper/23876f21_6a12_45f0_80b6_392c45f14dd3.jpeg");
    }
    83.3%{
        background-image: url("https://res.youpin.mi-img.com/youpinoper/6e169743_f8ed_4407_8f3f_d23ce9b3d3f1.png");
    }
    100%{
        background-image: url("https://res.youpin.mi-img.com/youpinoper/ac7e7de0_a28b_4fad_9749_e20cf74157d8.png");
    }
}
</style>
