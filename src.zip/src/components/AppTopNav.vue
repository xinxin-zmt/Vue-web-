<template>
    <div class="app-top-nav">
        <div class="w">
            <ul>
                <template v-if="userinfo.token">
                    <li><a href="javascript:;">张三</a></li>
                    <li><a href="javascript:;">退出登录</a></li>
                </template>
                <li v-else><a href="javascript:;">登录</a></li>
                <li><a href="javascript:;">注册</a></li>
                <li><a href="https://m.xiaomiyoupin.com/help">帮助中心</a></li>
                <li><a href="javascript:;"><i class="iconfont icon-phone"></i>
                        下载APP
                    </a></li>
                <li>
                    <div class="m-clauses"><a
                            class="m-safe-anchor">资质证照&nbsp;/&nbsp;协议规则</a>
                        <span class="h-icons h-down-icon h-down-icon-new">
                            <div style="width: 13px; height: 13px; cursor: default;"><svg fill="#ccc"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 22.5">
                                    <path
                                        d="M39.28.72h0a2.49,2.49,0,0,0-3.5,0L20,16.53,4.23.72A2.48,2.48,0,0,0,.72,4.23L18.24,21.78A2.48,2.48,0,0,0,20,22.5a2.52,2.52,0,0,0,1.77-.72L39.28,4.23A2.5,2.5,0,0,0,39.28.72Z">
                                    </path>
                                </svg></div>
                        </span>
                        <div class="site-nav">
                            <div class="small"><a data-src="资质证照"
                                    href="https://daren.xiaomiyoupin.com/ewen/pageFromId?id=gurkg3d4bh7bbe6q"
                                    class="">资质证照</a></div>
                            <div class="small"><a data-src="协议规则"
                                    href="https://daren.xiaomiyoupin.com/ewen/pageFromId?id=ytf4mzipem9cr7fj"
                                    class="">协议规则</a>
                            </div>
                        </div>
                    </div>                    
                </li>
            </ul>
        </div>
    </div>
</template>
<script>
import { useStore } from "vuex";
import { computed } from "vue";
export default {
    setup(props) {
        const store = useStore();
        let userinfo = computed(() => {
            return store.state.user.userinfo;
        });
        return { userinfo }
    }
};

</script>

<style lang="less" scoped>
//@import url('../assets/styles/variables.less'); 
.title-container{
    background-color:#fff;
}
.m-clauses{
    position: relative;
    text-align: center;
    padding-right: 40px;
    padding-left: 11px;
    float:left;
}
.m-site-top .site-nav li:hover a {
    color: #fff;
}

.site-nav{
    position: absolute;
    background-color: #fff;
    box-shadow: 0 0 5px rgb(216, 216, 216) inset;
    width: 140px;
    height: 70px;
    display: none;
}
.m-clauses:hover .site-nav{
    display: block;
}
.small{
    width: 140px;
    height: 35px;
    line-height: 35px;
    text-align: center;
}
.small a{
    color:#666;
}
.small:hover{
    background-color: #926626;
}
.small:hover a{
    color: #e7e7e7;
}
.app-top-nav {
    background-color: #333;
    margin: 0 auto;

    ul {
        display: flex;
        height: 48px;
        line-height: 45px;
        justify-content: flex-end;
        font-size: 14px;
        position: relative;

        li {
            a {
                color: #e7e7e7;
                padding: 0 10px;
                border-left: 1px solid #ccc;

                &:hover {
                    color: @xtxColor;
                }
            }
        }

        li:nth-child(1),
        li:nth-child(2) {
            a {
                border-left: 0;
            }
        }
    }
}
.m-safe-anchor:hover{
    cursor:pointer;
}
.box1 .block4{
    position:relative ;
}
.box1 .block4:hover .box1-block4-small{
    display: block;
}
.box1-block4-small{
    position: absolute;
    background-color: #fff;
    box-shadow: 0 0 5px rgb(216, 216, 216) inset;
    width: 140px;
    height: 70px;
    display: none;
}
.box1-small{
    width: 140px;
    height: 35px;
    line-height: 35px;
    text-align: center;
}
.box1-small a{
    color:#666;
}
.box1-small:hover{
    background-color: #926626;
}
.box1-small:hover a{
    color: #e7e7e7;
}
.m-site-top .m-clauses-con {
    position: relative;
    text-align: center;
    padding-right: 40px;
    padding-left: 11px;
}
.m-site-top .site-item-nav.hidden {
    height: 0;
    opacity: 0;
}
.m-site-top .m-clauses-con .site-item-nav {
    width: 160px;
}
.m-site-top .site-item-nav {
    position: absolute;
    left: 0;
    top: 48px;
    height: 0;
    opacity: 0;
    display: block;
    overflow: hidden;
    box-shadow: 0 3px 28px rgba(0,0,0,.1);
    transition: all .3s cubic-bezier(0,1,.5,1);
    background: #fff;
}
.hidden, .hide {
    display: none;
}
.m-site-top .site-item-nav.show {
    opacity: 1;
}
.m-site-top .m-clauses-con .show {
    height: 70px;
}
.m-site-top .m-clauses-con .site-item-nav {
    width: 160px;
}
.text-scroll-container .text-scroll .item {
    margin-right: 20px;
    color: #9f8052;
}
a, button {
    outline: none;
}
a {
    text-decoration: none;
}
.m-site-top .site-item-nav {
    position: absolute;
    left: 0;
    top: 48px;
    height: 0;
    opacity: 0;
    display: block;
    overflow: hidden;
    box-shadow: 0 3px 28px rgba(0,0,0,.1);
    transition: all .3s cubic-bezier(0,1,.5,1);
    background: #fff;
}
.fl {
    float: left;
}
.m-site-top .site-nav li:hover a {
    color: #fff;
}
.m-site-top .site-nav li a {
    display: block;
    font-size: 14px;
    color: #666;
}
.m-site-top, .m-site-top a {
    color: #e7e7e7;
}
a, button {
    outline: none;
}
a {
    text-decoration: none;
}
.m-site-top .m-clauses-con .h-down-icon {
    right: 10px;
}
.m-site-top .h-down-icon-new {
    line-height: 28px;
    top: 10px;
    right: 5px;
}
.m-site-top .h-down-icon {
    top: 10px;
    right: 0;
}
.h-icons {
    position: absolute;
}
</style>