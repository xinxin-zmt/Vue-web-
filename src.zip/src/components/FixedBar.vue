<template>
    <div class="m-fixedBar">
        <ul class="fixed-nav">
            <li><a class="m-icons m-icons- m-icons-service-fixed" data-src="" href="#!"></a>
                <p class="text">联系客服</p>
                <div class="fixed-pop fixed-service-pop ">
                    <div class="pop-inner">
                        <p class="info-title">小米有品平台问题，建议反馈，商户和物流问题投诉等请拨打 小米有品客服热线</p>
                        <p class="info-phone">952899</p>
                        <p class="info-day">(周一至周日 8：00-22：00)</p>
                        <p class="info-des">小米/米家自营品牌，手机电视智能硬件商品或订单发货/退款售后问题 请拨打小米自营客服热线</p>
                        <p class="info-phone">400-100-5678</p>
                        <p class="info-day">(周一至周日 8：00-18：00)</p>
                    </div><a class="m-icons m-icons-arrow-right " data-src="" href="#!"></a>
                </div>
            </li>
            <li><a class="m-icons m-icons- m-icons-download-active" data-src="" href="#!"></a>
                <p class="text">下载 APP</p>
                <div class="fixed-pop fixed-down-pop show p2">
                    <div class="pop-inner"><img class="qr-code"
                            src="//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/code.fcced6cb.png"
                            alt="qr-code">
                        <p class="site-info">下载小米有品APP<br>得新人礼包</p>
                    </div><a class="m-icons m-icons-arrow-right " data-src="" href="#!"></a>
                </div>
            </li>
            <li><a class="m-icons m-icons- m-icons-gift" data-src="" href="#!"></a>
                <p class="text">新人有礼</p>
                <div class="fixed-pop fixed-gift-pop p3">
                    <div class="pop-inner">
                        <div class="gift-bg"></div><img class="qr-code"
                            src="//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/code.fcced6cb.png"
                            alt="qr-code">
                        <p class="site-info">立即扫码下载·小米有品 APP</p>
                    </div><a class="m-icons m-icons-arrow-right " data-src="" href="#!"></a>
                </div>
            </li>
            <li><a class="m-icons m-icons- m-icons-wx-chat" data-src="" href="#!"></a>
                <p class="text">关注微信</p>
                <div class="fixed-pop fixed-wx-pop p4">
                    <div class="pop-inner"><img class="qr-code"
                            src="//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/wx_code.52bcbea0.png"
                            alt="qr-code">
                        <p class="site-info">扫码关注「小米有品」微信<br>服务号,签到积分赢大奖</p>
                    </div><a class="m-icons m-icons-arrow-right " data-src="" href="#!"></a>
                </div>
            </li>
            <li><a class="m-icons m-icons- m-icons-top" data-src="" href="#!"></a>
                <p class="text">回到顶部</p>
            </li>
        </ul>
    </div>
</template>
<script>
export default {

}
</script>
<style lang="less" scoped>
.m-fixedBar .fixed-down-pop {
    width: 130px;
    overflow: hidden;
}
.m-fixedBar .p1,.p2 {
    position: absolute;
    left: -120px;
    top: 0;
    padding-right: 20px;
}
.m-fixedBar .p3 {
    position: absolute;
    left: -185px;
    top: 0;
    padding-right: 20px;
}
.m-fixedBar .p4 {
    position: absolute;
    left: -180px;
    top: 0;
    padding-right: 20px;
}
.p2{
    display: none;
}
.p3{
    display: none;
}
.p4{
    display: none;
}
.m-fixedBar li:nth-child(1):hover .fixed-service-pop {
    display: block;
}
.m-fixedBar li:nth-child(2):hover .fixed-down-pop {
    display: block;
}
.m-fixedBar li:nth-child(3):hover .fixed-gift-pop {
    display: block;
}
.m-fixedBar li:nth-child(4):hover .fixed-wx-pop {
    display: block;
}
.m-fixedBar .fixed-service-pop .info-title {
    margin-top: 8px;
    color: #333;
    font-size: 12px;
}

.m-fixedBar .pop-inner {
    padding: 10px;
    border: 1px solid #dfdfdf;
    background: #fff;
}
.m-fixedBar .qr-code {
    display: block;
    width: 88px;
    height: 88px;
    margin: 0 auto 10px;
}
img {
    vertical-align: middle;
    border: none;
}
.text:hover {
    color: #cf9c4e;
}
.m-icons m-icons- m-icons-service-fixed:hover {
    color: #cf9c4e;
}
.m-fixedBar {
    position: fixed;
    top: 220px;
    right: 10px;
    z-index: 999;
    width: 81px;
    padding: 0 5px;
    background: #fff;
    box-shadow: 0 0 18px rgba(0, 0, 0, .1);
}
body,
dd,
div,
dl,
dt,
h1,
h2,
h3,
h4,
h5,
h6,
li,
ol,
p,
ul {
    margin: 0;
    padding: 0;
}
li,
ol,
ul {
    list-style: none;
}
.m-fixedBar li {
    padding: 10px;
    font-size: 12px;
    text-align: center;
    border-bottom: 1px solid #e7e7e7;
    cursor: pointer;
    position: relative;
}
.m-icons-service-fixed {
    width: 30px;
    height: 30px;
    background-position: 0 -1644px;
}
.m-icons-download-active {
    width: 30px;
    height: 30px;
    background-position: 0 -1270px;
}
.m-icons-gift {
    width: 30px;
    height: 30px;
    background-position: 0 -794px;
}
.m-icons-wx-chat {
    width: 30px;
    height: 30px;
    background-position: 0 -1270px;
}
.m-fixedBar .fixed-service-pop {
    width: 230px;
    left: -244px;
    position: absolute;
    display: none;
    top: -5px;
}
.qr-code {
    left: -500px;
}
.m-fixedBar .fixed-service-pop .info-day {
    margin-top: 1px;
    color: #666;
    font-size: 12px;
}
.m-fixedBar .fixed-service-pop .info-des {
    margin-top: 18px;
    color: #333;
    font-size: 12px;
}
.m-fixedBar .fixed-service-pop .info-phone {
    margin-top: 15px;
    color: #845f3f;
    font-size: 20px;
}
.m-fixedBar .fixed-pop .m-icons {
    position: absolute;
    right: 15px;
    top: 15px;
}
.m-icons-arrow-right {
    width: 6px;
    height: 12px;
    background-position: 0 -38px;
}
.m-fixedBar li:last-child {
    border-bottom: none;
}
.m-icons-top {
    width: 30px;
    height: 30px;
    background-position: 0 -1304px;
}
.m-icons {
    display: inline-block;
    background-image: url(//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/yp-icons.20abdb4e.png);
}
</style>