<template>
        <div class="m-footer">
            <div class="container clearfix">
                <div class="fl m-f-logo"><img
                        src="//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/logo.8cef1e8f.png"
                        alt="logo"></div>
                <div class="f-info fr">
                    <div class="f-icons"><a
                            href="https://www.xiaomiyoupin.com/app/shop/content?id=na056d0394b93a391"><img
                                src="//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/f-logo.76889756.png"></a>
                    </div>
                    <div>
                        <p class="footer-item"><span>©xiaomiyoupin.com </span><span>苏B2-20180351 苏ICP备18025642号-1
                            </span><img
                                src="//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/record-icon.0c577066.png"
                                alt="logo" style="width: 15px; height: 15px; vertical-align: -3px;"><a
                                href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=32010502010244"
                                target="_blank" rel="noopener noreferrer">苏公网安备 32010502010244号 </a></p>
                        <p class="footer-item"><span>企业名称：有品信息科技有限公司 </span><a
                                href="https://m.xiaomiyoupin.com/content/ewen/pageFromId?id=1akvh1" target="_blank"
                                rel="noopener noreferrer">关于我们 </a><a href="https://zhaoshang.xiaomiyoupin.com/"
                                target="_blank" rel="noopener noreferrer">入驻有品 </a><a
                                href="https://www.mi.com/intellectual?channel=xiaomiyoupin" target="_blank"
                                rel="noopener noreferrer">知识产权侵权投诉 </a></p>
                        <p class="footer-item"><a
                                href="https://m.xiaomiyoupin.com/content/ewen/pageFromId?id=921fb3yykmnc5gyp"
                                target="_blank" rel="noopener noreferrer" style="color: rgb(102, 102, 102);">平台运营资质证照
                            </a><a href="https://m.xiaomiyoupin.com/content/ewen/pageFromId?id=g5tbux" target="_blank"
                                rel="noopener noreferrer" style="color: rgb(102, 102, 102);">医疗器械网络交易服务第三方平台备案凭证 </a>
                        </p>
                        <p class="footer-item"><a
                                href="https://www.xiaomiyoupin.com/app/shop/content?id=s2426f03987ef05b5"
                                target="_blank" rel="noopener noreferrer">小米有品平台运营主体变更公告 </a></p>
                        <p class="footer-item"><span>南京市建邺区白龙江东街8号3栋9层 </span></p>
                    </div>
                </div>
            </div>
        </div>
</template>

<script>
export default {
}
</script>
<style lang="less" scoped>
.h-section, .home-wrap .m-footer {
    margin-top: 60px;
}
.m-footer {
    padding: 45px 0;
    height: 45px;
    line-height: 23px;
    border-top: 1px solid #e7e7e7;
    background-color: #fff;
    color: #666;
}
.container {
    width: 1080px;
    margin: 0 auto;
}
body, dd, div, dl, dt, h1, h2, h3, h4, h5, h6, li, ol, p, ul {
    margin: 0;
    padding: 0;
}
.clearfix:after, .clearfix:before {
    content: " ";
    display: table;
}
.fl {
    float: left;
}
.m-footer .m-f-logo img {
    width: 123px;
    height: 45px;
    margin-right: 25px;
}

img {
    vertical-align: middle;
    border: none;
}
.m-footer .f-info {
    position: relative;
    padding-right: 138px;
    font-size: 12px;
}
.fr {
    float: right;
}
.m-footer .f-icons {
    position: absolute;
    top: 4px;
    right: 0;
    padding-left: 14px;
}
.m-footer .f-icons img {
    width: 100px;
}
.m-footer .footer-item span {
    margin-right: 5px;
}
.m-footer .footer-item a {
    color: #666;
}
.m-footer .footer-item a, .m-footer .footer-item span {
    margin-right: 8px;
}

</style>