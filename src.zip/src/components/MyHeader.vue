<template>
    <div class="text-scroll-container">
        <div class="marquee_box text-scroll">
            <div class="title-container"><img
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAACoklEQVRYR+3X3UtTYRwH8O9z5uzF3oyIiIKK6CZCjKggFMxeNBzmztYOgTm7EIL8A7rQztwgIujCrrzaVKJaOQgjugisrruozCIiDLrJYqVEI9PzfGOGImPTnbOzNWLn7nCe5/d8zvc5L88jUOSHKHIfSsBcZ6iUYCnBXBPItf8/eQaj172rfv5gE0gNgkfKhPNka/edl+lupmDAaNRbnniHBkipgXARXDMPEorw+buHogUHjozoZZ+ejdZL0AeihcCGtIhCAkldGQyO1chkUqCHwKblnsOCJBgO+Q7DmNVAegFsXQ61+HregP09ajWl0AB5hsAOMyjbgAPXWitkItFAcj+EmHQoGJMGDgHUCOyxirIFONjjqTHIfpI77YBkqmFpim+FtO2/jJlRkOvziUvWtgQMB9QIyLZ84ywDI7r6nuDu4gUG3N9IVBYxUH1Msr5ogQNBj9sw5FDRApOwiK7eIHgx30hLb/E8KhxUTwsDFyhQLYgpAK8JHjT7O1vqJnMCpiu8sCCg9IFUCWzOJWVbgZGQu5aGUoXysuH2S7c/RqNex/RbHDUgfSRaAG40i7UVGA64X4ComkMIPHUojvZzXXfHk6fP+zqcb77Ej1NCI9FMcF02WHuBuvoB4K6F1TDwyK/HGlMhD3s7V3z9/vmUhPQJoIlkha3/4kzFwilACEy0X45tWSqp4b6O1fGJ+N89CEUjwZW2rGbSDWoFuLjO/avn105OTzWTyeWaOAHSqTgUV1vXvQfpxjO9aQoH1Fcg9y0UyyLBTOnevHK2Uv6eObCtdu9IXZ0+axPQ0wnKXjuAWb1A2TRKbdMfdB+jhB8ULoBP/Hqs2UqdbPqYnuLFRZMf7LmvjdBlNoNZaZMT0MqAZvuUgGYTS21fSvC/T/APsXEzOBI1p8gAAAAASUVORK5CYII="
                    class="icon"><span class="title">质量公告:</span></div>
            <p class="sc-dlfnuX cWHsYR"><a class="item"
                    href="https://m.xiaomiyoupin.com/content/ewen/book?id=PnfkRW&amp;nodeId=660b63e545b14c00018d8e17">医疗器械质量公告</a>
            </p>
        </div>
    </div>
    <div class="m-header clearfix header-class">
        <div class="">
            <div class="container">
                <div class="clearfix m-header-top">
                    <div class="m-logo m-tag-a" data-src="/"></div>
                    <div class="nav-part"></div>
                    <ul class="tab-list">
                        <li data-src="https://m.xiaomiyoupin.com/r/secbuy?type=secbuy" class="tab-item">有品秒杀</li>
                    </ul>
                    <div class="m-card-wrap fr">
                        <div class="m-card-mini">
                            <div style="width: 25px; height: 25px; cursor: default;"><svg fill="#333"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 41.97 41.04">
                                    <path
                                        d="M31.74,33.24H16.66c-1.9,0-4.16-1.94-4.49-4.83-.11-.93-.36-3.91-.66-7.35-.39-4.61-.89-10.36-1.17-12.89C9.9,4.3,8.38,3,7.75,3H1.5V0H7.75c2.14,0,4.54,2.05,5.38,6.58H37a4.77,4.77,0,0,1,3.76,1.79,5.5,5.5,0,0,1,1.13,4.5l-.13.67c-.63,3.17-2.3,11.58-3.24,14.56C37.35,31.75,35.39,33.24,31.74,33.24ZM13.5,9.58c.29,2.94.68,7.46,1,11.23.3,3.41.55,6.36.65,7.26a2.5,2.5,0,0,0,1.52,2.17H31.74c2.07,0,3.07-.43,3.9-3,.89-2.82,2.59-11.42,3.15-14.25l.14-.67a2.48,2.48,0,0,0-.51-2A1.84,1.84,0,0,0,37,9.58Z">
                                    </path>
                                    <circle cx="16.47" cy="37.95" r="3"></circle>
                                    <circle cx="34.32" cy="37.95" r="3"></circle>
                                    <circle cx="1.5" cy="1.5" r="1.5"></circle>
                                </svg></div>
                        </div>
                    </div>
                    <div class="m-search">
                        <div class="search-form ">
                            <div class="search-icon">
                                <div style="width: 20px; height: 20px; cursor: default;"><svg fill="#333"
                                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
                                        <path
                                            d="M47.27,43.74,37.5,34A21,21,0,1,0,34,37.5l9.78,9.77a2.5,2.5,0,0,0,3.53-3.53ZM5,21A16,16,0,1,1,21,37,16,16,0,0,1,5,21Z">
                                        </path>
                                    </svg></div>
                            </div>
                            <div class="m-autocomplete search-input-con"><input type="text" placeholder="净水器" value="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- 二级导航 -->
    <AppHeaderNav />
</template>
<script>
import { useStore } from 'vuex'
import { computed } from 'vue'
import AppHeaderNav from './AppHeaderNav.vue'
export default {
    components: {
        AppHeaderNav
    },
    setup(props) {
        const store = useStore();
        // 使用命名空间来调用 action
        store.dispatch('category/getAllCategory');
        // 从仓库里读取分类列表
        const list = computed(() => {
            return store.state.cateList;
        })
    }
}
</script>

<style lang="less" scoped>
.m-header-top {
    position: relative;
    padding-right: 40px;
    z-index: 9;
}
.text-scroll-container {
    display: flex;
    justify-content: center;
    font-size: 13px;
    color: #9f8052;
}

body,
dd,
div,
dl,
dt,
h1,
h2,
h3,
h4,
h5,
h6,
li,
ol,
p,
ul {
    margin: 0;
    padding: 0;
}

.text-scroll-container .text-scroll {
    max-width: 1080px;
}

.marquee_box {
    width: 100%;
    height: 38px;
    overflow: hidden;
    word-break: keep-all;
    white-space: nowrap;
    display: flex;
    align-items: center;
}

.text-scroll-container .text-scroll {
    max-width: 1080px;
}

.marquee_box {
    width: 100%;
    height: 38px;
    overflow: hidden;
    word-break: keep-all;
    white-space: nowrap;
    display: flex;
    align-items: center;
}

.marquee_box p {
    display: inline-block;
}

.cWHsYR {
    position: relative;
    left: 1080px;
    animation: 40s linear 0s infinite normal forwards running marquee_124;
}

@keyframes marquee_124 {
    0% {
        transform: translateX(0px);
    }

    100% {
        transform: translateX(-1204px);
    }
}

.icon {
    width: 20px;
    height: 20px;
    margin-right: 2px;
}

img {
    vertical-align: middle;
    border: none;
}

.title {
    margin-right: 6px;
}

.text-scroll-container .text-scroll .item {
    margin-right: 20px;
    color: #9f8052;
}

a,
button {
    outline: none;
}

a {
    text-decoration: none;
}

* {
    margin: 0;
    padding: 0;
}

body {
    font-size: 14px;
    font-family: Helvetica Neue, Helvetica, Arial, Microsoft Yahei, Hiragino Sans GB, Heiti SC, WenQuanYi Micro Hei, sans-serif;
}

a {
    text-decoration: none;
    color: #fff;
}

.clearfix::after {
    content: "";
    display: block;
    clear: both;
}
.header-class {
    padding-top: 0;
}
.m-header {
    position: relative;
    z-index: 101;
    margin-bottom: 5px;
    background-color: #fff;
}
div {
    display: block;
}
.container {
    width: 1080px;
    margin: 0 auto;
}
.m-header-top {
    position: relative;
    padding-right: 40px;
    z-index: 9;
}
.m-header .m-logo {
    float: left;
    width: 123px;
    height: 51px;
    background: url(//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/logo.8cef1e8f.png) 50% no-repeat;
    background-size: 100%;
}
.m-logo {
    width: 100px;
    height: 50px;
    line-height: 50px;
    text-align: center;
    font-size: 12px;
}
.m-tag-a {
    cursor: pointer;
}
.m-header .nav-part {
    float: left;
    margin-left: 10px;
    margin-right: 70px;
    width: 60px;
    height: 51px;
    line-height: 51px;
}
.m-header .tab-list {
    float: left;
    width: 420px;
    overflow: hidden;
}
li, ol, ul {
    list-style: none;
}
.m-header .tab-list li.tab-item {
    float: left;
    margin-right: 32px;
    height: 51px;
    line-height: 57px;
    font-size: 18px;
    color: #666;
    transition: color .2s ease;
}
.m-card-wrap {
    position: absolute;
    right: 6px;
    top: 18px;
}
.fr {
    float: right;
}
.m-card-mini {
    position: relative;
    width: 30px;
}
.m-header .m-search {
    float: right;
}
.m-search {
    width: 296px;
}
.search-form {
    position: relative;
    width: 246px;
    padding-left: 35px;
    padding-top: 9px;
    height: 32px;
    border-bottom: 1px solid #e7e7e7;
    transition: all .3s;
}
.search-form .search-icon {
    position: absolute;
    left: 0;
    top: 14px;
    display: block;
    z-index: 2;
    text-align: center;
    outline: 0;
    font-size: 14px;
}
element.style {
    width: 20px;
    height: 20px;
    cursor: pointer;
}
.search-input-con {
    z-index: 1;
    width: 245px;
    height: 32px;
    line-height: 32px;
}
.search-input-con input {
    width: 100%;
    border: none;
    color: #333;
    font-size: 14px;
    outline: 0;
    transition: all .2s;
}

</style>