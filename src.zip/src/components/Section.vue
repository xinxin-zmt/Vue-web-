<template>
    <div class="p-hero-wrap section">
        <div class="container" style="border-bottom-color: rgb(231, 231, 231);">
            <div class="line-container">
                <ul class="p-hreo-nav clearfix">
                    <div class="kingkong-column" style="min-height: 0px;">
                        <li class="m-tag-a " data-target="_blank"
                            data-src="https://m.xiaomiyoupin.com/w/new_product_v3?_rt=weex&amp;pageid=4728&amp;sign=846b35b9e94a50a84a0d07b9ab2cc36a&amp;pdl=jianyu">
                            <div>
                                <div class="m-product-image-container undefined"
                                    data-src="https://img.youpin.mi-img.com/ferriswheel/9080855f_d1f1_4bd9_b427_b60fa7cc1992.png?w=180&amp;h=180"
                                    style="width: 116px; height: 116px;">
                                    <div class="img-container" style="width: 116px; height: 116px;"><img
                                            src="https://img.youpin.mi-img.com/ferriswheel/9080855f_d1f1_4bd9_b427_b60fa7cc1992.png?w=180&amp;h=180"
                                            data-src="https://img.youpin.mi-img.com/ferriswheel/9080855f_d1f1_4bd9_b427_b60fa7cc1992.png?w=180&amp;h=180"
                                            alt="上新精选" style="width: 116px; height: 116px;"></div>
                                </div>
                            </div>
                            <p class="title" style="color: rgb(0, 0, 0);">上新精选</p>
                        </li>
                    </div>
                    <div class="kingkong-column" style="min-height: 0px;">
                        <li class="m-tag-a " data-target="_blank"
                            data-src="https://m.xiaomiyoupin.com/w/crowdfundV3?_rt=weex&amp;pageid=9433&amp;sign=e50311198e28d0dff1c5d38d97ad1aee&amp;pdl=jianyu">
                            <div>
                                <div class="m-product-image-container undefined"
                                    data-src="https://img.youpin.mi-img.com/ferriswheel/jqdqm5q81n8_22028918941626687376754.png?w=180&amp;h=180"
                                    style="width: 116px; height: 116px;">
                                    <div class="img-container" style="width: 116px; height: 116px;"><img
                                            src="https://img.youpin.mi-img.com/ferriswheel/jqdqm5q81n8_22028918941626687376754.png?w=180&amp;h=180"
                                            data-src="https://img.youpin.mi-img.com/ferriswheel/jqdqm5q81n8_22028918941626687376754.png?w=180&amp;h=180"
                                            alt="小米众筹" style="width: 116px; height: 116px;"></div>
                                </div>
                            </div>
                            <p class="title" style="color: rgb(0, 0, 0);">小米众筹</p>
                        </li>
                    </div>
                    <div class="kingkong-column" style="min-height: 0px;">
                        <li class="m-tag-a " data-target="_blank"
                            data-src="https://m.xiaomiyoupin.com/r/secbuy?type=secbuy">
                            <div>
                                <div class="m-product-image-container undefined"
                                    data-src="https://img.youpin.mi-img.com/ferriswheel/aphcvmd2gvg_22028918941626688016327.png?w=180&amp;h=180"
                                    style="width: 116px; height: 116px;">
                                    <div class="img-container" style="width: 116px; height: 116px;"><img
                                            src="https://img.youpin.mi-img.com/ferriswheel/aphcvmd2gvg_22028918941626688016327.png?w=180&amp;h=180"
                                            data-src="https://img.youpin.mi-img.com/ferriswheel/aphcvmd2gvg_22028918941626688016327.png?w=180&amp;h=180"
                                            alt="有品秒杀" style="width: 116px; height: 116px;"></div>
                                </div>
                            </div>
                            <p class="title" style="color: rgb(0, 0, 0);">有品秒杀</p>
                        </li>
                    </div>
                    <div class="kingkong-column" style="min-height: 0px;">
                        <li class="m-tag-a " data-target="_blank"
                            data-src="https://m.xiaomiyoupin.com/w/universal_1?_rt=weex&amp;pageid=6836&amp;sign=94147275592ceaaffcf4d996a82e0e09&amp;pdl=jianyu">
                            <div>
                                <div class="m-product-image-container undefined"
                                    data-src="https://img.youpin.mi-img.com/ferriswheel/ea317c7c_ef18_4ee7_91ab_15fa62c72e19.png?w=180&amp;h=180"
                                    style="width: 116px; height: 116px;">
                                    <div class="img-container" style="width: 116px; height: 116px;"><img
                                            src="https://img.youpin.mi-img.com/ferriswheel/ea317c7c_ef18_4ee7_91ab_15fa62c72e19.png?w=180&amp;h=180"
                                            data-src="https://img.youpin.mi-img.com/ferriswheel/ea317c7c_ef18_4ee7_91ab_15fa62c72e19.png?w=180&amp;h=180"
                                            alt="生活优选" style="width: 116px; height: 116px;"></div>
                                </div>
                            </div>
                            <p class="title" style="color: rgb(0, 0, 0);">生活优选</p>
                        </li>
                    </div>
                    <div class="kingkong-column" style="min-height: 0px;">
                        <li class="m-tag-a " data-target="_blank"
                            data-src="https://m.xiaomiyoupin.com/w/universal_1?_rt=weex&amp;pageid=7123&amp;sign=c99a44acccc55af79bf0e5dfd171790e&amp;pdl=jianyu">
                            <div>
                                <div class="m-product-image-container undefined"
                                    data-src="https://img.youpin.mi-img.com/sketch/79ca50c5_dc92_41da_bf5d_08ea24bb9652.png?w=180&amp;h=180"
                                    style="width: 116px; height: 116px;">
                                    <div class="img-container" style="width: 116px; height: 116px;"><img
                                            src="https://img.youpin.mi-img.com/sketch/79ca50c5_dc92_41da_bf5d_08ea24bb9652.png?w=180&amp;h=180"
                                            data-src="https://img.youpin.mi-img.com/sketch/79ca50c5_dc92_41da_bf5d_08ea24bb9652.png?w=180&amp;h=180"
                                            alt="小米自营" style="width: 116px; height: 116px;"></div>
                                </div>
                            </div>
                            <p class="title" style="color: rgb(0, 0, 0);">小米自营</p>
                        </li>
                    </div>
                </ul>
            </div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>
body, dd, div, dl, dt, h1, h2, h3, h4, h5, h6, li, ol, p, ul {
    margin: 0;
    padding: 0;
}
div.p-hero-wrap .container {
    padding-top: 30px;
    border-bottom-width: 1px;
    border-bottom-style: solid;
    overflow: hidden;
}
.container {
    width: 1080px;
    margin: 0 auto;
}
div.p-hero-wrap .container .line-container {
    display: inline-block;
}

div.p-hero-wrap .p-hreo-nav {
    overflow: hidden;
    padding-bottom: 10px;
}

li, ol, ul {
    list-style: none;
}
.clearfix:after, .clearfix:before {
    content: " ";
    display: table;
}
div.p-hero-wrap .p-hreo-nav .kingkong-column:first-child {
    margin-left: 28px;
}

div.p-hero-wrap .p-hreo-nav .kingkong-column {
    width: 116px;
    height: 100%;
    min-height: 277px;
    display: inline-block;
    margin-right: 110px;
}
div.p-hero-wrap .p-hreo-nav li:last-child {
    margin-right: 0;
}

div.p-hero-wrap .p-hreo-nav li {
    float: left;
    width: 116px;
}
.m-tag-a {
    cursor: pointer;
}
.m-product-image-container {
    overflow: hidden;
}

.m-product-image-container .img-container {
    overflow: hidden;
    display: inline-block;
}
div.p-hero-wrap .p-hreo-nav img {
    width: 116px;
    height: 116px;
}
img {
    vertical-align: middle;
    border: none;
}
div.p-hero-wrap .p-hreo-nav li .title {
    font-size: 14px;
    margin-top: 4px;
    width: 116px;
    text-align: center;
    color: #999;
}
div.p-hero-wrap .p-hreo-nav .kingkong-column {
    width: 116px;
    height: 100%;
    min-height: 277px;
    display: inline-block;
    margin-right: 110px;
}
div.p-hero-wrap .p-hreo-nav li:last-child {
    margin-right: 0;
}
div.p-hero-wrap .p-hreo-nav li {
    float: left;
    width: 116px;
}
.m-tag-a {
    cursor: pointer;
}

.m-product-image-container {
    overflow: hidden;
}

.m-product-image-container .img-container {
    overflow: hidden;
    display: inline-block;
}
div.p-hero-wrap .p-hreo-nav img {
    width: 116px;
    height: 116px;
}
img {
    vertical-align: middle;
    border: none;
}
div.p-hero-wrap .p-hreo-nav li .title {
    font-size: 14px;
    margin-top: 4px;
    width: 116px;
    text-align: center;
    color: #999;
}
.title {
    margin-right: 6px;
}
div.p-hero-wrap .p-hreo-nav .kingkong-column:last-child {
    margin-right: 28px;
}
div.p-hero-wrap .p-hreo-nav .kingkong-column {
    width: 116px;
    height: 100%;
    min-height: 277px;
    display: inline-block;
    margin-right: 110px;
}
div.p-hero-wrap .p-hreo-nav li:last-child {
    margin-right: 0;
}
div.p-hero-wrap .p-hreo-nav li {
    float: left;
    width: 116px;
}

li, ol, ul {
    list-style: none;
}
.m-product-image-container {
    overflow: hidden;
}
.m-product-image-container .img-container {
    overflow: hidden;
    display: inline-block;
}
img {
    vertical-align: middle;
    border: none;
}

</style>
