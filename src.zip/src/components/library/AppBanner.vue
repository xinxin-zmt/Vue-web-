<template>
  <el-carousel height="358px">
    <el-carousel-item v-for="item in imgList" :key="item.id">
      <img src="https://img.youpin.mi-img.com/youpinoper/ea993175_aa74_4be9_a444_bdd0901a4730.jpeg?w=1080&amp;h=450" >
    </el-carousel-item>
  </el-carousel>
</template>
<script>
export default {
  data() {
    return {
      imgList: [
        { id: '1', src: 'https://img.youpin.mi-img.com/youpinoper/ea993175_aa74_4be9_a444_bdd0901a4730.jpeg?w=1080&amp;h=450'},
        { id: '2', src: 'https://img.youpin.mi-img.com/youpinoper/cb93a1da_08d9_46e3_aa9c_25c6549a0fe4.jpeg?w=1080&amp;h=450'},
        { id: '3', src: 'https://img.youpin.mi-img.com/youpinoper/380d3e43_dbef_4bad_90c5_118a59f19caf.jpeg?w=1080&amp;h=450'},
        { id: '4', src: 'https://img.youpin.mi-img.com/youpinoper/051115c6_7660_4e6e_bd5a_0b3daf8281f5.jpeg?w=1080&amp;h=450'},
        { id: '5', src: 'https://img.youpin.mi-img.com/youpinoper/f8ede245_b7fd_4344_b9b3_ea7b63767718.png?w=1080&amp;h=450'}
      ]
    // name:'AppBanner',
    // props:{
    //     list:{
    //         type:Array,
    //         default:[]
    //     }
    // }
    }
  }
}
</script>
<style lang="less" scoped>
.el-carousel__item h3 {
    color: #475669;
    font-size: 18px;
    opacity: 0.75;
    line-height: 300px;
    margin: 0;
  }
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
  
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
</style> 