import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from'./store'
import ElementPlus from 'element-plus' // ①导入模块
import 'element-plus/dist/index.css' // ②导入样式
//引入初始化样式
import '@/assets/styles/base.css'
import '@/assets/styles/variables.less'
import myElement from'@/components/library'
createApp(App).use(store).use(router).use(ElementPlus).use(myElement).mount('#app')

