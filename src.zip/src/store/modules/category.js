import { createStore } from 'vuex'
import { getCategoryList } from '@/api/index'
import {topCategory} from'@/utils/constants'
export default createStore({
    namespaced:true,
    state: ()=>{
        return{
            cateList:topCategory
        }
    },
    mutations: {
        setList(state, payload) {
            state.cateList = payload;
        }
    },
    actions: {
        async getAllCategory({ commit }) {
            try {
                const res = await getCategoryList();
                if (res.code === '200') {
                    commit('setList', res.cateList)
                }
            }
            catch (error) {
                console.log(error)
            }
        }
    }
})