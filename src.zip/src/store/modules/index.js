// 搜索所有的vuex模块
import user from './user'
import category  from './category'
export default {
    user,
    category
}