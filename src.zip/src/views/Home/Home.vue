<template>
  <div class="home w">
    <div class="h-section h-crowdfounding">
      <div class="container clearfix">
        <div class="h-sec-top clearfix">
          <h2 class="h-subTit">小米有品众筹<span>永远好奇 永远年轻</span></h2><span class="h-more" data-src=""
            data-target="_blank"><span>更多</span><a class="m-icons m-icons-more more-icon" data-src=""
              href="#!"></a></span>
        </div>
        <div class="m-sec-main mt1">
          <div class="home-good-item  m-tag-a item-pos0 home-good-item-big no-ml h1"
            data-src="https://www.xiaomiyoupin.com/detail?gid=167332" data-target="_blank">
            <div class="item-inner i1" style="background-color: rgb(249, 243, 233);"><img class="pro-img"
                src="https://img.youpin.mi-img.com/shop-fe/701184ba_93b4_46cc_82ab_369c9b3ec853.png"
                data-src="https://img.youpin.mi-img.com/shop-fe/701184ba_93b4_46cc_82ab_369c9b3ec853.png" alt=""
                style="margin-top: 0px;">
              <div class="pro-text">
                <p class="pro-info" title="贵州习酒江山多娇">贵州习酒江山多娇</p>
                <p class="pro-desc" title="酱香突出， 宴请送礼， 空杯留香">酱香突出， 宴请送礼， 空杯留香</p>
                <p class="pro-price"><span class="tag">¥</span><span>369</span><span class="pro-flag">起</span></p>
              </div>
            </div>
            <div class="m-progress-wrap-con">
              <div class="m-bar-con">
                <div class="m-bar" style="width: 100%;"></div>
              </div>
              <div class="m-progress-info clearfix">
                <div class="fl m-suppory"><span class="sup-num">418</span>人支持</div><span
                  class="progress-tag-con fl"><span class="common-tag common-tag-text"
                    style="background-color: rgb(254, 207, 0);">热</span></span>
                <div class="fr m-persent">
                  <div><span class="m-num">100</span><span class="m-num-flag">%</span></div>
                </div>
              </div>
            </div>
          </div>
          <div class="home-good-item  m-tag-a item-pos1 h2  " data-src="https://www.xiaomiyoupin.com/detail?gid=166770"
            data-target="_blank">
            <div class="item-inner i2" style="background-color: rgb(248, 248, 248);"><img class="pro-img"
                src="https://img.youpin.mi-img.com/shop-fe/0b624849_115b_4c59_81a3_ddd63d846ef2.png"
                data-src="https://img.youpin.mi-img.com/shop-fe/0b624849_115b_4c59_81a3_ddd63d846ef2.png" alt=""
                style="margin-top: 0px;">
              <div class="pro-text">
                <p class="pro-info" title="云米掌静脉人脸锁">云米掌静脉人脸锁</p>
                <p class="pro-price"><span class="tag">¥</span><span>1999</span></p>
              </div>
            </div>
            <div class="m-progress-wrap-con">
              <div class="m-bar-con">
                <div class="m-bar" style="width: 257%;"></div>
              </div>
              <div class="m-progress-info m-progress-info-small clearfix">
                <div class="fl m-suppory"><span class="sup-num">704</span>人支持</div><span
                  class="progress-tag-con fl"><span class="common-tag common-tag-text"
                    style="background-color: rgb(254, 207, 0);">热</span></span>
                <div class="fr m-persent">
                  <div><span class="m-num">257</span><span class="m-num-flag">%</span></div>
                </div>
              </div>
            </div>
          </div>
          <div class="home-good-item  m-tag-a item-pos2 h3  " data-src="https://www.xiaomiyoupin.com/detail?gid=167180"
            data-target="_blank">
            <div class="item-inner i3" style="background-color: rgb(248, 248, 248);"><img class="pro-img"
                src="https://img.youpin.mi-img.com/shop-fe/058c9f72_9aaf_42fb_ada0_e739bc0a65ab.png"
                data-src="https://img.youpin.mi-img.com/shop-fe/058c9f72_9aaf_42fb_ada0_e739bc0a65ab.png" alt=""
                style="margin-top: 0px;">
              <div class="pro-text">
                <p class="pro-info" title="电动颈部固定器">电动颈部固定器</p>
                <p class="pro-price"><span class="tag">¥</span><span>399</span></p>
              </div>
            </div>
            <div class="m-progress-wrap-con">
              <div class="m-bar-con">
                <div class="m-bar" style="width: 220%;"></div>
              </div>
              <div class="m-progress-info m-progress-info-small clearfix">
                <div class="fl m-suppory"><span class="sup-num">2880</span>人支持</div><span
                  class="progress-tag-con fl"><span class="common-tag common-tag-text"
                    style="background-color: rgb(254, 207, 0);">热</span></span>
                <div class="fr m-persent">
                  <div><span class="m-num">220</span><span class="m-num-flag">%</span></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="p-trap-wrap">
      <div class="container clearfix">
        <div class="h-sec-top clearfix">
          <div class="trap-top-main fl"><span class="h-subTit fl">有品秒杀<span class="timestr"><img
                  src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKE1hY2ludG9zaCkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ODE4NDU0MzZBMUNFMTFFODhFQUZGMUEzNDU1MUNGRjUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6ODE4NDU0MzdBMUNFMTFFODhFQUZGMUEzNDU1MUNGRjUiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo4MTg0NTQzNEExQ0UxMUU4OEVBRkYxQTM0NTUxQ0ZGNSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo4MTg0NTQzNUExQ0UxMUU4OEVBRkYxQTM0NTUxQ0ZGNSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PjQBja0AAANrSURBVHja7JhbSFRRFIbPMZWKykwjJQgs0Ihq6KXMKAfKQNOKohJ6kIh66/YmlUXY5SEqSSroRaSHSssiFYuKktJqXlKE6GqPJuS1C5jJ9G/4J1bDuextI/nQgo9ZM2fvdf69zz5rrz12OBy2xpPFR5yauSn/XMzWzh4rzhpn5icoHTwA30G5R7vT4Bs/3ewU29wDM90a2ZE15PDIFoEGMIffu0GaS5wfIAH85KeTDYBp9D+AQvBa95GtBS1CzBDYI65ngAPgFngjRKg1+Q7c5vUM0Uf1H6Y/D7SC1ToztANcFgu+F2wET8AqUMZAtsaSUMEfguOgmf1ugiReVwJ3giteM1QpxKjRZoNX4DqDrtEUY7Gdav+Y/dvACvCR19XMnvFb1OfAINdPDpgIXqoBiDZqrdSDXSDAEdv8DPD3erb7vUQYJ46DVIu7H1zUXdQWg6vRTRePoAYc5drxsyxwjGJssbhzQbtpHlKvfJMQowIVgWJNMRbbFbNfP39LYtx00zxULTr1cFSNo8xDql+QcSKDrTYRtBnk0R8BW5ymWNg+MBns92jTzrgj/J7HuFqCjgj/PHjk82gSovdGF1NvaYX4XqYjaBlYTP8rc0gs7QTjRnaDbD9BG4Rfz8QYS+tj3Iit9xOUI/y6MdrU61zu5ygoS/ihMRIUcrmfo6Bk4Xdr3mBY+Gka7T+53M+3HkrUFDQk/BdgocFs2X6C+oQ/WzPobtZEFkuWpyxh3EzOYq+fILktzNcUdJUCesX20MhSxsmWCP+tn6BW4a8zmPpm5pT3IklWuLQtFH6Ln6A7wlcb4wwDUap+Ws480+MiKJlxZa7zFPQcdNCfAg4bvtKfmexSWaZE2yHGtXifZzpvmTxh7OVOHwvLjdqAy3U311pwn/4E1sGBvxSj+t9gPIvxa03qoRKRwFJYORaMUkwBK4ZUkRhLTAu0LpDPStFi5ajq7GsgU1NIJts3iIw8wLhdnmd7F1MdJ0Vl1W0stJr4RoZ4ivgCpvIstpQLO9/hHoncUNtMBZWCk/TVKeSuOHnEs04uMnhstRSpBniBa6nS5JGViZNGKWcmyLO+7n84kYNikIM56FUt+s1QFdjOIJdENm7mY9kEVoIFYBbP7YPMQx086aqjdqeIeVaIqTL9s+H//0N/zNB4sV8CDACpgNIYcitWCgAAAABJRU5ErkJggg=="
                  alt=""><span>12:00场</span></span></span>
            <div class="countdown fl">
              <div class="h-countdown-wrap"><span class="time-item-home hour">19</span><span
                  class="m-countdown-dot-home">:</span><span class="time-item-home minute">34</span><span
                  class="m-countdown-dot-home">:</span><span class="time-item-home second">51</span></div>
            </div>
          </div><span class="h-more" data-src="" data-target="_blank"><span>更多</span><a
              class="m-icons m-icons-more more-icon" data-src="" href="#!"></a></span>
        </div>
        <div class="swiper-container swiper-container-horizontal">
          <div class="swiper-wrapper">
            <div class="swiper-slide swiper-slide-active" style="width: 266.25px; margin-right: 5px;">
              <div class="m-goods-item-container first pro-item-trap margin-left-0"
                data-src="https://www.xiaomiyoupin.com/detail?gid=154575&amp;pid=385457" data-target="_blank">
                <div class="bigtrap-img-tag-container">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/shop-fe/6cfd69fe_abb4_4760_a2a7_cff49c867cfe.jpeg">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/shop-fe/6cfd69fe_abb4_4760_a2a7_cff49c867cfe.jpeg"
                          data-src="https://img.youpin.mi-img.com/shop-fe/6cfd69fe_abb4_4760_a2a7_cff49c867cfe.jpeg"
                          alt="万里宋境宴" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                </div>
                <div class="bigtrap-box">
                  <p class="pro-info" title="万里宋境宴">万里宋境宴</p>
                  <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">225</span><span
                      class="pro-flag">起</span><span class="market-price"><span class="pro-unit">¥</span><span
                        class="m-num">699</span></span></p>
                </div>
              </div>
            </div>
            <div class="swiper-slide swiper-slide-next" style="width: 266.25px; margin-right: 5px;">
              <div class="m-goods-item-container  pro-item-trap margin-left-0"
                data-src="https://www.xiaomiyoupin.com/detail?gid=161629&amp;pid=450540" data-target="_blank">
                <div class="bigtrap-img-tag-container">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/shop-fe/b7b31345_215a_412a_9dd6_d4f9c219e6bc.jpeg">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/shop-fe/b7b31345_215a_412a_9dd6_d4f9c219e6bc.jpeg"
                          data-src="https://img.youpin.mi-img.com/shop-fe/b7b31345_215a_412a_9dd6_d4f9c219e6bc.jpeg"
                          alt="0脂黑咖啡" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                </div>
                <div class="bigtrap-box">
                  <p class="pro-info" title="0脂黑咖啡">0脂黑咖啡</p>
                  <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">9</span><span
                      class="pro-flag">起</span><span class="market-price"><span class="pro-unit">¥</span><span
                        class="m-num">25.9</span></span></p>
                </div>
              </div>
            </div>
            <div class="swiper-slide" style="width: 266.25px; margin-right: 5px;">
              <div class="m-goods-item-container  pro-item-trap margin-left-0"
                data-src="https://www.xiaomiyoupin.com/detail?gid=159799&amp;pid=421406" data-target="_blank">
                <div class="bigtrap-img-tag-container">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/shop-fe/95f58d9a_014d_4f96_9454_b3fefd3422b0.jpeg">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/shop-fe/95f58d9a_014d_4f96_9454_b3fefd3422b0.jpeg"
                          data-src="https://img.youpin.mi-img.com/shop-fe/95f58d9a_014d_4f96_9454_b3fefd3422b0.jpeg"
                          alt="解酒益生菌燃酒灵" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                </div>
                <div class="bigtrap-box">
                  <p class="pro-info" title="解酒益生菌燃酒灵">解酒益生菌燃酒灵</p>
                  <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">49</span><span
                      class="pro-flag">起</span><span class="market-price"><span class="pro-unit">¥</span><span
                        class="m-num">119</span></span></p>
                </div>
              </div>
            </div>
            <div class="swiper-slide" style="width: 266.25px; margin-right: 5px;">
              <div class="m-goods-item-container  pro-item-trap margin-left-0"
                data-src="https://www.xiaomiyoupin.com/detail?gid=166851&amp;pid=458062" data-target="_blank">
                <div class="bigtrap-img-tag-container">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/shop-fe/d38bf179_965a_4d52_9fc2_3d496f83d87b.jpeg">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/shop-fe/d38bf179_965a_4d52_9fc2_3d496f83d87b.jpeg"
                          data-src="https://img.youpin.mi-img.com/shop-fe/d38bf179_965a_4d52_9fc2_3d496f83d87b.jpeg"
                          alt="小悬壶砭石揉腹仪" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                </div>
                <div class="bigtrap-box">
                  <p class="pro-info" title="小悬壶砭石揉腹仪">小悬壶砭石揉腹仪</p>
                  <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">119</span><span
                      class="pro-flag">起</span><span class="market-price"><span class="pro-unit">¥</span><span
                        class="m-num">259</span></span></p>
                </div>
              </div>
            </div>
            <div class="swiper-slide" style="width: 266.25px; margin-right: 5px;">
              <div class="m-goods-item-container first pro-item-trap margin-left-0"
                data-src="https://www.xiaomiyoupin.com/detail?gid=160109&amp;pid=420789" data-target="_blank">
                <div class="bigtrap-img-tag-container">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/shop-fe/9010a637_2810_48b5_9550_6da1656e5449.jpeg">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/shop-fe/9010a637_2810_48b5_9550_6da1656e5449.jpeg"
                          data-src="https://img.youpin.mi-img.com/shop-fe/9010a637_2810_48b5_9550_6da1656e5449.jpeg"
                          alt="指纹首饰收纳盒" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                </div>
                <div class="bigtrap-box">
                  <p class="pro-info" title="指纹首饰收纳盒">指纹首饰收纳盒</p>
                  <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">168</span><span
                      class="pro-flag">起</span><span class="market-price"><span class="pro-unit">¥</span><span
                        class="m-num">369</span></span></p>
                </div>
              </div>
            </div>
            <div class="swiper-slide" style="width: 266.25px; margin-right: 5px;">
              <div class="m-goods-item-container  pro-item-trap margin-left-0"
                data-src="https://www.xiaomiyoupin.com/detail?gid=157010&amp;pid=402359" data-target="_blank">
                <div class="bigtrap-img-tag-container">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/shop-fe/b431e147_8325_4d2c_a4db_5a9cde99bc21.jpeg">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/shop-fe/b431e147_8325_4d2c_a4db_5a9cde99bc21.jpeg"
                          data-src="https://img.youpin.mi-img.com/shop-fe/b431e147_8325_4d2c_a4db_5a9cde99bc21.jpeg"
                          alt="BINNIFA户外音响" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                </div>
                <div class="bigtrap-box">
                  <p class="pro-info" title="BINNIFA户外音响">BINNIFA户外音响</p>
                  <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">999</span><span
                      class="pro-flag">起</span><span class="market-price"><span class="pro-unit">¥</span><span
                        class="m-num">1999</span></span></p>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-button-next m-icons m-icons-next-hover"></div>
          <div class="swiper-button-prev m-icons m-icons-forward-hover swiper-button-disabled"></div>
        </div>
      </div>
    </div>
    <div class="h-section h-new-sec">
      <div class="container clearfix">
        <div class="h-sec-top clearfix">
          <h2 class="h-subTit">每日新品<span>每天10点 惊喜不断</span></h2><span class="h-more" data-src=""
            data-target="_blank"><span>更多</span><a class="m-icons m-icons-more more-icon" data-src=""
              href="#!"></a></span>
        </div>
        <div class="m-sec-main mt1">
          <div class="swiper-container swiper-container-horizontal">
            <div class="swiper-wrapper">
              <div class="swiper-slide swiper-slide-active" style="width: 266.25px; margin-right: 5px;">
                <div class="m-goods-item-container new-item-container first pro-item-sec margin-left-0"
                  data-src="https://www.xiaomiyoupin.com/detail?gid=167361" data-target="_blank">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/youpin_gms/b8de1388_fdbd_4ad2_82de_654fce20c89f.jpeg?w=800&amp;h=800">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/youpin_gms/b8de1388_fdbd_4ad2_82de_654fce20c89f.jpeg?w=800&amp;h=800"
                          data-src="https://img.youpin.mi-img.com/youpin_gms/b8de1388_fdbd_4ad2_82de_654fce20c89f.jpeg?w=800&amp;h=800"
                          alt="米家空气炸锅N1" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                  <div class="m-goods-common-box">
                    <p class="pro-info" title="米家空气炸锅N1">米家空气炸锅N1</p>
                    <p class="pro-desc" title="烹饪可视化 | 烹饪免翻面 | 金属内腔 | 5L大容量">烹饪可视化 | 烹饪免翻面 | 金...</p>
                    <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">199</span></p>
                  </div>
                </div>
              </div>
              <div class="swiper-slide swiper-slide-next" style="width: 266.25px; margin-right: 5px;">
                <div class="m-goods-item-container new-item-container  pro-item-sec margin-left-0"
                  data-src="https://www.xiaomiyoupin.com/detail?gid=167093" data-target="_blank">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/youpin_gms/8c4df511_e2e0_4993_85ea_7f88a01adb87.jpeg?w=800&amp;h=800">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/youpin_gms/8c4df511_e2e0_4993_85ea_7f88a01adb87.jpeg?w=800&amp;h=800"
                          data-src="https://img.youpin.mi-img.com/youpin_gms/8c4df511_e2e0_4993_85ea_7f88a01adb87.jpeg?w=800&amp;h=800"
                          alt="台式洗碗机5套S2" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                  <div class="m-goods-common-box">
                    <p class="pro-info" title="台式洗碗机5套S2">台式洗碗机5套S2</p>
                    <p class="pro-desc" title="超薄机身大容量，母婴除菌净洗舱">超薄机身大容量，母婴除菌净洗...</p>
                    <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">1699</span></p>
                  </div>
                </div>
              </div>
              <div class="swiper-slide" style="width: 266.25px; margin-right: 5px;">
                <div class="m-goods-item-container new-item-container  pro-item-sec margin-left-0"
                  data-src="https://www.xiaomiyoupin.com/detail?gid=166618" data-target="_blank">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/shop-fe/07cf41ca_90a7_4828_b84a_3551599430a4.jpeg">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/shop-fe/07cf41ca_90a7_4828_b84a_3551599430a4.jpeg"
                          data-src="https://img.youpin.mi-img.com/shop-fe/07cf41ca_90a7_4828_b84a_3551599430a4.jpeg"
                          alt="诸老大枕头粽" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                  <div class="m-goods-common-box">
                    <p class="pro-info" title="诸老大枕头粽">诸老大枕头粽</p>
                    <p class="pro-desc" title="百年传承 中华老字号始于1887">百年传承 中华老字号始于1887</p>
                    <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">49.9</span><span
                        class="pro-flag">起</span></p>
                  </div>
                </div>
              </div>
              <div class="swiper-slide" style="width: 266.25px; margin-right: 5px;">
                <div class="m-goods-item-container new-item-container  pro-item-sec margin-left-0"
                  data-src="https://www.xiaomiyoupin.com/detail?gid=167229" data-target="_blank">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/youpin_gms/fa2ccd43_aa18_4fbd_95e1_94e3e7007314.jpeg?w=800&amp;h=800">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/youpin_gms/fa2ccd43_aa18_4fbd_95e1_94e3e7007314.jpeg?w=800&amp;h=800"
                          data-src="https://img.youpin.mi-img.com/youpin_gms/fa2ccd43_aa18_4fbd_95e1_94e3e7007314.jpeg?w=800&amp;h=800"
                          alt="小米智能猫眼 2" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                  <div class="m-goods-common-box">
                    <p class="pro-info" title="小米智能猫眼 2">小米智能猫眼 2</p>
                    <p class="pro-desc" title="3MP 高清影像丨180° 监控视野丨5米红外补光">3MP 高清影像丨180° 监控视野丨...</p>
                    <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">579</span></p>
                  </div>
                </div>
              </div>
              <div class="swiper-slide" style="width: 266.25px; margin-right: 5px;">
                <div class="m-goods-item-container new-item-container first pro-item-sec margin-left-0"
                  data-src="https://www.xiaomiyoupin.com/detail?gid=166882" data-target="_blank">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/shop-fe/9de738fa_a669_4b5b_ad35_c66b3bcdb5dd.jpeg">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/shop-fe/9de738fa_a669_4b5b_ad35_c66b3bcdb5dd.jpeg"
                          data-src="https://img.youpin.mi-img.com/shop-fe/9de738fa_a669_4b5b_ad35_c66b3bcdb5dd.jpeg"
                          alt="PQQ蓝莓叶黄素" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                  <div class="m-goods-common-box">
                    <p class="pro-info" title="PQQ蓝莓叶黄素">PQQ蓝莓叶黄素</p>
                    <p class="pro-desc" title="40mg*60粒,高性价比,护眼明目">40mg*60粒,高性价比,护眼明目</p>
                    <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">69</span><span
                        class="pro-flag">起</span></p>
                  </div>
                </div>
              </div>
              <div class="swiper-slide" style="width: 266.25px; margin-right: 5px;">
                <div class="m-goods-item-container new-item-container  pro-item-sec margin-left-0"
                  data-src="https://www.xiaomiyoupin.com/detail?gid=167274" data-target="_blank">
                  <div class="small-item-img">
                    <div class="m-product-image-container undefined" style="width: 266px; height: 266px;"
                      data-src="https://img.youpin.mi-img.com/youpin_gms/b0f8d5bb_eee1_4fc2_a811_fd68d107b912.jpeg?w=800&amp;h=800">
                      <div class="img-container" style="width: 266px; height: 266px;"><img
                          src="https://img.youpin.mi-img.com/youpin_gms/b0f8d5bb_eee1_4fc2_a811_fd68d107b912.jpeg?w=800&amp;h=800"
                          data-src="https://img.youpin.mi-img.com/youpin_gms/b0f8d5bb_eee1_4fc2_a811_fd68d107b912.jpeg?w=800&amp;h=800"
                          alt="小米插线板4位4控" style="width: 266px; height: 266px;"></div>
                    </div>
                  </div>
                  <div class="m-goods-common-box">
                    <p class="pro-info" title="小米插线板4位4控">小米插线板4位4控</p>
                    <p class="pro-desc" title="独立控制开关丨防误触保护门丨750℃阻燃外壳丨18mm间距">独立控制开关丨防误触保护门丨...</p>
                    <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">39</span><span
                        class="pro-flag">起</span></p>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-button-next m-icons m-icons-next-hover"></div>
            <div class="swiper-button-prev m-icons m-icons-forward-hover swiper-button-disabled"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="h-section h-category-sec sec27">
      <div class="container">
        <div class="h-sec-top clearfix">
          <h2 class="h-subTit">为你推荐<span></span></h2>
        </div>
        <div class="m-product-list  clearfix">
          <div class="m-goods-item-container first pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=156663" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://img.youpin.mi-img.com/shop-fe/164e1071_3c42_4a53_b1f6_a789325901ef.png">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img src="https://img.youpin.mi-img.com/shop-fe/164e1071_3c42_4a53_b1f6_a789325901ef.png"
                      data-src="https://img.youpin.mi-img.com/shop-fe/164e1071_3c42_4a53_b1f6_a789325901ef.png"
                      alt="优调防滑家居拖" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc">防滑静音简约家居拖</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><img
                  src="https://img.youpin.mi-img.com/tag/4167059a2a83e6dece26ebc1300abaf8.png?w=192&amp;h=42"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><span
                  class="common-tag common-tag-text"
                  style="background-color: rgb(255, 255, 255); color: rgb(248, 36, 0); border-color: rgb(255, 156, 139);">满200减30</span><img
                  src="https://img.youpin.mi-img.com/new_gms/2c0523c5_8d73_4d0b_9004_7c0f7d78bff5.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/73f965df_f41d_403f_8dfb_01d7dad0752d.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="优调防滑家居拖">优调防滑家居拖</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">19.8</span></p>
            </div>
          </div>
          <div class="m-goods-item-container  pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=149183" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://img.youpin.mi-img.com/shop-fe/b16408e9_98d0_4cc5_aa84_6ccddfc57789.png">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img src="https://img.youpin.mi-img.com/shop-fe/b16408e9_98d0_4cc5_aa84_6ccddfc57789.png"
                      data-src="https://img.youpin.mi-img.com/shop-fe/b16408e9_98d0_4cc5_aa84_6ccddfc57789.png"
                      alt="抗静电保暖抓绒衣" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc">保暖抗静电,舒适透气</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><img
                  src="https://img.youpin.mi-img.com/new_gms/8131fd40_d4fe_43a1_943d_a0edd8462824.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/tag/4167059a2a83e6dece26ebc1300abaf8.png?w=192&amp;h=42"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><span
                  class="common-tag common-tag-text"
                  style="background-color: rgb(255, 255, 255); color: rgb(248, 36, 0); border-color: rgb(255, 156, 139);">满200减30</span><img
                  src="https://img.youpin.mi-img.com/new_gms/2c0523c5_8d73_4d0b_9004_7c0f7d78bff5.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/e6c71fb5_c04b_4887_8156_eef6ac36f756.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="抗静电保暖抓绒衣">抗静电保暖抓绒衣</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">59</span></p>
            </div>
          </div>
          <div class="m-goods-item-container  pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=100289" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://img.youpin.mi-img.com/shop-fe/ccba2485_3cf1_4835_ba00_663ad125a220.png">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img src="https://img.youpin.mi-img.com/shop-fe/ccba2485_3cf1_4835_ba00_663ad125a220.png"
                      data-src="https://img.youpin.mi-img.com/shop-fe/ccba2485_3cf1_4835_ba00_663ad125a220.png"
                      alt="竹纤维抑菌手帕纸" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc">不漂白无有害添加,四层加厚</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><img
                  src="https://img.youpin.mi-img.com/tag/4167059a2a83e6dece26ebc1300abaf8.png?w=192&amp;h=42"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><span
                  class="common-tag common-tag-text"
                  style="background-color: rgb(255, 255, 255); color: rgb(248, 36, 0); border-color: rgb(255, 156, 139);">满200减30</span><img
                  src="https://img.youpin.mi-img.com/new_gms/ad04d64d_436f_4cf1_838e_96804dbdd88b.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/73f965df_f41d_403f_8dfb_01d7dad0752d.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="竹纤维抑菌手帕纸">竹纤维抑菌手帕纸</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">14.9</span><span
                  class="pro-flag">起</span></p>
            </div>
          </div>
          <div class="m-goods-item-container  pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=167180" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://img.youpin.mi-img.com/shop-fe/8047d122_8152_45ed_b9ab_eb6f20ef9484.jpeg">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img src="https://img.youpin.mi-img.com/shop-fe/8047d122_8152_45ed_b9ab_eb6f20ef9484.jpeg"
                      data-src="https://img.youpin.mi-img.com/shop-fe/8047d122_8152_45ed_b9ab_eb6f20ef9484.jpeg"
                      alt="电动颈部固定器" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc">气囊推举按摩 无线智能控制</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><span class="common-tag common-tag-text"
                  style="background-color: rgb(254, 166, 0); color: rgb(255, 255, 255); border-color: rgb(255, 156, 139);">HOT</span><img
                  src="https://img.youpin.mi-img.com/new_gms/2c0523c5_8d73_4d0b_9004_7c0f7d78bff5.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/22d7f25a_e2ff_4914_811b_dc3d306f9132.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="电动颈部固定器">电动颈部固定器</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">399</span></p>
            </div>
          </div>
          <div class="m-goods-item-container first pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=154255" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://cnbj1-new.fds.api.xiaomi.com/nr-upload-outer/img_94d675ba-9cec-4c3e-bd7d-6a0934283c98.png?w=800&amp;h=800&amp;workId=64658f167b6b980030428fd9">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img
                      src="https://cnbj1-new.fds.api.xiaomi.com/nr-upload-outer/img_94d675ba-9cec-4c3e-bd7d-6a0934283c98.png?w=800&amp;h=800&amp;workId=64658f167b6b980030428fd9"
                      data-src="https://cnbj1-new.fds.api.xiaomi.com/nr-upload-outer/img_94d675ba-9cec-4c3e-bd7d-6a0934283c98.png?w=800&amp;h=800&amp;workId=64658f167b6b980030428fd9"
                      alt="野马轻便儿童头盔" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc">野马夏季轻便儿童头盔</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><img
                  src="https://img.youpin.mi-img.com/tag/4167059a2a83e6dece26ebc1300abaf8.png?w=192&amp;h=42"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/2c0523c5_8d73_4d0b_9004_7c0f7d78bff5.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/73f965df_f41d_403f_8dfb_01d7dad0752d.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="野马轻便儿童头盔">野马轻便儿童头盔</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">117.3</span><span
                  class="pro-flag">起</span></p>
            </div>
          </div>
          <div class="m-goods-item-container  pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=149253" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://img.youpin.mi-img.com/shopmain/7ad91c34609f659b3e45b6b53b1acea1.png?w=800&amp;h=800">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img
                      src="https://img.youpin.mi-img.com/shopmain/7ad91c34609f659b3e45b6b53b1acea1.png?w=800&amp;h=800"
                      data-src="https://img.youpin.mi-img.com/shopmain/7ad91c34609f659b3e45b6b53b1acea1.png?w=800&amp;h=800"
                      alt="小米人脸识别门锁" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc"> 小米高端旗舰人脸识别门锁</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><img
                  src="https://img.youpin.mi-img.com/new_gms/8131fd40_d4fe_43a1_943d_a0edd8462824.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/ad04d64d_436f_4cf1_838e_96804dbdd88b.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/2643a0f2_c7ec_4b40_ae6d_069891ce16a6.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/73f965df_f41d_403f_8dfb_01d7dad0752d.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="小米人脸识别门锁">小米人脸识别门锁</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">1979</span></p>
            </div>
          </div>
          <div class="m-goods-item-container  pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=158952" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://img.youpin.mi-img.com/shop-fe/d3e6fec9_3976_45e9_9786_26dd7b7c8b0e.png">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img src="https://img.youpin.mi-img.com/shop-fe/d3e6fec9_3976_45e9_9786_26dd7b7c8b0e.png"
                      data-src="https://img.youpin.mi-img.com/shop-fe/d3e6fec9_3976_45e9_9786_26dd7b7c8b0e.png"
                      alt="北海流油海鸭蛋" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc">来自北部湾红树林的美味</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><img
                  src="https://img.youpin.mi-img.com/new_gms/35ee1c98_6090_40fa_85ed_d4a2070e50c3.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/tag/4167059a2a83e6dece26ebc1300abaf8.png?w=192&amp;h=42"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><span
                  class="common-tag common-tag-text"
                  style="background-color: rgb(255, 255, 255); color: rgb(248, 36, 0); border-color: rgb(255, 156, 139);">满99减10</span><img
                  src="https://img.youpin.mi-img.com/new_gms/73f965df_f41d_403f_8dfb_01d7dad0752d.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="北海流油海鸭蛋">北海流油海鸭蛋</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">49.9</span></p>
            </div>
          </div>
          <div class="m-goods-item-container  pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=148210" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://img.youpin.mi-img.com/shop-fe/6157b9eb_abda_47ad_873a_e8a387e2ae7b.png">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img src="https://img.youpin.mi-img.com/shop-fe/6157b9eb_abda_47ad_873a_e8a387e2ae7b.png"
                      data-src="https://img.youpin.mi-img.com/shop-fe/6157b9eb_abda_47ad_873a_e8a387e2ae7b.png"
                      alt="重力车载手机支架" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc">重力感应,六点折叠可伸缩</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><img
                  src="https://img.youpin.mi-img.com/tag/4167059a2a83e6dece26ebc1300abaf8.png?w=192&amp;h=42"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><span
                  class="common-tag common-tag-text"
                  style="background-color: rgb(255, 255, 255); color: rgb(248, 36, 0); border-color: rgb(255, 156, 139);">满99减10</span><img
                  src="https://img.youpin.mi-img.com/new_gms/2c0523c5_8d73_4d0b_9004_7c0f7d78bff5.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/ad04d64d_436f_4cf1_838e_96804dbdd88b.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/73f965df_f41d_403f_8dfb_01d7dad0752d.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="重力车载手机支架">重力车载手机支架</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">39</span></p>
            </div>
          </div>
          <div class="m-goods-item-container first pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=143938" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://img.youpin.mi-img.com/shopmain/9f6bb5fbb0ca4372ff530931ed003cf8.png?w=800&amp;h=800">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img
                      src="https://img.youpin.mi-img.com/shopmain/9f6bb5fbb0ca4372ff530931ed003cf8.png?w=800&amp;h=800"
                      data-src="https://img.youpin.mi-img.com/shopmain/9f6bb5fbb0ca4372ff530931ed003cf8.png?w=800&amp;h=800"
                      alt="新鲜东魁杨梅" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc">云南高山杨梅，地标产品</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><img
                  src="https://img.youpin.mi-img.com/tag/4167059a2a83e6dece26ebc1300abaf8.png?w=192&amp;h=42"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/2c0523c5_8d73_4d0b_9004_7c0f7d78bff5.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="新鲜东魁杨梅">新鲜东魁杨梅</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">148</span><span
                  class="pro-flag">起</span></p>
            </div>
          </div>
          <div class="m-goods-item-container  pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=140250" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://img.youpin.mi-img.com/shop-fe/a35165bc_622b_43ed_9660_52db9b3b76ec.png">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img src="https://img.youpin.mi-img.com/shop-fe/a35165bc_622b_43ed_9660_52db9b3b76ec.png"
                      data-src="https://img.youpin.mi-img.com/shop-fe/a35165bc_622b_43ed_9660_52db9b3b76ec.png"
                      alt="牛小哥头盔" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc">安全的重量,可以很轻</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><img
                  src="https://img.youpin.mi-img.com/tag/4167059a2a83e6dece26ebc1300abaf8.png?w=192&amp;h=42"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/e6c71fb5_c04b_4887_8156_eef6ac36f756.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/new_gms/73f965df_f41d_403f_8dfb_01d7dad0752d.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="牛小哥头盔">牛小哥头盔</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">79</span><span
                  class="pro-flag">起</span></p>
            </div>
          </div>
          <div class="m-goods-item-container  pro-item-category"
            data-src="https://www.xiaomiyoupin.com/detail?gid=163372" data-target="_blank">
            <div class="category-img-container">
              <div class="product-img">
                <div class="m-product-image-container undefined" style="width: 264px; height: 198px;"
                  data-src="https://img.youpin.mi-img.com/shop-fe/7a574346_43a0_4026_b3be_dd29748b4569.png">
                  <div class="img-container"
                    style="padding-left: 35px; padding-right: 35px; padding-bottom: 3px; width: 194px; height: 195px;">
                    <img src="https://img.youpin.mi-img.com/shop-fe/7a574346_43a0_4026_b3be_dd29748b4569.png"
                      data-src="https://img.youpin.mi-img.com/shop-fe/7a574346_43a0_4026_b3be_dd29748b4569.png"
                      alt="睾丸酮增强剂" style="height: 195px; width: 195px; margin-left: -0.5px;"></div>
                </div>
              </div>
              <p class="pro-desc">睾丸酮增强剂,促睾胶囊</p>
            </div>
            <div class="category-box">
              <div class="m-goods-common-tag-con"><img
                  src="https://img.youpin.mi-img.com/new_gms/da07b0ad_6931_4a46_a259_634a0a1ce2ad.jpeg"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><img
                  src="https://img.youpin.mi-img.com/tag/4167059a2a83e6dece26ebc1300abaf8.png?w=192&amp;h=42"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"><span
                  class="common-tag common-tag-text"
                  style="background-color: rgb(255, 255, 255); color: rgb(248, 36, 0); border-color: rgb(255, 156, 139);">满200减30</span><img
                  src="https://img.youpin.mi-img.com/new_gms/73f965df_f41d_403f_8dfb_01d7dad0752d.png"
                  class="common-tag common-tag-img" alt="" style="height: 20px;"></div>
              <p class="pro-info" title="睾丸酮增强剂">睾丸酮增强剂</p>
              <p class="pro-price"><span class="pro-unit">¥</span><span class="m-num">94</span><span
                  class="pro-flag">起</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
</script>
<style>
/* 小米有品众筹 */
.h-crowdfounding {
    margin-top: 35px;
}
.h-section, .home-wrap .m-footer {
    margin-top: 60px;
}
.container {
    width: 1080px;
    margin: 0 auto;
}
.h-sec-top {
    position: relative;
    z-index: 99;
    margin-bottom: 20px;
}
.h-sec-top .h-subTit {
    color: #333;
    font-size: 28px;
    font-weight: 400;
}
.h-sec-top .h-subTit span {
    margin-left: 12px;
    font-size: 14px;
    color: #999;
}
.h-sec-top .h-more {
    position: absolute;
    right: 0;
    top: 6px;
    height: 30px;
    color: #999;
    cursor: pointer;
}
.h-sec-top .h-more span {
    position: relative;
    bottom: 9px;
    font-size: 14px;
}
.h-sec-top .h-more .more-icon {
    height: 30px;
    width: 30px;
}
.m-icons-more {
    width: 30px;
    height: 30px;
    background-position: 0 -1134px;
}
.m-icons {
    display: inline-block;
    background-image: url(//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/yp-icons.20abdb4e.png);
}
a, button {
    outline: none;
}
a {
    text-decoration: none;
}
body, dd, div, dl, dt, h1, h2, h3, h4, h5, h6, li, ol, p, ul {
    margin: 0;
    padding: 0;
}
.no-ml {
    margin-left: 0;
}

.home-good-item .item-inner {
    position: relative;
    height: 210px;
    background: #f3f0e9;
}
.i1{
  width: 533px;
}
.i2,.i3{
  width: 266px;
}
.no-ml {
    margin-left: 0;
}
.home-good-item {
    float: left;
    margin-left: 5px;
}
.m-tag-a {
    cursor: pointer;
}

.home-good-item-big .pro-img, .home-good-item-big .pro-img1 {
    position: absolute;
    right: 15px;
    bottom: 10px;
    width: 215px;
    height: 215px;
    z-index: 4;
}
img {
    vertical-align: middle;
    border: none;
}
.home-good-item-big .pro-text {
    position: relative;
    z-index: 6;
    padding-top: 25px;
    padding-left: 23px;
}
.home-good-item-big .pro-info {
    color: #333;
    margin-top: 0;
    font-size: 20px;
    line-height: 24px;
    height: 24px;
}
.pro-desc, .pro-info {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.home-good-item-big .pro-desc {
    color: #999;
    font-size: 16px;
    line-height: 20px;
    height: 20px;
    margin-top: 8px;
}
.home-good-item-big .pro-price {
    font-size: 24px;
    line-height: 28px;
    height: 28px;
    overflow: hidden;
    color: #a92112;
    margin-top: 16px;
}
.home-good-item-big .pro-price .tag {
    font-size: 15px;
    vertical-align: top;
    margin-right: 7px;
}
.pro-flag, .pro-ori, .pro-unit {
    font-size: 12px;
}
.m-progress-wrap-con .m-bar-con {
    width: 100%;
    height: 3px;
    overflow: hidden;
    background: #e3e1e2;
}
.m-progress-wrap-con .m-bar-con .m-bar {
    width: 0;
    height: 100%;
    background: url(//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/bar.d948f88f.jpg) 0 0 no-repeat;
}
.m-progress-wrap-con .m-progress-info {
    margin-top: 10px;
}
.m-progress-wrap-con .m-progress-info .m-suppory {
    color: #999;
    font-size: 15px;
    margin-left: 20px;
}
.m-progress-wrap-con .m-progress-info .m-suppory .sup-num {
    margin-right: 6px;
    color: #a92112;
    font-size: 18px;
}
.progress-tag-con {
    text-align: center;
    height: 18px;
    padding-top: 2px;
    padding-bottom: 2px;
    overflow: hidden;
    display: inline-block;
}
.fl {
    float: left;
}
.progress-tag-con .common-tag-img, .progress-tag-con .common-tag-text {
    height: 18px;
    border-radius: 2px;
    vertical-align: bottom;
}
.progress-tag-con .common-tag-text {
    padding: 0 6px;
    color: #fff;
    font-size: 13px;
    line-height: 18px;
}
.progress-tag-con .common-tag {
    display: inline-block;
    height: 18px;
    margin-left: 3px;
}
.m-progress-wrap-con .m-progress-info .m-persent {
    margin-right: 15px;
    color: #a92112;
    font-size: 18px;
}
.fr {
    float: right;
}
.m-progress-wrap-con .m-progress-info .m-num-flag {
    font-size: 11px;
}
.home-good-item {
    float: left;
    margin-left: 5px;
}
.m-tag-a {
    cursor: pointer;
}

.home-good-item .pro-img, .home-good-item .pro-img1 {
    position: absolute;
    right: 15px;
    bottom: 10px;
    width: 130px;
    height: 130px;
    z-index: 4;
}
img {
    vertical-align: middle;
    border: none;
}
img {
    overflow-clip-margin: content-box;
    overflow: clip;
}
.home-good-item .pro-text {
    position: relative;
    z-index: 6;
    padding-top: 25px;
    padding-left: 15px;
}
.home-good-item .pro-info {
    color: #333;
    margin-top: 0;
    font-size: 20px;
    line-height: 24px;
    height: 24px;
}
.home-good-item .pro-price {
    font-size: 20px;
    line-height: 24px;
    height: 24px;
    overflow: hidden;
    color: #a92112;
    margin-top: 11px;
}
.home-good-item .pro-price .tag {
    font-size: 11px;
    vertical-align: top;
    margin-right: 5px;
}
/* 有品秒杀 */
.p-trap-wrap {
    padding-top: 40px;
}
.container {
    width: 1080px;
    margin: 0 auto;
}
.h-sec-top {
    position: relative;
    z-index: 99;
    margin-bottom: 20px;
}
.fl {
    float: left;
}
.h-sec-top .h-subTit {
    color: #333;
    font-size: 28px;
    font-weight: 400;
}
.fl {
    float: left;
}
.p-trap-wrap .trap-top-main .timestr {
    margin-left: 12px;
}
.h-sec-top .h-subTit span {
    margin-left: 12px;
    font-size: 14px;
    color: #999;
}
.p-trap-wrap .trap-top-main .timestr img {
    width: 18px;
    height: 18px;
    vertical-align: -15%;
}
img {
    vertical-align: middle;
    border: none;
}
.p-trap-wrap .trap-top-main .timestr span {
    margin-left: 3px;
    font-size: 18px;
    color: #a92112;
}
.h-sec-top .h-subTit span {
    margin-left: 12px;
    font-size: 14px;
    color: #999;
}
.p-trap-wrap .trap-top-main .countdown {
    height: 23px;
    margin-left: 6px;
    position: relative;
    top: 12px;
}
.fl {
    float: left;
}
.h-countdown-wrap .time-item-home {
    display: inline-block;
    width: 23px;
    height: 23px;
    line-height: 23px;
    margin: 0 3px;
    color: #fff;
    text-align: center;
    font-size: 15px;
    background: #b04337;
}
.h-countdown-wrap .m-countdown-dot-home {
    display: inline-block;
    font-size: 15px;
    color: #b04337;
}
.h-countdown-wrap .time-item-home {
    display: inline-block;
    width: 23px;
    height: 23px;
    line-height: 23px;
    margin: 0 3px;
    color: #fff;
    text-align: center;
    font-size: 15px;
    background: #b04337;
}
.h-countdown-wrap .m-countdown-dot-home {
    display: inline-block;
    font-size: 15px;
    color: #b04337;
}
.h-countdown-wrap .time-item-home {
    display: inline-block;
    width: 23px;
    height: 23px;
    line-height: 23px;
    margin: 0 3px;
    color: #fff;
    text-align: center;
    font-size: 15px;
    background: #b04337;
}
.h-sec-top .h-more {
    position: absolute;
    right: 0;
    top: 6px;
    height: 30px;
    color: #999;
    cursor: pointer;
}
.h-sec-top .h-more span {
    position: relative;
    bottom: 9px;
    font-size: 14px;
}
.h-sec-top .h-more .more-icon {
    height: 30px;
    width: 30px;
}
.m-icons-more {
    width: 30px;
    height: 30px;
    background-position: 0 -1134px;
}
.m-icons {
    display: inline-block;
    background-image: url(//cdn.cnbj1.fds.api.mi-img.com/youpin-pc/production/YouPin_PC/static3/media/yp-icons.20abdb4e.png);
}
.swiper-container {
    position: relative;
    overflow: hidden;
    margin: 0 auto;
    z-index: 2;
}
.swiper-wrapper {
    position: relative;
    width: 100%;
    height: 100%;
    z-index: 3;
    display: flex;
    box-sizing: content-box;
}
.swiper-slide {
    -webkit-flex-shrink: 0;
    -ms-flex: 0 0 auto;
    flex-shrink: 0;
    width: 100%;
    height: 100%;
    position: relative;
}
.m-goods-item-container.first {
    margin-left: 0;
}
.margin-left-0 {
    margin-left: 0;
}
.m-goods-item-container {
    position: relative;
    float: left;
    width: 266px;
    margin-left: 5px;
    text-align: center;
    background: #fff;
    transition: all .4s;
    cursor: pointer;
}
.bigtrap-img-tag-container {
    width: 266px;
    height: 266px;
    position: relative;
}
.hot-big-item-img, .small-item-img {
    display: block;
    width: 100%;
    text-align: center;
    overflow: hidden;
    background: #f8f8f8;
}
.m-product-image-container {
    overflow: hidden;
}
.m-product-image-container .img-container {
    overflow: hidden;
    display: inline-block;
}
.bigtrap-box {
    background: #faf6ef;
    padding-top: 13px;
    padding-bottom: 15px;
}
.bigtrap-box .pro-info {
    color: #333;
    font-size: 19px;
    line-height: 23px;
    height: 23px;
    margin-top: 0;
}
.pro-desc, .pro-info {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.bigtrap-box .pro-price {
    margin-bottom: 0;
}
.m-goods-item-container .pro-price {
    margin-top: 11px;
    margin-bottom: 0;
    height: 26px;
    line-height: 26px;
    color: #a92112;
}
.pro-price {
    height: 26px;
    line-height: 26px;
    overflow: hidden;
    color: #c00000;
}
.m-goods-item-container .pro-unit {
    font-size: 15px;
}
.pro-flag, .pro-ori, .pro-unit {
    font-size: 12px;
}
.m-goods-item-container .m-num {
    font-size: 22px;
}
.pro-flag, .pro-ori, .pro-unit {
    font-size: 12px;
}
.m-goods-item-container .market-price {
    text-decoration: line-through;
    color: #333;
    margin-left: 5px;
}
.m-goods-item-container .market-price .pro-unit {
    font-size: 9px;
}
.m-goods-item-container .pro-unit {
    font-size: 15px;
}
.pro-flag, .pro-ori, .pro-unit {
    font-size: 12px;
}
.m-goods-item-container .market-price .m-num {
    font-size: 14px;
}
.m-goods-item-container .m-num {
    font-size: 22px;
}
/* 为你推荐 */
.h-category-sec {
    margin-top: 50px;
}
.h-section, .home-wrap .m-footer {
    margin-top: 60px;
}
.container {
    width: 1000px;
    margin: 0 auto;
}
.h-sec-top {
    position: relative;
    z-index: 99;
    margin-bottom: 20px;
}
.h-sec-top .h-subTit {
    color: #333;
    font-size: 28px;
    font-weight: 400;
}
.h-sec-top .h-subTit span {
    margin-left: 12px;
    font-size: 14px;
    color: #999;
}
.h-category-sec .pro-item-category {
    width: 264px;
    padding-bottom: 0;
    margin-bottom: 5px;
    border: 1px solid #e7e7e7;
    background: none;
}
.category-img-container {
    width: 100%;
}
.category-img-container .product-img {
    width: 100%;
    height: 198px;
    overflow: hidden;
}
.m-product-image-container {
    overflow: hidden;
}
.m-product-image-container .img-container {
    overflow: hidden;
    display: inline-block;
}
img {
    vertical-align: middle;
    border: none;
}
.category-img-container .pro-desc {
    color: #845f3f;
    font-size: 16px;
    line-height: 20px;
    height: 20px;
    margin-top: 0;
}
.m-goods-item-container .pro-desc {
    color: #666;
    font-size: 14px;
    line-height: 18px;
    height: 18px;
    margin-top: 8px;
}
.pro-desc {
    height: 24px;
    line-height: 24px;
    font-size: 14px;
    color: #999;
}
.pro-desc, .pro-info {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.m-product-image-container .img-container {
    overflow: hidden;
    display: inline-block;
}
.m-goods-common-tag-con {
    text-align: center;
    height: 20px;
    line-height: 22px;
    padding-top: 2px;
    padding-bottom: 2px;
    width: 100%;
    overflow: hidden;
}
.m-goods-item-container .common-tag-img {
    height: 20px;
    overflow: hidden;
    vertical-align: bottom;
}
.m-goods-item-container .common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
.common-tag-img {
    overflow: hidden;
    vertical-align: bottom;
}
img {
    vertical-align: middle;
    border: none;
}
img {
    overflow-clip-margin: content-box;
    overflow: clip;
}
.m-goods-item-container .common-tag-text {
    padding: 0 4.5px;
    font-size: 14px;
    line-height: 20px;
    vertical-align: bottom;
    border-radius: 3px;
    border-width: .7px;
    border-style: solid;
}
.m-goods-item-container .common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
.common-tag-text {
    padding: 0 4.5px;
    font-size: 14px;
    height: 18.6px;
    line-height: 18.6px;
    vertical-align: bottom;
    border-radius: 3px;
    border-width: .7px;
    border-style: solid;
}
.common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
.m-goods-item-container .common-tag-img {
    height: 20px;
    overflow: hidden;
    vertical-align: bottom;
}
.m-goods-item-container .common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
.common-tag-img {
    overflow: hidden;
    vertical-align: bottom;
}
.common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}

.category-box {
    margin-top: 18px;
    padding: 13px 0 10px;
    background: #f8f8f8;
}
.m-goods-common-tag-con {
    text-align: center;
    height: 20px;
    line-height: 22px;
    padding-top: 2px;
    padding-bottom: 2px;
    width: 100%;
    overflow: hidden;
}
.m-goods-item-container .common-tag-img {
    height: 20px;
    overflow: hidden;
    vertical-align: bottom;
}
.m-goods-item-container .common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
.common-tag-img {
    overflow: hidden;
    vertical-align: bottom;
}
.common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
img {
    vertical-align: middle;
    border: none;
}
.m-goods-item-container .common-tag-text {
    padding: 0 4.5px;
    font-size: 14px;
    line-height: 20px;
    vertical-align: bottom;
    border-radius: 3px;
    border-width: .7px;
    border-style: solid;
}
.m-goods-item-container .common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
.common-tag-text {
    padding: 0 4.5px;
    font-size: 14px;
    height: 18.6px;
    line-height: 18.6px;
    vertical-align: bottom;
    border-radius: 3px;
    border-width: .7px;
    border-style: solid;
}
.common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
.m-goods-item-container .common-tag-img {
    height: 20px;
    overflow: hidden;
    vertical-align: bottom;
}
.m-goods-item-container .common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
.common-tag-img {
    overflow: hidden;
    vertical-align: bottom;
}
.common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
img {
    vertical-align: middle;
    border: none;
}
.m-goods-item-container .common-tag-img {
    height: 20px;
    overflow: hidden;
    vertical-align: bottom;
}
.m-goods-item-container .common-tag {
    display: inline-block;
    height: 20px;
    margin-left: 8px;
}
.category-box .pro-info {
    color: #333;
    margin-top: 10px;
    font-size: 18px;
    line-height: 22px;
    height: 22px;
}
.m-goods-item-container .pro-info {
    color: #333;
    margin-top: 8px;
    font-size: 19px;
    line-height: 23px;
    height: 23px;
}
.pro-desc, .pro-info {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.pro-info {
    height: 26px;
    line-height: 26px;
    margin-top: 10px;
    color: #333;
    font-size: 16px;
}
.category-box .pro-price {
    margin-top: 11px;
    margin-bottom: 0;
    height: 22px;
    line-height: 22px;
    color: #a92112;
}
.m-goods-item-container .pro-price {
    margin-top: 11px;
    margin-bottom: 0;
    height: 26px;
    line-height: 26px;
    color: #a92112;
}
.pro-price {
    color: #a92112;
}
.pro-price {
    height: 26px;
    line-height: 26px;
    overflow: hidden;
    color: #c00000;
}
.category-box .pro-price .pro-unit {
    margin-right: 5px;
}
.category-box .pro-price .pro-unit {
    font-size: 13px;
}
.m-goods-item-container .pro-unit {
    font-size: 15px;
}
.m-product-list .pro-unit {
    font-size: 12px;
}
.pro-flag, .pro-ori, .pro-unit {
    font-size: 12px;
}
.category-box .pro-price .m-num {
    font-size: 20px;
}
.m-goods-item-container .m-num {
    font-size: 22px;
}
.m-product-image-container .img-container {
    overflow: hidden;
    display: inline-block;
}
.h-category-sec .pro-item-category {
    width: 264px;
    padding-bottom: 0;
    margin-bottom: 5px;
    border: 1px solid #e7e7e7;
    background: none;
}
.m-goods-item-container.first {
    margin-left: 0;
}
.h-category-sec .pro-item-category {
    width: 264px;
    padding-bottom: 0;
    margin-bottom: 5px;
    border: 1px solid #e7e7e7;
    background: none;
}
.m-goods-item-container {
    position: relative;
    float: left;
    width: 266px;
    margin-left: 5px;
    text-align: center;
    background: #fff;
    transition: all .4s;
    cursor: pointer;
}
.category-img-container {
    width: 100%;
}
.category-img-container .product-img {
    width: 100%;
    height: 198px;
    overflow: hidden;
}
.m-product-image-container {
    overflow: hidden;
}

</style>