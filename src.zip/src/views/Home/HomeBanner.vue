<template>
    <div class="banner-box">
        <div class="m-banner ">
            <div class="m-ban-con">
                <div class="swiper-container swiper-container-horizontal">
                    <el-carousel height="358px">
                        <el-carousel-item v-for="item in imgList" :key="item.id">
                            <img :src=item.src >
                        </el-carousel-item>
                    </el-carousel>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import { ref } from 'vue';
import { getBanner } from '@/api';
import AppBanner from '@/components/library/AppBanner.vue';

export default {
    data() {
    return {
      imgList: [
        { id: '1', src: 'https://img.youpin.mi-img.com/youpinoper/ea993175_aa74_4be9_a444_bdd0901a4730.jpeg?w=1080&amp;h=450'},
        { id: '2', src: 'https://img.youpin.mi-img.com/youpinoper/cb93a1da_08d9_46e3_aa9c_25c6549a0fe4.jpeg?w=1080&amp;h=450'},
        { id: '3', src: 'https://img.youpin.mi-img.com/youpinoper/380d3e43_dbef_4bad_90c5_118a59f19caf.jpeg?w=1080&amp;h=450'},
        { id: '4', src: 'https://img.youpin.mi-img.com/youpinoper/051115c6_7660_4e6e_bd5a_0b3daf8281f5.jpeg?w=1080&amp;h=450'},
        { id: '5', src: 'https://img.youpin.mi-img.com/youpinoper/f8ede245_b7fd_4344_b9b3_ea7b63767718.png?w=1080&amp;h=450'}
      ]
    }
    // setup() {
    //     const list = ref([]);
    //     getBanner().then(res => {
    //         console.log(res);
    //         if (res.msg = '操作成功') {
    //             list.value = res.result;
    //         }
    //     }).catch(err => {
    //         console.log(err);
    //     });
    //     return { list }
    // }
}
}
</script>
<style lang="less" scoped>
img{
    width: 900px;
}
.banner-box {
    position: relative;
    width: 100%;
    height: 100%;
    z-index: 3;
    display: flex;
    box-sizing: content-box;
}

.banner-nav .banner-box {
    width: 859px;
    float: right;
}

.m-banner .swipe-item img {
    height: 358px;
}

.m-banner,
.m-banner .m-ban-con {
    position: relative;
}

.m-banner {
    z-index: 1;
    width: 859px;
    margin: 0 auto;
    text-align: center;
}

.swiper-wrapper {
    position: relative;
    width: 100%;
    height: 100%;
    z-index: 3;
    display: flex;
    box-sizing: content-box;
}

div.p-hero-wrap .container {
    padding-top: 30px;
    border-bottom-width: 1px;
    border-bottom-style: solid;
    overflow: hidden;
}

.container {
    width: 1080px;
    margin: 0 auto;
}

div.p-hero-wrap .container .line-container {
    display: inline-block;
}

div.p-hero-wrap .p-hreo-nav {
    overflow: hidden;
    padding-bottom: 10px;
}

div.p-hero-wrap .p-hreo-nav .kingkong-column:first-child {
    margin-left: 28px;
}

div.p-hero-wrap .p-hreo-nav .kingkong-column:last-child {
    margin-right: 28px;
}

div.p-hero-wrap .p-hreo-nav .kingkong-column {
    width: 116px;
    height: 100%;
    min-height: 277px;
    display: inline-block;
    margin-right: 110px;
}

div.p-hero-wrap .p-hreo-nav li:last-child {
    margin-right: 0;
}

div.p-hero-wrap .p-hreo-nav li {
    float: left;
    width: 116px;
}

.m-tag-a {
    cursor: pointer;
}

.m-product-image-container {
    overflow: hidden;
}

.m-product-image-container .img-container {
    overflow: hidden;
    display: inline-block;
}

img {
    vertical-align: middle;
    border: none;
}

div.p-hero-wrap .p-hreo-nav li .title {
    font-size: 14px;
    margin-top: 4px;
    width: 116px;
    text-align: center;
    color: #999;
}

.title {
    margin-right: 6px;
}

.nav-container .nav-list .nav-item:last-child:not(:nth-of-type(10)) {
    margin-bottom: 13px;
}

.m-banner .swipe-item {
    font-weight: 700;
    color: #14ade5;
    font-size: 20px;
}

.swiper-slide {
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    width: 100%;
    height: 100%;
    position: relative;
}

.m-tag-a {
    cursor: pointer;
}

a,
button {
    outline: none;
}

a {
    text-decoration: none;
}

.m-banner .swipe-item img {
    height: 358px;
}

.swiper-container-horizontal>.swiper-pagination-bullets,
.swiper-pagination-custom,
.swiper-pagination-fraction {
    bottom: 10px;
    left: 0;
    width: 100%;
}

.swiper-pagination {
    position: absolute;
    text-align: center;
    transition: .3s;
    transform: translateZ(0);
    z-index: 10;
}

.swiper-button-next {
    right: 10px
}

.swiper-button-next,
.swiper-button-prev {
    position: absolute;
    top: 50%;
    margin-top: -22px;
    z-index: 10;
    cursor: pointer;
}

div.p-hero-wrap .container .line-container {
    display: inline-block;
}

div.p-hero-wrap .container {
    padding-top: 30px;
    border-bottom-width: 1px;
    border-bottom-style: solid;
    overflow: hidden;
}

.container {
    width: 1080px;
    margin: 0 auto;
}
</style>