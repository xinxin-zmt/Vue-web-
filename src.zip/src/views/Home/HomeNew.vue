<template>
  <div class="home-new">
  <MyPanel>
    
  </MyPanel>
  </div>
</template>
<script>
import MyPanel from '@/components/MyPanel.vue'
export default {
  components:{
    MyPanel
  }
}
</script>
<style lang="less" scoped>
  
</style>




