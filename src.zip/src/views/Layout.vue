<template>
    <!-- 1、顶部通栏 -->
    <AppTopNav/>
    <!-- 2、头部区域 -->
    <MyHeader/>
    <!-- 3、主体区域 -->
    <div class="main">
        <Section/>
        <Home/>
    </div>
    <!-- 4、底部区域 -->
    <FixedBar/>
    <MyFooter/>
</template>
<script>
import AppTopNav from'@/components/AppTopNav.vue'
import MyHeader from'@/components/MyHeader.vue'
import AppHeaderNav from'@/components/AppHeaderNav.vue'

import Home from'@/views/Home/Home.vue'
import Section from'@/components/Section.vue'
import FixedBar from'@/components/FixedBar.vue'
import MyFooter from'@/components/MyFooter.vue'
export default {
    components:{
        AppTopNav,
        MyHeader,
        AppHeaderNav,
        Home,
        Section,
        FixedBar,
        MyFooter
    }
}
</script>

<style lang="less" scoped></style>